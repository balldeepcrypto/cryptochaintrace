import { useState, useMemo, useRef, useCallback, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import {
  useGetWallet,
  useGetWalletTransactions,
  getGetWalletQueryKey,
  getGetWalletTransactionsQueryKey,
} from "@workspace/api-client-react";
import { AddressDisplay } from "@/components/address-display";
import { saveRecentSearch } from "@/lib/recent-searches";
import { exportAsPdf, exportAsJson, reportFilename, encodeReportForUrl, sha256Sync } from "@/lib/report-export";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ArrowLeftRight, ArrowDownLeft, ArrowUpRight, ArrowLeft,
  Network, GitFork, FileCode, Tag, ShieldAlert, ShieldCheck, Shield,
  ExternalLink, Users, ChevronRight, ChevronDown, Loader2,
  AlertTriangle, X, Zap, Bookmark, BookmarkCheck, Copy, Check, Heart, MessageSquare,
  Plus, GitMerge, Layers, Flag, FileText, MousePointer2, Download, FileJson,
  Landmark, Star, Route, Package,
} from "lucide-react";
import { Link } from "wouter";

// ─── Known entity labels ──────────────────────────────────────────────────────
// "dag-team" = DAG official entities (DOR Metagraph, DTM, Team Foundation, Treasury,
//   Validator Tax Pool, Reward Pool). They are LABELLED PROMINENTLY and highlighted in
//   reports, but they DO count as private commingling evidence (unlike exchange/bridge/genesis).
const KNOWN_LABELS: Record<string, { label: string; type: "exchange" | "genesis" | "defi" | "flagged" | "bridge" | "dag-team" | "official" | "mixer" | "founder" }> = {
  // ── XRP ────────────────────────────────────────────────────────────────────
  rHb9CJAWyB4rj91VRWn96DkukG4bwdtyTh: { label: "XRP Genesis",     type: "genesis" },
  r3kmLJN5D28dHuH8vZNUZpMC4JPgrKQBkR: { label: "Ripple Inc.",      type: "genesis" },
  r9cZA1mLK5R5Am25ArfXFmqgNwjZgnfk59: { label: "Ripple Cold 1",   type: "genesis" },
  rHb9CJAWyB4uj91VRWn96DkukG4bwdtyTh: { label: "Ripple Cold 2",   type: "genesis" },
  rhtufNsYfrozs4GvSq4HMYcR9y3dg8FwdC: { label: "Ripple Treasury / Official", type: "genesis" },
  // ── XRPL Founders / Major Holders ──────────────────────────────────────────
  ragKXjY7cBTXUus32sYHZVfkY46Nt2O829: { label: "Arthur Britto — XRPL Co-Creator", type: "founder" },
  rG2eEaeiJou6cVQ3Ktx7XMNwGhuW99xmHP: { label: "Arthur Britto — XRPL Co-Creator", type: "founder" },
  rsF9cc6gniHLTR2Jng29ng21ez7L9PpmPt: { label: "Arthur Britto — XRPL Co-Creator", type: "founder" },
  rJ5EJYsW6Vkeruj1LAmQYq3VP7QUQKBH1W: { label: "Arthur Britto — XRPL Co-Creator", type: "founder" },
  rsXNUCJKxeyFuGHyfRnuWPita2ns32upBD: { label: "Arthur Britto — XRPL Co-Creator", type: "founder" },
  rQKZSmgmBJvv3Fwj1vuGjUXnegTqJc25z:  { label: "Arthur Britto — XRPL Co-Creator", type: "founder" },
  rDfrrrBJZshSQDvfT2kmL9oUBdish52unH: { label: "Chris Larsen — Ripple Co-Founder", type: "founder" },
  rD6tdgGHG7hwGTA6P39aE7W89fbqxXRjzk: { label: "Chris Larsen — Ripple Co-Founder", type: "founder" },
  r476293LUcdqtjiSGJ5Dh44J1xBCDWeX3:  { label: "Chris Larsen — Ripple Co-Founder", type: "founder" },
  r44CNwMwyJf4MEA1eHVMLPTkZ1LSv4B2rv: { label: "Chris Larsen — Ripple Co-Founder", type: "founder" },
  rhREXVH938ToGkdJ09NCYEY4x8kSEtjna:  { label: "Chris Larsen — Ripple Co-Founder", type: "founder" },
  rPoJNiCk7XSFLR28nH2hAbkYqjtMC3hK2k: { label: "Chris Larsen — Ripple Co-Founder",  type: "founder" },
  rU1bPM4q2rVhC73F7znm7Lt5QnYzZsV35q: { label: "Chris Larsen Funding Wallet",        type: "founder" },
  rEbKBkgKSQgm5x8PycZc5VjdCVTmqYfcY1: { label: "Arthur Britto — XRPL Co-Creator",   type: "founder" },
  rEb8TK3gBgk5auZkwc6sHnwrGVJH8DuaLh: { label: "Bitstamp XRP",    type: "exchange" },
  rMQ98K56yXJbDGv49ZSmW51sLn94Xe1mu1: { label: "Bitstamp XRP 2",  type: "exchange" },
  rDsbeomae4FXwgQTJp9Rs64Qg9vDiTCdBv: { label: "Bitstamp Exchange", type: "exchange" },
  rG6FZ31hDHN1K5Dkbma3PSB5uVCuVVRzfn: { label: "Bitfinex XRP",    type: "exchange" },
  rBndiPPKs9k5rjBb7HsEiqXKVZ9MMhGmhM: { label: "Kraken XRP",      type: "exchange" },
  rKmBGxocj9Abgy25J51Mk1iqFzW9aVF9Tc: { label: "Kraken XRP 2",    type: "exchange" },
  rLHzPsX6oXkzU2qL12kHCH8G8cnZv1rBJh: { label: "Kraken XRP 3",    type: "exchange" },
  rBx5RkPh2KR3JqBtZWoU25ZxGHaJzYMD84: { label: "Kraken XRP 4",    type: "exchange" },
  rBKPS4oLSaV2KVVuHH8EpQqMGgWj5U37h4: { label: "Bittrex XRP",     type: "exchange" },
  rPJwJUmDMijFtBi3GnW2VRFTCEpFCJCGPA: { label: "Poloniex XRP",    type: "exchange" },
  rrpNnNLKrartuEqfJGpqyDwPj1BBN1ybNn: { label: "Binance XRP",      type: "exchange" },
  rBttd61FExHC68vsZ8dqmS3DfjFEceA1A:  { label: "Binance XRP 2",   type: "exchange" },
  rDAE53VfMvftPB4ogpWGWvzkQxfht6JPxr: { label: "Binance Exchange",  type: "exchange" },
  rfQ9EcLkU6WnNmkS3EwUkFeXeN47Rk8Cvi: { label: "Binance Exchange",  type: "exchange" },
  rBtttd61FExHC68vsZ8dqmS3DfjFEceA1A: { label: "Binance Exchange",  type: "exchange" },
  rPCpZwPKogNodbjRxGDnefVXu9Q9R4PN4Q: { label: "Binance Exchange",  type: "exchange" },
  r9c6A65SmhhZALrkMTpqc9X3kGjv5gtNNk: { label: "Ripple",            type: "exchange" },
  rsbfd5ZYWqy6XXf6hndPbRjDAzfmWc1CeQ: { label: "Luna Global",       type: "exchange" },
  rBgnUKAEiFhCRLPoYNPPe3JUWayRjP6Ayg: { label: "Coinspot Exchange", type: "exchange" },
  rHXuEaRYnnJom5RS9K5pMrfFSmXwcjALBF: { label: "Coinbase XRP",     type: "exchange" },
  rw2ciyaNshpHe7bCHo4bRWq6pqqynnWKQg: { label: "Coinbase XRP 2",  type: "exchange" },
  rwnYLUsoBQX3ECa1A5bSKLdbPoHKnqf63J: { label: "Coinbase XRP 3",  type: "exchange" },
  r4sRyacXpbh4HbagmgfoQq8Q3j8ZJzbZ1J: { label: "Coinbase XRP 4",  type: "exchange" },
  rwpTh9DDa52XkM9nTKp2QrJuCGV5d1mQVP: { label: "Coinbase XRP 5",  type: "exchange" },
  rwpTh9DDa52XKm9nTKp2QrJuCGV5d1mQVP: { label: "Coinbase XRP 5b", type: "exchange" },
  r3YsZdkznVzYBv141qhwXHDWoPUXLdksNw: { label: "Coinbase XRP 6",  type: "exchange" },
  rLNaPoKeeBjZe2qs6x52yVPZpZ8td4dc6w: { label: "Coinbase XRP 7",  type: "exchange" },
  rUjfTQpvBr6wsGGxMw6sRmRQGG76nvp8Ln: { label: "Coinbase XRP 8",  type: "exchange" },
  r3wcwBpVCGcKu7TzY1ta2kQiJ5UHECDFZS: { label: "Coinbase XRP 9",  type: "exchange" },
  rayCEqaUBryJSWxf3BEc1Y4EMRYLuK3aJ8: { label: "Coinbase XRP 10", type: "exchange" },
  r7BspkyEZqKZ88SovgxZtsGGxoVoPodJf:  { label: "Coinbase XRP 11", type: "exchange" },
  rGFNBYb9548VqJojTDoDDYoJBEpvmVywSV: { label: "Coinbase XRP 12", type: "exchange" },
  rQGXuQCZH27mj7wcikYrKCEbAh5xfenwb8: { label: "Coinbase XRP 13", type: "exchange" },
  r4k4U4Hge3mLfyURfGu3pJFeNTWXduBha2: { label: "Coinbase XRP 14", type: "exchange" },
  rGvmcMqafc5HAdyhaoQCG4tpBZKdYLT3cH: { label: "Coinbase XRP 15", type: "exchange" },
  rHRHwHJHHzQ328c33wCimeXqCgyDoxLXjF: { label: "Coinbase XRP 16", type: "exchange" },
  rJb5KsHsDHF1YS5B5DU6QCkH5NsPaKQTcy: { label: "OKX XRP",         type: "exchange" },
  rUzWJkXyEtT8ekSSxkBYPqCvHpngcy6Fks: { label: "OKX XRP 2",       type: "exchange" },
  rPVMhWBsfF9iMXYj3aAzJVkPDTFNSyWdKy: { label: "Huobi XRP",       type: "exchange" },
  rHpSX1VNr3tdsDvvSAFKMPXzTZ3KPAJQ2E: { label: "HTX XRP",         type: "exchange" },
  rDm691szLmEqpUbXmgnj159Ffpp9PntHwj: { label: "HTX XRP 2",       type: "exchange" },
  r4FuDeXifHAZork5KcEQKKBqmBWPGiFmJC: { label: "Uphold XRP",      type: "exchange" },
  rMdG3ju8pgyVh29ELPWaDuA74CpWW6Fxns: { label: "Uphold XRP 2",    type: "exchange" },
  rsXT3AQqhHDusFs3nQQuwcA1yXRLZJAXKw: { label: "Uphold XRP 3",    type: "exchange" },
  raBQUYdAhnnojJQ6Xi3eXztZ74ot24RDq1: { label: "Gemini XRP",      type: "exchange" },
  rKNwXQh9GMjaU8uTqKLECsqyib47g5dMvo: { label: "Crypto.com XRP",  type: "exchange" },
  rEvwSpejhGTbdAXbxRTpGAzPBQKRZxN5s:  { label: "eToro XRP",           type: "exchange" },
  r4DymtkgUAH2wqRxVfdd3Xtswzim6eC6c5: { label: "Crypto.com XRP",      type: "exchange" },
  rnJrjec2vrTJAAQUTMTjj7U6xdXrk9N4mT: { label: "Kraken XRP",          type: "exchange" },
  rBEc94rUFfLfTDwwGN7rQGBHc883c2OHx:  { label: "Uphold XRP",       type: "exchange" },
  rU5ACGLKbhPQB92GZhT5UV22NHeVrEGuU6: { label: "Coinbase XRP (Cold)", type: "exchange" },
  rEvuKRoEbZSbm5k5Qe5eTD9BixZXsfkxHf: { label: "Kraken XRP",       type: "exchange" },
  rGFuMiw48HdbnrUbkRToR1yMBZkjbqvUhQ: { label: "MEXC XRP",        type: "exchange" },
  rHcFoo6a9qT5NHiVn1THwuhbekk8ovtWiL: { label: "Bybit XRP",       type: "exchange" },
  rNxp4h8apvRis6mJf9Sh8C6iRxfrDWN7AV: { label: "KuCoin XRP",      type: "exchange" },
  rGsxGQNdaDyFhZQ5JqDGPkT3VGFFexCaM3: { label: "Gate.io XRP",     type: "exchange" },
  rGmP2iRHqoYkFXF3HqrZEGZVXiqBGKcZmz: { label: "Gate.io XRP 2",   type: "exchange" },
  rMJXDzU1N9ZSDzPF7s1i2GGKyjM2wB3iom: { label: "Robinhood XRP",   type: "exchange" },
  rN7n3473SaZBCG4dFL75EpTSMBKmFVBQBh: { label: "Bitget XRP",           type: "exchange" },
  rBWpYJhuJWBPakzJ4kYQqHShSkkF3rgeD:  { label: "Cobo Custody XRP",     type: "exchange" },
  rQrgppDZMMKeq1x9gDuoytWeRLmLfXYV3q: { label: "Union Chain XRP",      type: "exchange" },
  rMxCKbEDwqr76QuheSUMdEGf4B9xJ8m5De: { label: "Ripple RLUSD Issuer",  type: "exchange" },
  rwPJqrGioKpieFx3MsbiySfrrFqt2PzUDN: { label: "Coinbase",             type: "exchange" },
  rUrriLdQ4q6fPbjiyo5zGHY5NFdUzJr13TM: { label: "Coinbase",            type: "exchange" },
  rDdkHrHMqFPFqUew2WCxPhS5JR6Gmh755RS: { label: "Coinbase",            type: "exchange" },
  rGwCvT1vFDxsj6WWV55jBYxzXduyiPnVwZ: { label: "Coinbase",             type: "exchange" },
  rD2yXXhio7QdkQ2Nx59MkRCw1w7Mq3NBSa: { label: "Coinbase",             type: "exchange" },
  rLWajfrUR6htxdzyl7XAZ7TS51Dds8XTT8: { label: "Coinbase",             type: "exchange" },
  rBDSYHx4xKZvWvBR9kGeVnWEFEb8ir7Gfm: { label: "Coinbase",             type: "exchange" },
  rHo7znRYDpeBJoMzcMMZfV6r8ML4hPeCDR: { label: "Coinbase",             type: "exchange" },
  rGct8a15zHDuCobXWMja4FNI47TcJ6DoB5: { label: "Coinbase",             type: "exchange" },
  rUs9dv67xMdFs2mdtCnK7tKHbtcJvy7Pu9: { label: "Coinbase",             type: "exchange" },
  rXypYS18H9sh9v3582dmZuuw18hgWEVFg: { label: "Coinbase",               type: "exchange" },
  rMvaKYzHpaZGUUSRX1iJbnqKV2iG9gmjTH: { label: "Coinbase",             type: "exchange" },
  rsZ1kdivRkXwqY4Ws69HeRRGjgJtmaqKaR: { label: "Coinbase",             type: "exchange" },
  rpyLCHeFs897rYKTMAzSRKrMGhRK6GUrri: { label: "Coinbase",             type: "exchange" },
  rDfKzRSdXacYfFbVLfi7xBLFRXkCyNvMme: { label: "Coinbase",             type: "exchange" },
  r4Gyb9xhG4iLrsR6Ac9dcHTjZLekJcXW2V: { label: "Coinbase",             type: "exchange" },
  rLWDu4tEhtBaLDYNtjALT21hdhwX8f9vNK: { label: "Coinbase",             type: "exchange" },
  rnjXFUfKCtBBYDTK1GCYbJL6V9WCqRGdEr: { label: "Coinbase",             type: "exchange" },
  rwPet7Vu3yaBuwMgFYG521mSat1qkkwsLE: { label: "Coinbase",              type: "exchange" },
  r4VDPS5yatqpkdBoJxNWh3TWWXTmR62r: { label: "Coinbase",                type: "exchange" },
  rpMaupvHx4jcfgpd58VdLVR7g6XjhnUtXg: { label: "Coinbase",             type: "exchange" },
  rNCfaHmv2QLs6du9r25KTsZpdsyWQAquTd: { label: "Coinbase",             type: "exchange" },
  rKzfrk1RsUxWmHimWyNwk8AoWHoFneu4m: { label: "Uphold",                type: "exchange" },
  rBEc94rUFfLfTDwwGN7rQGBHc883c2QHhx: { label: "Uphold",               type: "exchange" },
  rsX8cp4aj9grKVD9V1K2ouUbxgYsigUtBL: { label: "Uphold",               type: "exchange" },
  rEvuKRoEBzSbM5k5Qe5tD9BixZXsfxkHf: { label: "Kraken",                type: "exchange" },
  rUeDDFNp2q7Ymvyv75hFGC8DAcygVyJbNF: { label: "Kraken",                type: "exchange" },
  rKV8HEL3vLc6q9waTJcewdRdSFyx67QFb: { label: "Crypto.com",            type: "exchange" },
  rJmXYcKCGJSayp4sAdp6Eo4CdSFtDVv7WG: { label: "Crypto.com",           type: "exchange" },
  rEeWEp88cpKUddkKk37B2EZeiHGBiBXY3: { label: "Binance.US",             type: "exchange" },
  rMvYS27SYs5dXfdsUgpvv1CSrPsCz7ePF5: { label: "Binance.US",           type: "exchange" },
  // ── XRP Founders (additional addresses) ────────────────────────────────────
  rhmkfhYZY3XJgGTcGxLAKuEoph49bmMqbb: { label: "CHRIS LARSEN",  type: "founder" },
  rhREXVHV938ToGkdJQ9NCYEY4x8kSEtjna: { label: "CHRIS LARSEN",  type: "founder" },
  rNLrQvgfLZNLqcqjAAQYBUNBSC5dVkiDXw: { label: "CHRIS LARSEN",  type: "founder" },
  rHtLaipqqfbhgMSHkF1YcuWaivvgRH851o: { label: "CHRIS LARSEN",  type: "founder" },
  r476293LUcDqtjiSGJ5Dh44J1xBCDWeX3:  { label: "CHRIS LARSEN",  type: "founder" },
  r44CNwMWyJf4MEA1eHVMLPTkZ1LSv4Bzrv: { label: "CHRIS LARSEN",  type: "founder" },
  ragKXjY7cBTXUus32sYHZVfkY46Nt2Q829: { label: "AH BRITTO",     type: "founder" },
  rG2eEaeiJou6cVQ3KtX7XMNwGhuW99xmHP: { label: "AH BRITTO",     type: "founder" },
  rsXNUCJkXeyFuGHyfRnuWPita2ns32upBD: { label: "AH BRITTO",     type: "founder" },
  rQKZSMgmBJvv3FvWj1vuGjUXnegTqJc25z: { label: "AH BRITTO",     type: "founder" },
  // ── XRP Nicknames ──────────────────────────────────────────────────────────
  "rрiXNS2rfFNy1xYpToanshnRPYhQ2Mydph": { label: "MUSK",          type: "founder" },
  rnso4QWkGuF9XgsiTBHawQQmr27KDwGVwm:   { label: "THIEL",         type: "founder" },
  rpdfM4KARNqE8bTZkBTgv1kCM4F3GPhu5G:   { label: "ISSAC NEWTON",  type: "founder" },
  rNsWgZX6DjAnKGE2pnCZqD6kFpXwvC4jKp:   { label: "ASIMOV",        type: "founder" },
  rG7Q8kohMLTDo47BAbNiR8kt6k8WifodbX:   { label: "ANDREESSEN",    type: "founder" },
  // ── XRP Exchanges (additional) ─────────────────────────────────────────────
  r4DymtkgUAh2wqRxVfdd3Xtswzim6eC6c5: { label: "Crypto.com",        type: "exchange" },
  r4DbbWjsZQ2hCcxmjncr7MRjpXTBPckGa9: { label: "Bybit",             type: "exchange" },
  r3ZVNKgkkT3A7hbEZ8HxnNnLDCCmZiZECV: { label: "Binance US",        type: "exchange" },
  rDKw32dPXHfoeGoD3kVtm76ia1WbxYtU7D: { label: "Coinone",           type: "exchange" },
  rhuCPEoLFYbpbwyhXioSumPKrnfCi3AXJZ: { label: "Coinone",           type: "exchange" },
  rhSTwqSK13zdRmzHMZZP8i7DnuG27pwX76: { label: "Bitstamp",          type: "exchange" },
  rs8ZPbYqgecRcDzQpJYAMhSxSi5htsjnza: { label: "Binance",           type: "exchange" },
  rP3mUZyCDzZkTSd1VHoBbFt8HGm8fyq8qV: { label: "Binance",           type: "exchange" },
  rDecw8UhrZZUiaWc91e571b3TL41MUioh7: { label: "Binance",           type: "exchange" },
  rEbXa31msPbPDZgmLMKH7CaKaf7VipoLBo: { label: "Binance",           type: "exchange" },
  rPJ5GFpyDLv7gqeB1uZVUBwDwi41kaXN5A: { label: "Binance",           type: "exchange" },
  rpVu7CQHTGqWDvBzm3TB2drmZBmh6jGNz4: { label: "Binance",           type: "exchange" },
  rKuP5k67YtHzsCmSQp7votF7u4afp4uNcm: { label: "Binance",           type: "exchange" },
  rPz2qA93PeRCyHyFCqyNggnyycJR1N4iNf: { label: "Binance",           type: "exchange" },
  rDNuKeiwTHWRCyBrh1aQUthLPkCUTxhz2W: { label: "Binance",           type: "exchange" },
  rNU4eAowPuixS5ZCWaRL72UUeKgxcKExpK: { label: "Binance",           type: "exchange" },
  rhWj9gaovwu2hZxYW7p388P8GRbuXFLQkK: { label: "Binance",           type: "exchange" },
  rarG6FaeYhnzSKSS5EEPofo4gFsPn2bZKk: { label: "Binance",           type: "exchange" },
  rwkbXMJQLQhVhcjZnnHV4zu39N7WcQXQKX: { label: "Binance",           type: "exchange" },
  rwTTsHVUDF8Ub2nzV2oAeWxfJzUvobXLEf: { label: "Bybit",             type: "exchange" },
  rMvCasZ9cohYrSZRNYPTZfoaaSUQMfgQ8G: { label: "Bybit",             type: "exchange" },
  rJn2zAPdFA193sixJwuFixRkYDUtx3apQh: { label: "Bybit",             type: "exchange" },
  rn7d8bZhsdz9ecf586XsvbmVePfxYGrs34: { label: "Coinbase",          type: "exchange" },
  rPyCQm8E5j78PDbrfKF24fRC7qUAk1kDMZ: { label: "Bitthumb",          type: "exchange" },
  rw3fRcmn5PJyPKuvtAwHDSpEqoW2JKmKbu: { label: "Bitthumb",          type: "exchange" },
  rDxJNbV23mu9xsWoQHoBqZQvc77YcbJXwb: { label: "Upbit",             type: "exchange" },
  rfL1mn4VTCoHdhHhHMwqpShCFUaDBRk6Z5: { label: "Upbit",             type: "exchange" },
  rwa7YXssGVAL9yPKw6QJtCen2UqZbRQqpM: { label: "Upbit",             type: "exchange" },
  rNcAdhSLXBrJ3aZUq22HaNtNEPpB5fR8Ri: { label: "Upbit",             type: "exchange" },
  r4G689g4KePYLKkyyumM1iUppTP4nhZwVC: { label: "Upbit",             type: "exchange" },
  rJo4m69u9Wd1F8fN2RbgAsJEF6a4hW1nSi: { label: "Upbit",             type: "exchange" },
  rLgn612WAgRoZ285YmsQ4t7kb8Ui3csdoU: { label: "Upbit",             type: "exchange" },
  rs48xReB6gjKtTnTfii93iwUhjhTJsW78B: { label: "Upbit",             type: "exchange" },
  rJWbw1u3oDDRcYLFqiWFjhGWRKVcBAWdgp: { label: "Upbit",             type: "exchange" },
  rMNUAfSz2spLEbaBwPnGtxTzZCajJifnzH: { label: "Upbit",             type: "exchange" },
  rErKXcbZj9BKEMih6eH6ExvBoHn9XLnTWe: { label: "Uphold",            type: "exchange" },
  rEvwSpejhGTbdAXbxRTpGAzPBQkBRZxN5s: { label: "eToro",             type: "exchange" },
  rhWVCsCXrkwTeLBg6DyDr7abDaHz3zAKmn: { label: "Bitflyer",          type: "exchange" },
  rsT3yYMkuicxW1hYsy787mg5XHhkz2uQRk: { label: "Evernorth",         type: "exchange" },
  rKXXrAgpkHQN8m4HxAQCYmDCPPUByc9mVq: { label: "Evernorth",         type: "exchange" },
  rE3hWEGquaixF2XwirNbA1ds4m55LxNZPk: { label: "Bitfinex",          type: "exchange" },
  rLW9gnQo7BQhU6igk5keqYnH3TVrCxGRzm: { label: "Bitfinex",          type: "exchange" },
  rNu9U5sSouNoFunHp9e9trsLV6pvsSf54z: { label: "Gate.io",           type: "exchange" },
  rHcFoo6a9qT5NHiVn1THQRhsEGcxtYCV4d: { label: "Gate.io",           type: "exchange" },
  rLzxZuZuAHM7k3FzfmhGkXVwScM4QSxoY7: { label: "Gate.io",           type: "exchange" },
  rNnWmrc1EtNRe5SEQEs9pFibcjhpvAiVKF: { label: "Gate.io",           type: "exchange" },
  rPEPYN8sHU3cytBwVm69qPbVztaoj7wNf:  { label: "Mercado Bitcoin",   type: "exchange" },
  rLSn6Z3T8uCxbcd1oxwfGQN1Fdn5CyGujK: { label: "Bitso",             type: "exchange" },
  rPBMDP7CGiKzMvPx6SsCGgeDsrsUyv1K1b: { label: "Yobit",             type: "exchange" },
  rpQATJWPPdNMxVCTQDYcnRNwtFDnanT3nk: { label: "Bitunix",           type: "exchange" },
  rQUmgHMWTXGpFqcVEo2qtHY7xvhk4V4Bua: { label: "CoinDCX",          type: "exchange" },
  rs2dgzYeqYqsk8bvkQR5YPyqsXYcA24MP2: { label: "MEXC",              type: "exchange" },
  r9FNc9txxrB98DizMkhQBj3hgKQCbF1bGA: { label: "Zebpay",            type: "exchange" },
  rLMAAuqJowC5yMccaPnappeLM8vDfdiDTg: { label: "Phemex",            type: "exchange" },
  rE3Cc3i6163Qzo7oc6avFQAxQE4gyCWhGP: { label: "Bitkub",            type: "exchange" },
  // ── XRP Ripple Official (additional) ───────────────────────────────────────
  rJqiMb94hyz41SBTNr2AyPNW8AzELa8nE:  { label: "Ripple",            type: "official" },
  rfRms8V4gNsJDdg4VtWrjxsgrQPQ9ZF8n8: { label: "Ripple",            type: "official" },
  rhtufNsYfrozs4GvSq4HMYcR9y3dg8FWdC: { label: "Ripple",            type: "official" },
  rhyp1uMC9Xyj3Px8amUH3xVv6tbjYJkojs: { label: "Ripple",            type: "official" },
  r3F5NsyiGwVYs2Rs3cCcrVw4t5wZP2ZxRr: { label: "Ripple",            type: "official" },
  rBg2FuZT91C52Nny68houguJ4vt5x1o91m: { label: "Ripple",            type: "official" },
  // ── XRP Labels (May 29 2026) ───────────────────────────────────────────────
  raorBmbzraA6TooLQ6kGWRSx1HQq7d4gzS: { label: "CHRIS LARSEN",      type: "founder"  },
  r4MoybfgCHDoUByYyMejimaX6a8CEtWtav: { label: "Ripple",            type: "official" },
  rhbWRsNE4v4neB5KvscrwCvcETv7c1vDJf: { label: "Ripple",            type: "official" },
  rJAMeVrUyezc5TVrzwq7HUM4VzW4xUYZzR: { label: "Ripple",            type: "official" },
  raQwCVAJVqjrVm1Nj5SFRcX8i22BhdC9WA: { label: "UPBIT",             type: "exchange" },
  r3zUhJWabAMMLT5n631r2wDh9RP3dN1bRy: { label: "BTC MARKETS",       type: "exchange" },
  rsdvR9WZzKszBogBJrpLPE64WWyEW4ffzS: { label: "ETORO",             type: "exchange" },
  rUTyLdTBDcajmCBZYnRVmHTUAMuCzbNgnC: { label: "BITLO",             type: "exchange" },
  rGDreBvnHrX1get7na3J4oowN19ny4GzFn: { label: "BITGET GLOBAL",     type: "exchange" },
  rE1sdh25BJQ3qFwngiTBwaq3zPGGYcrjp1: { label: "CEX.IO",            type: "exchange" },
  rLpvuHZFE46NUyZH5XaMvmYRJZF7aory7t: { label: "KUCOIN",            type: "exchange" },
  rsrx4uxk8s9RyHkHDTapFb3SFv1y4iVR5J: { label: "NBX",               type: "exchange" },
  r4hYwnBsNH764iTfhRSopu4M3Ct5gMkCGD: { label: "ZB",                type: "exchange" },
  rnW8je5SsuFjkMSWkgfXvqZH3gLTpXxfFH: { label: "MERCADO BITCOIN",   type: "exchange" },
  rEAKseZ7yNgaDuxH74PkqB12cVWohpi7R6: { label: "ROBINHOOD",         type: "exchange" },
  rUBPgv8hVMBrFMeNYBPMUwiTwWiEom3GvQ: { label: "SUNCRYPTO",         type: "exchange" },
  rnBKit9uv2L3pH8HQwPKpDJhhwACKct3ro: { label: "WHITEBIT HOT WALLET", type: "exchange" },
  r97KeayHuEsDwyU1yPBVtMLLoQr79QcRFe: { label: "BITBANK",           type: "exchange" },
  rwSdwXsQVCjYXUyempsGxk1Sgws6perYZL: { label: "GOPAX",             type: "exchange" },
  r3S8AV7DQ6URd9qhKkDc2vD6XCaNU34328: { label: "NEXO",              type: "exchange" },
  rDseVXFK1SkWhFH65cqAxf3HmvHCF6b94t: { label: "VALR",              type: "exchange" },
  rNBYQJfRfUtLgsbmR3PPBvnDircwfWpeWh: { label: "XT",                type: "exchange" },
  rhub8VRN55s94qWKDv6jmDy1pUykJzF3wq: { label: "GATEHUB",           type: "exchange" },
  rwBWAoDdybkxHUixvSUCqdJdz8dQs2vhrm: { label: "SHUFFLE",           type: "exchange" },
  rLrbZMJDdL8eQd7HsW314bCtvE16LTLYkM: { label: "COINMOTION",        type: "exchange" },
  rPSJ1TdurLDkgiptGUgvGii72tWto2cQBA: { label: "BITFOREX",          type: "exchange" },
  raTjYCE2ForijAiCsjywXQ3WTq58U42gyq: { label: "COINCOLA",          type: "exchange" },
  r5NACh63T67aZyfGCGJZCvWrVgxT51SXK:  { label: "COINCOLA",          type: "exchange" },
  rPm7zTAaENqWUdJ8YoWYPgtAC9ZdrF7rhL: { label: "COINCOLA",          type: "exchange" },
  r5VodfjXnVYXC4MQ5kB32NeiYpb3kn8s2:  { label: "ZEBPAY",            type: "exchange" },
  rKBRWUTreGNU9d3pL2gYUo23jn4UdKiAoS: { label: "BLOFIN",            type: "exchange" },
  rLkhKQPc2Jrik1j5PSfBqoDDUTq9oX5mz1: { label: "FOXBIT",            type: "exchange" },
  rvYAfWj5gh67oV6fW32ZzP3Aw4Eubs59B:  { label: "BITSTAMP",          type: "exchange" },
  rw9isBiVw3M2dt2KKHePVuUUmHxix9VY35: { label: "COBO CUSTODY",      type: "exchange" },
  rPotpackAV39ysG1cyprYDa6ambUAPtKHk: { label: "ROOT NETWORK",      type: "exchange" },
  rNgm5vZY4WSTjiuNPLLB7Se82GEeYCvK9C: { label: "WOOX",              type: "exchange" },
  rpz5zUKWWXGDB1Gc4jZEKv6LsVuBHsbNhE: { label: "BCGAME",            type: "exchange" },
  rNwUcrxYiTZ5cRAuEQVuQGDb7miaPRBVAd: { label: "COINS.PH",          type: "exchange" },
  rfQ3a8airxdz9bumRZDMRRTbGVtehWAxHd: { label: "AOFEX",             type: "exchange" },
  r9R8jciZBYGq32DxxQrBPi5ysZm67iQitH: { label: "NEAR INTENTS",      type: "exchange" },
  r4ep6pSY9JhMhLHGFb5GtVabzS1KvihiZP: { label: "COINHAKO",          type: "exchange" },
  rMZdHB6uHvAEPzzKdsWYyhgyLkhFNjuwih: { label: "MAX EXCHANGE",      type: "exchange" },
  rJJqEefks9dewe9W7Q2g7yKFFT1zsPxw8J: { label: "FIRI",              type: "exchange" },
  rFuckiRGCTerroristsNoBiTEXypBrmUM:  { label: "NOBITEX HACK",      type: "exchange" },
  rGmWNTmi6STmrHKk5padm7jM8fLLQp2QBr: { label: "BTSE",              type: "exchange" },
  rCdg3wqHgBFEuyysHcx25HGPpBWPY4VfD:  { label: "WAZIRX",            type: "exchange" },
  rLgNzfkph2rr73yQgapCh2AAEFw4cXV9yE: { label: "CHIPS.GG",          type: "exchange" },
  rpY7bZBkA98P8zds5LdBktAKj9ifekPdkE: { label: "BITFLYER",          type: "exchange" },
  rNQEMJA4PsoSrZRn9J6RajAYhcDzzhf8ok: { label: "COINCHECK",         type: "exchange" },
  rUudTR36BKRQtD64y6jqp5jTq159V1cRUS: { label: "COINCASINO",        type: "exchange" },
  rKwWsi1XWCevQmVL9VhPD8DuYF4dobFdoT: { label: "BINGX",             type: "exchange" },
  rNUyxNugxv67vhQZZCif2Ru1Hb4APNmwUS: { label: "HITBTC",            type: "exchange" },
  rJPA3zznzaDowTYhhfTVzX6XhR3Kn81JJc: { label: "COINMENA",          type: "exchange" },
  rGpxjNG7ovJTqNbahA6obUMyEfi7AnPax4: { label: "BINANCE",           type: "exchange" },
  rfKsmLP6sTfVGDvga6rW6XbmSFUzc3G9f3: { label: "BITRUE",            type: "exchange" },
  rKvAtitwmaYVFG8GwDmUSyqo71YMbeBSwn: { label: "PDAX",              type: "exchange" },
  rfVgMZSiGtcDxSETPi7TWbkY7drNUbSXSJ: { label: "BITBNS",            type: "exchange" },
  rL7ehXUB6Xhyakbz7SZ6tbMwNhekeFEMdb: { label: "HOTCOIN GLOBAL",    type: "exchange" },
  raV5bXp9hNe5G4YFxLDSGHExL3bVyYmwZ9: { label: "DUEL",              type: "exchange" },
  // ── XLM (Stellar) ──────────────────────────────────────────────────────────
  GDDEAH46MNFO6JD7NTQ5FWJBC4ZSA47YEK3RKFHQWADYTS6NDVD5NZN: { label: "Binance XLM",     type: "exchange" },
  GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN: { label: "Binance XLM 2",   type: "exchange" },
  GAAZI4TCR3TY5OJHCTJC2A4QSY6CJWJH5IAJTGKIN2ER7LBNVKOCCWN: { label: "Coinbase XLM",    type: "exchange" },
  GA3CINHTGMUMRVPJPVHYJWQJ2EF7EX2PCRAFN4H4ZPO77WB6RHXEHMJT: { label: "Coinbase XLM 2", type: "exchange" },
  GDQP2KPQGKIHYJGXNUIYOMHARUARCA7DJT5FO2FFOOKY3B2WSQHG4W37: { label: "Coinbase XLM 3", type: "exchange" },
  GDT7ARDYZRBXXYOCSQ3MUMISTITSSRWZI6KR2A5L5Q3KB4QIZHGYMTIH: { label: "Bybit XLM 3",     type: "exchange" },
  GCGMJ63NTBSQKW7OEQ3J2RZH6PYXSTEUK4TVE35IPXLB7XWNI2PUDCY6: { label: "Uphold XLM 6",    type: "exchange" },
  GDUQXQAR4ECNAYCTGZAS4TH4KJJIZDLXPR5V2YYRFRGGQ3LTXBFTBVW6: { label: "Coinbase XLM 6", type: "exchange" },
  GDF4UGQSY6VHWN7T4XJEZ6WYJEREMZYLNYZ5CCKYVS3V3MNYIBMTB354: { label: "Coinbase XLM 7",  type: "exchange" },
  GCIL6JNOVODHIZGZBYKWSRDRYUVXWF5ZEVMISJQQJBQRMF5FAH6YOD7U: { label: "Coinbase XLM 8",  type: "exchange" },
  GCVEON7LARMBNCCJCYLXO4FNFENL6R74NWCC2V6YZN5Z6L5W4GUZDMWC: { label: "Coinbase XLM 9",  type: "exchange" },
  GDS2WFLIJID6BDM64FGUD7MNOVZUEWHJ5VJPO2GQ32KOZCYIYIRIQTG6: { label: "Coinbase XLM 10", type: "exchange" },
  GDZHDOITT5W2S35LVJZRLUAUXLU7UEDEAN4R7O4VA5FFGKG7RHC4NPSC: { label: "Coinbase XLM 11", type: "exchange" },
  GBRSO2HPPEHCZASU3W3ZDMS7ISWPWJZB7IJ4JPFLZMKN7VOTWUCT3SL6: { label: "Coinbase XLM 12", type: "exchange" },
  GB5FUSCVVV7ZLKJVL7FRCSBQHZXYLMSWWXXYC7NH35GV57S5XWKEVA4V: { label: "Coinbase XLM 13", type: "exchange" },
  GANZM2JP5ZFHI2UZCFTK5OAPLJJVEWRKCLGJD5RTAI7WRTHX6OB6O6CC: { label: "Coinbase XLM 14", type: "exchange" },
  GDTYD6BWWZIOHD2PPLTFQYW3KVTT5YEF2EVWMTUJTVGQ4U2UBKFHHVYN: { label: "Coinbase XLM 15", type: "exchange" },
  GA5XIGA5C7QTPTWXQHY6T19HSGZDQXPKFBM7NZQND4KHZFVU5HY6KKK: { label: "Kraken XLM",      type: "exchange" },
  GA5XIGA5C7QTPTWXQHY6MCJRMTRZDOSHR6EFIBNDQTCQHG262N4GGKTM: { label: "Kraken XLM 2",    type: "exchange" },
  GAP5LETOV6YIE62YAM56STDANPRDO7ZFDBGSNHJQIYGGKSMOZAHOOS2S: { label: "Bitstamp XLM",     type: "exchange" },
  GBVOL67TMUQBGL4TZYNMY3ZQ5WGQYFPFD5VJRWXR72VA33VFNL225PL: { label: "Huobi XLM",        type: "exchange" },
  GBZ35ZJRIKJGYH5PBKLKOZ5L5GQXCDIARHV3LIJEV7MIRUCQIRLVVB6: { label: "Bitfinex XLM",     type: "exchange" },
  GCGNWKCJ3KHRLPM3TM6N7D3W5YKDJFL6A2YCXFXNMRTZ4Q66MEMGHMN: { label: "OKX XLM",          type: "exchange" },
  GDKIJJIKXLOM2NRMPNQZUUYK24ZPVFC6426GZAEP3KUK6KEJLACCWNMX: { label: "MEXC XLM",         type: "exchange" },
  GAHK7EEG2WWHVKDNT4CEQFZGKF2LGDSW2IVM4S5DP42RBW3K6BTODB4: { label: "Uphold XLM",       type: "exchange" },
  GBJDVTWUXRNDK35X7A6XYHB2XYXEM7XRH776KK6VYOYY5JL2PJCZPZ3O:  { label: "Uphold XLM 2",      type: "exchange" },
  GBJDVTTWUXRNDK35X7A6XYHB2XYXEM7XRH776KK6VYOYY5JL2PJCZPZ3O: { label: "Uphold XLM Cold",   type: "exchange" },
  GBW5AENWI5PFJRYEIAIRYDB62MVEHDYHEBXKFN3TI64RSL2L6GYOYFG4: { label: "Uphold XLM 3",    type: "exchange" },
  GDMKMOHKKYS4VTHBCH4TZXNFF7MK7KDA7IEZL6NB36JREVCRNYZJXPTA: { label: "Uphold XLM 4",    type: "exchange" },
  GBP32F37ZHXGSLOE4WAFCLNWQUMY4OUIAUGNBZUF4OD2BG6MS7WKRTSX: { label: "Uphold XLM 5",    type: "exchange" },
  GCNSGHUCG5VMGLT5RIYYZSO7VQULQKAJ62QA7EC7KH6X7HJR3BXCRRY: { label: "KuCoin XLM",       type: "exchange" },
  GBEZDAOKKUDLLNR4EGZFGLCDBQBQLQCQS72LKRNKRUAWPDBPXJVBJV74: { label: "KuCoin XLM 2",     type: "exchange" },
  GBUQWP3BOUZX34TOND2QV7QQ7K7VJTM6DBYRD3UI1FAB6B5OKKWKFKP: { label: "Bybit XLM",        type: "exchange" },
  GBDUXW4E5WRM5EM6UXBLE7Y5XGSXJX472BSSBPKFPQ3PJCJHRIA6SH4C: { label: "Bybit XLM 2",     type: "exchange" },
  GCEZWKCA5VLDNRLN3RPRJMRZOX3Z6G5CHCGCFY9QQGDPFHD1N0PQEN:   { label: "Gate.io XLM",     type: "exchange" },
  GBSTRUSD7IRX73RQZBL3RQUH6KS3O4NYFY3QCALDLZD77XMZOPWAVTUK: { label: "Crypto.com XLM",  type: "exchange" },
  GDKLYAQTME4MVGCVPQBXSXVMQKGRKDTNF7FIOAJQWNC4GQVPZARQKLE:  { label: "Bitget XLM",      type: "exchange" },
  GB2ES2N326MZK4EGJBKN3ZARCQ5RTFQSAWIJAAKFVIIIJSCC35TXIMLB: { label: "Robinhood XLM",    type: "exchange" },
  GB67TJFJO3GUA432EJ4JTODHFYSBTM44P4XQCDOFTXJNNPV2UKUJYVBF: { label: "Crypto.com",        type: "exchange" },
  GBF6SZEZ4AJY7BCBUV3ZYJ3Q27YMO4NJU6IZQP7ODY47MPVFWCO24SNW: { label: "Blockchain.com",    type: "exchange" },
  GARAR5QR7WRL24MQMSO4INWV7C5SE4EE2YVXTLD6ORONYFHSUAGZYSLN: { label: "Blockchain.com",          type: "exchange" },
  GBBALM76B5OUPOZCMFCNT5PVIFV3WTUYX3VVGC7FMN4ZPQLGCG2C4X3D: { label: "Kraken",                 type: "exchange" },
  GBXCM6MHKWZR7DYIBHZZAXXV6CYTGAROIXISAW3PQM7L3J7LTY5ORHHO: { label: "Kraken Cold Storage Wallet", type: "exchange" },
  GAQZU7Y7GB3E4XOA3ZXEZDOTIEIWQRYOAIVJ6STY2YTUQAGZL3GYJCXG: { label: "Kraken",                          type: "exchange" },
  GB6DQO6LDNGANIWKPA4E5Y6GRRFAP56Y2N3BIU54JQ3NT66L53RZCOM5: { label: "Kraken Cold Wallet",              type: "exchange" },
  GCDBX7GTQWJFTAJCJUGV4KXJZE6Q527YRLW75GYDJ2ODSVBOXCS4W7VS: { label: "MEXC",                            type: "exchange" },
  GAV6J5L473K4H6226IFNCAL7E5A2PR63YRCZDYJPTQH3S35YODXUUADV: { label: "Coinbase",                        type: "exchange" },
  GCR5X5Z7ETS4DLGPMBD6BGCBO5QZIL2O3CLKLGE6NEH5L55FDZFFLXFD: { label: "Coinbase",                        type: "exchange" },
  GCFN6RGQLZXK4XTIL524EXXAFHTAQMNEEI5P5VBWDME5JEXPNSVTIH3V: { label: "Coinbase",                        type: "exchange" },
  GCVLELPP5ZIDS6B4VFVZDNUEIGAYSRH3QHFJUO75XSCK3RSBY5FEXJ5N: { label: "Coinbase",                        type: "exchange" },
  GC5PFAXPL3BYIRHLMUFD3E353DINA6A52DXJIXLKQEVO2GA7WFWGWCFS: { label: "Coinbase",                        type: "exchange" },
  GBOYDKMW7MKSXV3UAPTEWVF3IX2EIJ4YOCEH6MOO5XTYOJKIH73YESVB: { label: "Coinbase",                        type: "exchange" },
  GB5CLRWUCBQ6DFK2LR5ZMWJ7QCVEB3XKMPTQUYCDIYB4DRZJBEW6M26D: { label: "Coinbase",                        type: "exchange" },
  GC23BCI644P66PPNRGRMKFFVQZZXE3CSCGMFIYFV5OW4WCPM2XICKWQZ: { label: "Coinbase",                        type: "exchange" },
  GCETHWILKC242GHWHCYAI4VAU4D4JZ637XHCAEABW6EVWWDILXNRMPJF: { label: "Binance",                         type: "exchange" },
  GC5LF63GRVIT5ZXXCXLPI3RX2YXKJQFZVBSAO6AUELN3YIMSWPD6Z6FH: { label: "Binance",                        type: "exchange" },
  GDHF3HIKWM5KJAVLZBSZWUFDOEOT7IBMY22UXG4QBE326O354INLPAND: { label: "Binance",                         type: "exchange" },
  GABFQIK63R2NETJM7T673EAMZN4RJLLGP3OFUEJU5SZVTGWUKULZJNL6: { label: "Binance",                        type: "exchange" },
  GBAIA5U6E3FSRUW55AXACIVGX2QR5JYAS74OWLED3S22EGXVYEHPLGPA: { label: "Binance",                         type: "exchange" },
  GDUST544JNATIO2VI3L7LXHVJFZXNYRWIKNMGRV2RZFZOOBE635SEI4C: { label: "Bitrue",                          type: "exchange" },
  GAWPTHY6233GRWZZ7JXDMVXDUDCVQVVQ2SXCSTG3R3CNP5LQPDAHNBKL: { label: "Bitfinex",                      type: "exchange" },
  GDBK3AHPQ7AO2U7JYEBFGJ2PBDVVFANHH4NQANDX6Q4GZ266WZ3IOIXN: { label: "Bitstamp",                      type: "exchange" },
  GA3NTBDIKQVDDM6ZDKJLGXJFESWJ636AGRIW34RH5WL24LUMX3YASKX2: { label: "Bitstamp",                       type: "exchange" },
  GBC6NRTTQLRCABQHIR5J4R4YDJWFWRAO4ZRQIM2SVI5GSIZ2HZ42RINW: { label: "Gate.io",                        type: "exchange" },
  GDBIXGZ3EKI3M4DBM65ADLHVNYIOG7JXGOHW5DHUZQAXPORY3QNO2PNY: { label: "ChangeNOW",                      type: "exchange" },
  GAJ4BSGJE6UQHZAZ5U5IUOABPDCYPKPS3RFS2NVNGFGFXGVQDLBQJW2P: { label: "KuCoin",                         type: "exchange" },
  GBGII2C7M4TOEC2MVAZYG3TRFM3ATCCEWANSN4Q3AHEX3NRKXJCVZDEV: { label: "OKEx",                            type: "exchange" },
  GB3RMPTL47E4ULVANHBNCXSXM2ZA5JFY5ISDRERPCXNJUDEO73QFZUNK: { label: "CEX.IO",                          type: "exchange" },
  GBW64JT24G4M2FTXVDKJOEQDSBLULXALEYY6VPEJIEN4NTFGMW35BPP5: { label: "Bitvavo",                        type: "exchange" },
  GAFK7XFZHMLSNV7OJTBO7BAIZA66X6QIBV5RMZZYXK4Q7ZSO52J5C3WQ: { label: "Centre",                         type: "exchange" },
  GAKGC35HMNB7A3Q2V5SQU6VJC2JFTZB6I7ZW77SJSMRCOX2ZFBGJOCHH: { label: "SDF Direct Development 2",       type: "genesis" },
  GATL3ETTZ3XDGFXX2ELPIKCZL7S5D2HY3VK4T7LRPD6DW5JOLAEZSZBA: { label: "SDF Direct Development",         type: "genesis" },
  GAPV2C4BTHXPL2IVYDXJ5PUU7Q3LAXU7OAQDP7KVYHLCNM2JTAJNOQQI: { label: "SDF Direct Development",        type: "genesis" },
  GB6NVEN5HSUBKMYCE5ZOWSK5K23TBWRUQLZY3KNMXUZ3AQ2ESC4MY4AQ: { label: "SDF Direct Development",          type: "genesis" },
  GDWXQOTIIDO2EUK4DIGIBLEHLME2IAJRNU6JDFS5B2ZTND65P7J36WQZ: { label: "SDF Product and Innovation Wallet", type: "genesis" },
  GDUY7J7A33TQWOSOQGDO776GGLM3UQERL4J3SPT56F6YS4ID7MLDERI4: { label: "SDF Growth Wallet",               type: "genesis" },
  GC3ITNZSVVPOWZ5BU7S64XKNI5VPTRSBEXXLS67V4K6LEUETWBMTE7IH: { label: "SDF Growth Wallet",               type: "genesis" },
  GCVJDBALC2RQFLD2HYGQGWNFZBCOD2CPOTN3LE7FWRZ44H2WRAVZLFCU: { label: "SDF Growth Wallet",               type: "genesis" },
  GCPWKVQNLDPD4RNP5CAXME4BEDTKSSYRR4MMEL4KG65NEGCOGNJW7QI2: { label: "SDF Product and Innovation Wallet", type: "genesis" },
  GAMGGUQKKJ637ILVDOSCT5X7HYSZDUPGXSUW67B2UKMG2HEN5TPWN3LQ: { label: "SDF Assets and Liquidity Wallet", type: "genesis" },
  GBEVKAYIPWC5AQT6D4N7FC3XGKRRBMPCAMTO3QZWMHHACLHTMAHAM2TP: { label: "SDF Growth Wallet",               type: "genesis" },
  GA6D2S6XDBT7WZIZNDGUBLXUGDAGLZGZ2SYT2JLXD4BB2W76XS66FZ2S: { label: "SDF Early Employee Grants Wallet", type: "genesis" },
  // ── HBAR (Hedera) ──────────────────────────────────────────────────────────
  "0.0.23576":   { label: "Binance HBAR",    type: "exchange" },
  "0.0.34140":   { label: "Binance HBAR 2",  type: "exchange" },
  "0.0.726513":  { label: "OKX HBAR",        type: "exchange" },
  "0.0.3664683": { label: "Coinbase HBAR",   type: "exchange" },
  "0.0.1649540": { label: "KuCoin HBAR",     type: "exchange" },
  "0.0.3014985": { label: "Bybit HBAR",      type: "exchange" },
  "0.0.2764670": { label: "Uphold HBAR",     type: "exchange" },
  "0.0.1067766": { label: "Uphold HBAR",     type: "exchange" },
  "0.0.1147432": { label: "Kraken HBAR",     type: "exchange" },
  "0.0.2574696": { label: "Gate.io HBAR",    type: "exchange" },
  "0.0.4352618": { label: "Bitget HBAR",     type: "exchange" },
  "0.0.496787":  { label: "Crypto.com HBAR", type: "exchange" },
  "0.0.611791":  { label: "Crypto.com HBAR", type: "exchange" },
  "0.0.1268012": { label: "Crypto.com HBAR", type: "exchange" },
  "0.0.6942669": { label: "Crypto.com HBAR", type: "exchange" },
  "0.0.1937593": { label: "Crypto.com HBAR", type: "exchange" },
  "0.0.1133968": { label: "Coinbase HBAR",   type: "exchange" },
  "0.0.1134089": { label: "Coinbase HBAR",   type: "exchange" },
  "0.0.1155594": { label: "Coinbase HBAR",   type: "exchange" },
  "0.0.1917742": { label: "Coinbase HBAR",   type: "exchange" },
  "0.0.615421":  { label: "Bybit HBAR",      type: "exchange" },
  "0.0.615422":  { label: "Bybit HBAR",      type: "exchange" },
  "0.0.285576":  { label: "Bitrue HBAR",     type: "exchange" },
  "0.0.3396073": { label: "HTX HBAR",        type: "exchange" },
  "0.0.38674":   { label: "Binance.US",      type: "exchange" },
  "0.0.38675":   { label: "Binance.US 2",    type: "exchange" },
  "0.0.956030":  { label: "Coinbase",        type: "exchange" },
  "0.0.106202":  { label: "Kraken",          type: "exchange" },
  "0.0.1042784": { label: "Robinhood",       type: "exchange" },
  "0.0.372889":  { label: "Bitstamp",        type: "exchange" },
  "0.0.5094":    { label: "Hedera Foundation",    type: "genesis" },
  "0.0.98":      { label: "Hedera Fee Collector",  type: "genesis" },
  "0.0.800":     { label: "Hedera Rewards",         type: "genesis" },
  "0.0.801":     { label: "Hedera Staking",          type: "genesis" },
  // ── XDC (XinFin) ───────────────────────────────────────────────────────────
  xdc1c5808a8c6a24dd5e9d7af4c1bb92e3a7fcb5f55: { label: "Bitrue XDC",    type: "exchange" },
  xdcadf8f46f6d9b480e1f91c02c0cAfec9d37d3aa:   { label: "AscendEX XDC",  type: "exchange" },
  xdc4a62f8ceEF3F2ea81E32e0EAce2e16e8c8BEbC54: { label: "KuCoin XDC",    type: "exchange" },
  xdc2a0f8B4D3ac1D66a72A0e29eCFd60b79Fe54f7Cc: { label: "Gate.io XDC",   type: "exchange" },
  xdc0bdf7ED8a08e99aBb3acB37fEc88bF01DB4fcbae: { label: "Bitrue XDC 2",  type: "exchange" },
  xdc15adad47B4Cd4b14fB8B3FaF8Fd02DF62a3cE8Dc: { label: "OKX XDC",      type: "exchange" },
  // XDC exchange wallets (0x-prefixed format — May 2026)
  "0x86c334119af88d8daa1bbd4e982b24c410a0301":   { label: "HitBTC",   type: "exchange" },
  "0xd0ad6bc1c9e6fd9fc1be1d674109e1afcc78b058":  { label: "Bybit",    type: "exchange" },
  "0x4e5d2ddf1c5060a64d70eec1731710f49a76d2bf":  { label: "KuCoin",   type: "exchange" },
  "0x43b96a1bbe34ccf6d67b334ee86405fb950bdcaa":  { label: "Huobi",    type: "exchange" },
  "0x472c619028ba67b817b48f8d64dbb7699ce0fadf":  { label: "Bitfinex", type: "exchange" },
  "0xf29f049144467b3dc55e19205c30c1737942f23a":  { label: "MEXC",     type: "exchange" },
  "0x377b8ce04761754e8ac153b47805a9cf6b190873":  { label: "Upbit",    type: "exchange" },
  "0xab782bc7d4a2b306825de5a7730034f8f63ee1bc":  { label: "Bitvavo",  type: "exchange" },
  // ── Ethereum / EVM ─────────────────────────────────────────────────────────
  "0x28c6c06298d514db089934071355e5743bf21d60": { label: "Binance Hot",    type: "exchange" },
  "0x21a31ee1afc51d94c2efccaa2092ad1028285549": { label: "Binance Cold",   type: "exchange" },
  "0xdfd5293d8e347dfe59e90efd55b2956a1343963d": { label: "Binance 2",      type: "exchange" },
  "0xbe0eb53f46cd790cd13851d5eff43d12404d33e8": { label: "Binance Cold 3", type: "exchange" },
  "0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be": { label: "Binance Legacy", type: "exchange" },
  "0xf977814e90da44bfa03b6295a0616a897441acec": { label: "Binance 5",      type: "exchange" },
  "0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43": { label: "Coinbase Hot",   type: "exchange" },
  "0x71660c4005ba85c37ccec55d0c4493e66fe775d3": { label: "Coinbase 2",     type: "exchange" },
  "0x503828976d22510aad0201ac7ec88293211d23da": { label: "Coinbase 3",     type: "exchange" },
  "0xd688aea8f7d450909adeb20364e860db13647ed7": { label: "Coinbase 4",     type: "exchange" },
  "0x267be1c1d684f78cb4f6a176c4911b741e4ffdc0": { label: "Kraken ETH",     type: "exchange" },
  "0x2910543af39aba0cd09dbb2d50200b3e800a63d2": { label: "Kraken 2",       type: "exchange" },
  "0x0a869d79a7052c7f1b55a8ebabbea3420f0d1e13": { label: "Kraken 3",       type: "exchange" },
  "0xf30ba13e4b04ce5dc4d254ae5fa95477800f0eb0": { label: "Kraken ETH 4",   type: "exchange" },
  "0x0681d8db095565fe8a346fa0277bffde9c0edbbf": { label: "OKX Hot",        type: "exchange" },
  "0x6cc5f688a315f3dc28a7781717a9a798a59fda7b": { label: "OKX 2",          type: "exchange" },
  "0xe93381fb4c4f14bda253907b18fad305d799241a": { label: "Huobi 1",        type: "exchange" },
  "0x46705dfff24256421a05d056c29e81bdc09723b8": { label: "Huobi 2",        type: "exchange" },
  "0xab5c66752a9e8167967685f1450532fb96d5d24f": { label: "Huobi 3",        type: "exchange" },
  "0x77134cbc06cb00b66f4c7e623d5fdbf6777635ec": { label: "MEXC ETH",       type: "exchange" },
  "0x4fdaf3ef3af2b3c3b4e5f94c0e6d70fed7b3c830": { label: "Bybit ETH",      type: "exchange" },
  "0x1ab4973a48dc892cd9971ece8e01dcc7688f8f23": { label: "Bybit ETH 2",    type: "exchange" },
  "0x0d0707963952f2fba59dd06f2b425ace40b492fe": { label: "Gate.io",        type: "exchange" },
  "0x7793cd85c11a924478d358d49b05b37b91ab9d79": { label: "Gate.io ETH 2",  type: "exchange" },
  "0x12d66f87a04a9e220743712ce6d9bb1b5616b8fc": { label: "Tornado Cash 0.1 ETH Pool (Mixer)", type: "mixer" },
  "0x47ce0c6ed5b0ce3d3a51fdb1c52dc66a7c3c2936": { label: "Tornado Cash 1 ETH Pool (Mixer)",   type: "mixer" },
  "0x910cbd523d972eb0a6f4cae4618ad62622b39dbf": { label: "Tornado Cash 10 ETH Pool (Mixer)",  type: "mixer" },
  "0xa160cdab225685da1d56aa342ad8841c3b53f291": { label: "Tornado Cash 100 ETH Pool (Mixer)", type: "mixer" },
  "0x2faf487a4414fe77e2327f0bf4ae2a264a776ad2": { label: "FTX (defunct)",  type: "flagged" },
  "0xc098b2a3aa256d2140208c3de6543aaef5cd3a94": { label: "FTX US (defunct)", type: "flagged" },
  // ── Kraken ETH (full wallet list) ──────────────────────────────────────────
  "0xae2d4617c862309a3d75a0ffb358c7a5009c673f": { label: "Kraken ETH",            type: "exchange" },
  "0x43984d578803891dfa9706bdeee6078d80cfc79e": { label: "Kraken ETH",            type: "exchange" },
  "0x66c57bf505a85a74609d2c83e94aabb26d691e1f": { label: "Kraken ETH",            type: "exchange" },
  "0xda9dfa130df4de4673b89022ee50ff26f6ea73cf": { label: "Kraken ETH",            type: "exchange" },
  "0xa83b11093c858c86321fbc4c20fe82cdbd58e09e": { label: "Kraken ETH",            type: "exchange" },
  "0xce27fc71139d02f9a3d5cc1356add185750660ac": { label: "Kraken ETH",            type: "exchange" },
  "0x0d0452f487d1edc869d1488ae984590ca2900d2f": { label: "Kraken ETH",            type: "exchange" },
  "0x6d0cf1f651f5ae585d24dcaa188d44e389e93d26": { label: "Kraken ETH",            type: "exchange" },
  "0x735fd3c55a8be1aeb3544c7e29eba3ea23500a1c": { label: "Kraken ETH",            type: "exchange" },
  "0xfedac45de308e24b8282193c512f029250943d8a": { label: "Kraken ETH",            type: "exchange" },
  "0x098cbdd8eb01b19d37539644821772e9bde12d55": { label: "Kraken ETH",            type: "exchange" },
  "0x9ee32359b180ff684a315053e418aaf223932cb9": { label: "Kraken ETH",            type: "exchange" },
  "0x491f5512751f5db45c5415049d423affaae70392": { label: "Kraken ETH",            type: "exchange" },
  "0x34036f30371847c9fd8036b7ea5af1b3126306dc": { label: "Kraken ETH",            type: "exchange" },
  "0x62ac55b745f9b08f1a81dcbbe630277095cf4be1": { label: "Kraken ETH",            type: "exchange" },
  "0x7dafba1d69f6c01ae7567ffd7b046ca03b706f83": { label: "Kraken ETH",            type: "exchange" },
  "0xd2dd7b597fd2435b6db61ddf48544fd931e6869f": { label: "Kraken ETH",            type: "exchange" },
  "0x69f57499e75d18d69261d081412e794b33b0e91e": { label: "Kraken ETH",            type: "exchange" },
  "0x10593a64b7b7bb0ea29b8c01f1619ca8ff294b2f": { label: "Kraken ETH",            type: "exchange" },
  "0x60637c83bd6aea40d637d91cca8d724272b2d5fa": { label: "Kraken ETH",            type: "exchange" },
  "0xa939bffb33bed18dc0063737cb9ea41a1fdb2fe3": { label: "Kraken ETH",            type: "exchange" },
  "0x5c5f75b6fba2903adf66c7bddcea99b4cce44a8a": { label: "Kraken ETH",            type: "exchange" },
  "0xa861678bee80035114b47615142e9302139a8c32": { label: "Kraken ETH",            type: "exchange" },
  "0xe853c56864a2ebe4576a807d26fdc4a0ada51919": { label: "Kraken ETH",            type: "exchange" },
  "0xe52ecf8d97e290dad5963296c5d1f81472f2ec48": { label: "Kraken ETH",            type: "exchange" },
  "0x5203aeaaee721195707b01e613b6c3259b3a5cf6": { label: "Kraken ETH",            type: "exchange" },
  "0x71beefcf9f31872ccec0bc9789f211609685205a": { label: "Kraken ETH",            type: "exchange" },
  "0x16b2b042f15564bb8585259f535907f375bdc415": { label: "Kraken ETH",            type: "exchange" },
  "0x8ab54f9e6df35b26168847ea93dab9659ecf286d": { label: "Kraken ETH",            type: "exchange" },
  "0x79990a901281bee059bb3f4d7db477f7495e2049": { label: "Kraken ETH",            type: "exchange" },
  "0x92927a664c88449318e14d0fd582c787ae2cd934": { label: "Kraken ETH",            type: "exchange" },
  "0x490b1e689ca23be864e55b46bf038e007b528208": { label: "Kraken ETH",            type: "exchange" },
  "0xe7178ad747f2c12ab1f8332e61cf6e756815d5c6": { label: "Kraken ETH",            type: "exchange" },
  "0xadae2f3b0db76cb3eafe76a8bf99b93f099c140a": { label: "Kraken ETH",            type: "exchange" },
  "0x52f5f2add61c835ff10550402a46621ebd1071d5": { label: "Kraken ETH",            type: "exchange" },
  "0xfa52274dd61e1643d2205169732f29114bc240b3": { label: "Kraken ETH",            type: "exchange" },
  "0xf1f7648f81f5219c36d75d24d33811f16b426dbe": { label: "Kraken ETH",            type: "exchange" },
  "0xe850b7c87f66371035e184c72d4b99e7b2ca4865": { label: "Kraken ETH",            type: "exchange" },
  "0x0ef6aeb825dc4c9983d551f8afefaae9d79165c6": { label: "Kraken ETH",            type: "exchange" },
  "0xa054611c5b224a5f4ce93ac2a5f8d0ed17813402": { label: "Kraken ETH",            type: "exchange" },
  "0xa25aa6dbf6d9bbd7a6a9eb47b9f1e57a2bd92d7": { label: "Kraken ETH",            type: "exchange" },
  "0x16b34756653f88a89005e96c0622832d8fb6b0b5": { label: "Kraken ETH",            type: "exchange" },
  "0xfcaf9c57c26566f96d23f585950bb1c66e138890": { label: "Kraken ETH",            type: "exchange" },
  "0xa2f443492bbb1b041fceee5194e2bc133ecc6407": { label: "Kraken ETH",            type: "exchange" },
  "0x8dfee7dbd859989bf3e80c4f64c42b7cd283671b": { label: "Kraken ETH",            type: "exchange" },
  "0x3ff7215004fea03c2c745e0476e3f412050e04d1": { label: "Kraken ETH",            type: "exchange" },
  "0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40": { label: "Kraken ETH",            type: "exchange" },
  "0xa4a6a282a7fc7f939e01d62d884355d79f5046c1": { label: "Kraken ETH",            type: "exchange" },
  "0xa6715eafe5d215b82cb9e90a9d6c8970a7c90033": { label: "Kraken ETH",            type: "exchange" },
  "0x109be9d7d5f64c8c391ced3a8f69bdef20fcaea9": { label: "Kraken ETH",            type: "exchange" },
  "0x94dbf04e273d87e6d9bed68c616f43bf86560c74": { label: "Kraken ETH",            type: "exchange" },
  "0xcf40d0d2b44f2b66e07cace1372ca42b73cf21a3": { label: "Kraken ETH",            type: "exchange" },
  "0xc6bed363b30df7f35b601a5547fe56cd31ec63da": { label: "Kraken ETH",            type: "exchange" },
  "0x29728d0efd284d85187362faa2d4d76c2cfc2612": { label: "Kraken ETH",            type: "exchange" },
  "0x22af984f13dfb5c80145e3f9ee1050ae5a5fb651": { label: "Kraken Cold Wallet",    type: "exchange" },
  "0x8d05d9924fe935bd533a844271a1b2078eae6fcf": { label: "Kraken Cold Wallet",    type: "exchange" },
  "0x9f1799fb47b1514f453bcebbc37ecfe883756e83": { label: "Kraken Cold Wallet",    type: "exchange" },
  "0x2e7542ec36df6429d8c397f88c4cf0c925948f44": { label: "Kraken Deployer",       type: "exchange" },
  "0xa24787320ede4cc19d800bf87b41ab9539c4da9d": { label: "Kraken Deployer",       type: "exchange" },
  "0xd4039ecc40aeda0582036437cf3ec02845da4c13": { label: "Kraken ETH Staking",    type: "exchange" },
  "0xa40dfee99e1c85dc97fdc594b16a460717838703": { label: "Kraken ETH2 Depositor", type: "exchange" },
  "0xe9f7ecae3a53d2a67105292894676b00d1fab785": { label: "Kraken Hot Wallet",     type: "exchange" },
  "0xcc282e2004428939ee5149a9e7872f0b4d5d5ec7": { label: "Kraken Hot Wallet",     type: "exchange" },
  "0x05ff6964d21e5dae3b1010d5ae0465b3c450f381": { label: "Kraken Hot Wallet",     type: "exchange" },
  "0xe1498a9ef5c6aa51790a642f70c31238326b1724": { label: "Kraken MANA Token",     type: "exchange" },
  // ── Gemini ETH ─────────────────────────────────────────────────────────────
  "0xd24400ae8bfebb18ca49be86258a3c749cf46853": { label: "Gemini ETH",            type: "exchange" },
  "0x6fc82a5fe25a5cdb58bc74600a40a69c065263f8": { label: "Gemini ETH",            type: "exchange" },
  "0x61edcdf5bb737adffe5043706e7c5bb1f1a56eea": { label: "Gemini ETH",            type: "exchange" },
  "0x5f65f7b609678448494de4c87521cdf6cef1e932": { label: "Gemini ETH",            type: "exchange" },
  "0xb302bfe9c246c6e150af70b1caaa5e3df60dac05": { label: "Gemini ETH",            type: "exchange" },
  "0x8d6f396d210d385033b348bcae9e4f9ea4e045bd": { label: "Gemini ETH",            type: "exchange" },
  "0xd69b0089d9ca950640f5dc9931a41a5965f00303": { label: "Gemini ETH",            type: "exchange" },
  "0x183b1ffb0aa9213b9335adfad82e47bfb02f8d24": { label: "Gemini ETH",            type: "exchange" },
  "0xafcd96e580138cfa2332c632e66308eacd45c5da": { label: "Gemini Cold Wallet",    type: "exchange" },
  "0x07ee55aa48bb72dcc6e9d78256648910de513eca": { label: "Gemini Contract",       type: "exchange" },
  "0x485b9a41e8bf06e57bb64c6ba7cb04f9d53d2d76": { label: "Gemini Contract",       type: "exchange" },
  "0xdd51f01d9fc0fd084c1a4737bbfa5becb6ced9bc": { label: "Gemini Deployer",       type: "exchange" },
  "0x4c2f150fc90fed3d8281114c2349f1906cde5346": { label: "Gemini Deployer",       type: "exchange" },
  "0x4b7ee45f30767f36f06f79b32bf1fca6f726deda": { label: "Gemini eFIL Token",     type: "exchange" },
  "0x056fd409e1d7a124bd7017459dfea2f387b6d5cd": { label: "Gemini GUSD Token",     type: "exchange" },
  "0xdec042a90de005b22754e94a8a979c4b8c67fde5": { label: "Gemini Old Contract",   type: "exchange" },
  // ── MEXC ETH (extended) ────────────────────────────────────────────────────
  "0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88": { label: "MEXC ETH",              type: "exchange" },
  "0x9b64203878f24eb0cdf55c8c6fa7d08ba0cf77e5": { label: "MEXC ETH",              type: "exchange" },
  "0x576b81f0c21edbbc920ad63feeb2b0736b018a58": { label: "MEXC ETH",              type: "exchange" },
  "0x8e1701cfd85258ddb8dfe89bc4c7350822b9601d": { label: "MEXC ETH",              type: "exchange" },
  "0x4982085c9e2f89f2ecb8131eca71afad896e89cb": { label: "MEXC ETH",              type: "exchange" },
  "0x0162cd2ba40e23378bf0fd41f919e1be075f025f": { label: "MEXC ETH",              type: "exchange" },
  "0x4e3ae00e8323558fa5cac04b152238924aa31b60": { label: "MEXC ETH",              type: "exchange" },
  "0x0211f3cedbef3143223d3acf0e589747933e8527": { label: "MEXC ETH",              type: "exchange" },
  "0xf016e1d45ef23bdd414e7a2e4d46e1b34577b508": { label: "MEXC ETH",              type: "exchange" },
  "0x3cc936b795a188f0e246cbb2d74c5bd190aecf18": { label: "MEXC ETH",              type: "exchange" },
  "0xee136c0389733849dd710ac7104e92c6bf497574": { label: "MEXC ETH",              type: "exchange" },
  "0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64": { label: "MEXC ETH",              type: "exchange" },
  "0x83c1c224044ef8573e9a728dbb91013cf80827e6": { label: "MEXC ETH",              type: "exchange" },
  "0xdf90c9b995a3b10a5b8570a47101e6c6a29eb945": { label: "MEXC ETH",              type: "exchange" },
  "0x51e3d44172868acc60d68ca99591ce4230bc75e0": { label: "MEXC ETH",              type: "exchange" },
  "0xffb3118124cdaebd9095fa9a479895042018cac2": { label: "MEXC ETH",              type: "exchange" },
  "0x00fe6efff506e62bdab2c128159b6867dd200c67": { label: "MEXC Deployer",         type: "exchange" },
  "0xfdd26cadf65a3b2efdbb9357670b9b4861b39bdd": { label: "MEXC Depositer Funder", type: "exchange" },
  // ── Robinhood ETH ──────────────────────────────────────────────────────────
  "0x40b38765696e3d5d8d9d834d8aad4bb6e418e489": { label: "Robinhood ETH",         type: "exchange" },
  "0x882b3db1ad49b4a705f76f6f6a5b110785e427e0": { label: "Robinhood Token",       type: "exchange" },
  "0x2efb50e952580f4ff32d8d2122853432bbf2e204": { label: "Robinhood ETH 2",       type: "exchange" },
  "0x6081258689a75d253d87ce902a8de3887239fe80": { label: "Robinhood ETH 3",       type: "exchange" },
  "0xa26e73c8e9507d50bf808b7a2ca9d5de4fcc4a04": { label: "Robinhood ETH 4",       type: "exchange" },
  "0x841ed663f2636863d40be4ee76243377dff13a34": { label: "Robinhood ETH 5",       type: "exchange" },
  "0x73af3bcf944a6559933396c1577b257e2054d935": { label: "Robinhood ETH 6",       type: "exchange" },
  "0x7c5830cb1a1efe898dcd5cf401165cb952508ccc": { label: "Robinhood ETH 7",       type: "exchange" },
  "0xe0f3e36dbdfa9696b7bcb0d3313522a0bb28d5f4": { label: "Robinhood ETH 8",       type: "exchange" },
  "0x1887fa9edadeab7562b01cc3f4fa246ace2c3cdd": { label: "Robinhood ETH 9",       type: "exchange" },
  // ── Uphold ETH ─────────────────────────────────────────────────────────────
  "0x1c727a55ea3c11b0ab7d3a361fe0f3c47ce6de5d": { label: "Uphold ETH",            type: "exchange" },
  "0x66ae6b09a65bd0d459c38b5dc443fc2a4cfde886": { label: "Uphold Labs",            type: "exchange" },
  "0x3d8fc1cffaa110f7a7f9f8bc237b73d54c4abf61": { label: "Uphold",                type: "exchange" },
  "0x352e50481b9e0b30f9ca70efc27a52d298f6697":  { label: "Uphold ETH 3",          type: "exchange" },
  "0x6e5d4a298332e51a83539a57461e803bcf409050": { label: "Uphold ETH 4",          type: "exchange" },
  "0xa95350d70b18fa29f6b5eb8d627ceeeee499340d": { label: "Uphold ETH 5",          type: "exchange" },
  // ── Coinbase ETH (full wallet list) ────────────────────────────────────────
  "0x7915f087685ffd71608e5d118f3b70c27d9ef4e":  { label: "Coinbase: Commerce",         type: "exchange" },
  "0xf6874c88757721a02f47592140905c4336dfbc61": { label: "Coinbase: Commerce 2",        type: "exchange" },
  "0xce97003ea2e0a565a9a0b6e36209c6ddaaa14b05": { label: "Coinbase: Deployer",          type: "exchange" },
  "0xc8373edfad6d5c5f600b6b2507f78431c5271ff5": { label: "Coinbase 11",                 type: "exchange" },
  "0xb624219480543c54603fb6b07d5eb347e51bffe0": { label: "Coinbase 13",                 type: "exchange" },
  "0x20fe51a9229eef2cf8ad9e89d91cab9312cf3b7a": { label: "Coinbase 14",                 type: "exchange" },
  "0x333d17d3b42bf7930dbc6e852ca7bcf560a69003": { label: "Coinbase 15",                 type: "exchange" },
  "0x9810762578accf1f314320cca5b72506ae7d7630": { label: "Coinbase 16",                 type: "exchange" },
  "0x3dd1d15b3c78d6acfd75a254e857cbe5b9ff0af2": { label: "Coinbase 17",                 type: "exchange" },
  "0xf491d040110384dbcf7f241ffe2a546513fd873d": { label: "Coinbase 18",                 type: "exchange" },
  "0xc7bf35c9a3bdd1b1c19a6963de669cb45191a019": { label: "Coinbase 19",                 type: "exchange" },
  "0x05e3a758fdd29d28435019ac453297ea37b61b62": { label: "Coinbase 20",                 type: "exchange" },
  "0xa3682fe8fd73b90a7564585a436ec2d2aeb612ee": { label: "Coinbase 21",                 type: "exchange" },
  "0x739120ade7ed878fca5bbdb806263a8258fe2360": { label: "Coinbase 22",                 type: "exchange" },
  "0xdddfabcd4d8ffc6d5beaf154f18b778f892a0740": { label: "Coinbase 23",                 type: "exchange" },
  "0x8af8485e1f178be06386cd3877fde20626e0284f": { label: "Coinbase 24",                 type: "exchange" },
  "0x6dcbce46a8b494c885d0e7b6817d2b519df64467": { label: "Coinbase 25",                 type: "exchange" },
  "0xa656f7d2a93a6f5878aa768f24eb38ec8c827fe2": { label: "Coinbase 26",                 type: "exchange" },
  "0x6321f9f02d9d56261c8c79131ae74d7b427ccaf5": { label: "Coinbase 27",                 type: "exchange" },
  "0x2dfb39711dbe2cf254c3f2915e03035a5affecae": { label: "Coinbase 28",                 type: "exchange" },
  "0x81b044b81beaccff016591e71f4aa43405f2e4b2": { label: "Coinbase 29",                 type: "exchange" },
  "0x5fac951171b5c9f67cf3a11169887ae7ffefc0b":  { label: "Coinbase 130",                type: "exchange" },
  "0x31c937157efa4c7b7390571f01b476922e43b10a": { label: "Coinbase 158",                type: "exchange" },
  "0x7830c87c02e56aff27fa8ab1241711331fa86f43": { label: "Coinbase: Deposit",           type: "exchange" },
  "0x382ffce2287252f930e1c8dc9328dac5bf282ba1": { label: "Coinbase: Fees",              type: "exchange" },
  "0xa090e606e30bd747d4e6245a1517ebe430f0057e": { label: "Coinbase: Miscellaneous",     type: "exchange" },
  "0xcfc96b27bc175cdb353c231c662b28445ae9f01a": { label: "Coinbase 159",                type: "exchange" },
  "0xfa518ddba9c954d863e8b9c0359a36e444f46802": { label: "Coinbase 160",                type: "exchange" },
  "0x47073c804a591b0033aa0a7b1a1a35515481052f": { label: "Coinbase 161",                type: "exchange" },
  "0x01dbcbd257ce4332b570deba15b803337b0e9eee": { label: "Coinbase 162",                type: "exchange" },
  "0xbc1373482071bec7421699d3a9a5a0e6066470e9": { label: "Coinbase 163",                type: "exchange" },
  "0x5682bd619c4a337fdea6116dd584ba944ceac5f":  { label: "Coinbase 164",                type: "exchange" },
  "0x35aa5495f0d686fbb8318abeb5e42ec1da9bb0ce": { label: "Coinbase 165",                type: "exchange" },
  "0x43e5c286bbb8874b464ceaae274466f18dc4b7c9": { label: "Coinbase 166",                type: "exchange" },
  "0x904383ea20adb9b590360341925c0ea724c8a57f": { label: "Coinbase 167",                type: "exchange" },
  "0x969e3afc5580f0bc3790d789781be4150c43d510": { label: "Coinbase 168",                type: "exchange" },
  "0x46d06422b2718ea06042bfa1c1712bd52896ef3":  { label: "Coinbase 169",                type: "exchange" },
  "0x9d67adc2cc190d6a0378d52fac55319d8e0d6aed": { label: "Coinbase 170",                type: "exchange" },
  "0x82a8b86776ecd679c43cfccbb1988e7482ca3f45": { label: "Coinbase 171",                type: "exchange" },
  "0xd35724edd7c6208e9050a97ce3ac89f15566abe9": { label: "Coinbase 172",                type: "exchange" },
  "0xf45a300a5b7b3099ae11673559a6a81656b5dba4": { label: "Coinbase 173",                type: "exchange" },
  "0x3c1984f10cc306de7c3a8767a8aafcc0944bf5db": { label: "Coinbase 174",                type: "exchange" },
  "0x58aaf79cb86dd730fa008973d4c4b6fee8fb4d80": { label: "Coinbase 175",                type: "exchange" },
  "0x114c5be8151419fd30048299836d6685f5535884": { label: "Coinbase 176",                type: "exchange" },
  "0x48f86ae9f2f8b21e49f5b98cc4066fb421a39ab0": { label: "Coinbase 177",                type: "exchange" },
  "0x25e01082ab471f4325a45da9ea6b8f27b1f042ef": { label: "Coinbase 178",                type: "exchange" },
  "0x73183c36e0ca0647e1ee2764b9024033bc5483c3": { label: "Coinbase 179",                type: "exchange" },
  "0x2caafa8cddac8dd753f927d9dd1816ad0063a422": { label: "Coinbase 180",                type: "exchange" },
  "0x2f04879b1f1cfc4a8ac7574c78684ed18da45dd0": { label: "Coinbase 181",                type: "exchange" },
  "0x2ec90c4a7c4cc64d7f662ccb9d5ef94d3e556860": { label: "Coinbase 182",                type: "exchange" },
  "0x624417da5bbdd091f814a49b9cefae2c797a234d": { label: "Coinbase 183",                type: "exchange" },
  "0x71c35d3ce7cdc7855ec9d4ea0dd0abba91176ed1": { label: "Coinbase 184",                type: "exchange" },
  "0x7fba67199ec67af97cc036963a23087809810b63": { label: "Coinbase 185",                type: "exchange" },
  "0xae61f9d00b24a79b9b48d88d5be40c29f6462af4": { label: "Coinbase 186",                type: "exchange" },
  "0x14011b461b711b91d35d516d4964cfaae3f79a38": { label: "Coinbase 187",                type: "exchange" },
  "0x2de960c016165cd9b48f8b8d51dddc5364f04d59": { label: "Coinbase 188",                type: "exchange" },
  "0x8c1323c2bc755030582c7f2d131c14296df8d30d": { label: "Coinbase 189",                type: "exchange" },
  "0x44cb1ebcc9d703ce505443fc653961ab151c6b73": { label: "Coinbase 190",                type: "exchange" },
  "0xe0b50a87ae35e3f7a87f1c3904d53bd93d29f1d1": { label: "Coinbase 191",                type: "exchange" },
  "0xa8dcc0373822b94d7f57326be24ca67bafcaad6b": { label: "Coinbase 192",                type: "exchange" },
  "0xd4239903418b6a55d7cec9cc2ba22a3b6aca7003": { label: "Coinbase 193",                type: "exchange" },
  "0x35aeed3aa9657abf8b847038bb591b51e1e4c69f": { label: "Coinbase 194",                type: "exchange" },
  "0xdb3c617cdd2fbf0bb4309c325f47678e37f096d9": { label: "Coinbase 195",                type: "exchange" },
  "0xb93d8596ac840816bd366dc0561e8140afd0d1cb": { label: "Coinbase 196",                type: "exchange" },
  "0x7ead3a4361bd26a20deb89c9470be368ee9cb6f1": { label: "Coinbase 197",                type: "exchange" },
  "0xd5268a476aadd1a6729df5b3e5e8f2c1004139af": { label: "Coinbase 198",                type: "exchange" },
  "0x7db25dfaabc961808b482ea47dc6c26a3cbd5589": { label: "Coinbase 199",                type: "exchange" },
  "0xa4ffe11ec05b066d87762bc03f6b6728ab16811f": { label: "Coinbase 200",                type: "exchange" },
  "0x881d4032abe4188e2237efcd27ab435e81fc6bb1": { label: "Coinbase: Commerce 3",        type: "exchange" },
  "0x1bbe1be1fb532a010762665cfbed31595367e5d":  { label: "Coinbase: ERC20 Distributor", type: "exchange" },
  "0x4675c7e5baafbfbc748158becba61ef3b0a263":   { label: "Coinbase: MEV Builder",       type: "exchange" },
  "0x6d44bfb8432d17882bb6e84652f5c3b36fcc8280": { label: "Coinbase: Mint Forwarder",    type: "exchange" },
  "0xcbb7c0000ab88b473b1f5afd9ef808440eed33bf": { label: "Coinbase: cbBTC Token",       type: "exchange" },
  "0xec8103eb573150cb92f8af612e0072843db2295f": { label: "Coinbase: Base Sequencer",    type: "exchange" },
  "0x94bb3074cb9d804d3aacfea2079fc3798165268e": { label: "Coinbase: Lighter Deposit",   type: "exchange" },
  "0x6f52730dba7b02beefcaf0d6998c9ae901ea04f9": { label: "Coinbase Cold 1",             type: "exchange" },
  "0xeba20d0f74ecc13130579d21bb53d63c96258652": { label: "Coinbase Cold 2",             type: "exchange" },
  "0x281055afc982d96fab65b3a49cac8b878184cb16": { label: "Coinbase Cold 3",             type: "exchange" },
  "0xf27daff52c38b2c373ad2b9392652ddf433303c4": { label: "Coinbase Cold 4",             type: "exchange" },
  "0x93745feeb3c42f6ab0f9890cbce65b360145b4ab": { label: "Coinbase Cold 5",             type: "exchange" },
  "0x90e63c3d53e0ea496845b7a03ec7548b70014a91": { label: "Coinbase Cold 6",             type: "exchange" },
  "0x6c37a68dbb44c3f437d15dc405c67bf5778b8637": { label: "Coinbase Cold 7",             type: "exchange" },
  "0x9a1ed80ebc9936cee2d3db944ee6bd8d407e7f9f": { label: "Coinbase Cold 8",             type: "exchange" },
  "0x4fd166478b440fb2a0bc64321ec35ed48f9cdb16": { label: "Coinbase Cold 9",             type: "exchange" },
  "0xb8487eed31cf5c559bf3f4edd166b949553d0d11": { label: "Coinbase Cold 10",            type: "exchange" },
  "0x5ffc99b5b23c5ab8f463f6090342879c286a29be": { label: "Coinbase Cold 11",            type: "exchange" },
  "0x3d2e397f94e415d7773e72e44d5b5338a99e77d9": { label: "Coinbase Cold 12",            type: "exchange" },
  "0xe04cf52e9fafa3d9bf14c407aff94165ef835f7":  { label: "Coinbase Cold 13",            type: "exchange" },
  "0x19d599012788b991ff542f31208bab21ea38403e": { label: "Coinbase Cold 14",            type: "exchange" },
  "0xcad50671877eb564d42ddd76b5fec46ac60ef1bd": { label: "Coinbase Cold 15",            type: "exchange" },
  "0xe9eaf769192becc0d27f6d5b73d5dbd6cd06a430": { label: "Coinbase Prime 93",           type: "exchange" },
  "0x54a57fade3899fb79224f32fab57b3eb656125b1": { label: "Coinbase Prime 94",           type: "exchange" },
  "0x39b7792c640c0f17b6ceab062bc927cb944b136a": { label: "Coinbase Prime 95",           type: "exchange" },
  "0x3f0e9b199a51751876479216d467b05dd5f06e2":  { label: "Coinbase Prime 96",           type: "exchange" },
  "0xcd4dc62388365567bb85dbfa813dadac7766e683": { label: "Coinbase Prime 97",           type: "exchange" },
  "0x0fae62e1643f47dda3c5cab7eab1270b96339232": { label: "Coinbase Prime 98",           type: "exchange" },
  "0x469c45be41483480bc57a76572923576d8486fb7": { label: "Coinbase Prime 99",           type: "exchange" },
  "0xd6c156087acc6a40ee7d355aa56c776d2945b700": { label: "Coinbase Prime 100",          type: "exchange" },
  "0x5ce305fa1beac74f1cc44a083e7c996246052f9e": { label: "Coinbase Prime 101",          type: "exchange" },
  "0xd00cfab6ed43e32d8fb3968639d8283262201638": { label: "Coinbase Prime 102",          type: "exchange" },
  "0x5fb6b61f8698ab13de8d679019e63356361046b8": { label: "Coinbase Prime 103",          type: "exchange" },
  "0x646ee498b8dad180257fdc26b22f423002515c0e": { label: "Coinbase Prime 104",          type: "exchange" },
  "0x2dd4237a5e5f8221b5ec44ca299576e62629ede7": { label: "Coinbase Prime 105",          type: "exchange" },
  "0xab862d97e60fd8ee26db7f4667995406d8e29179": { label: "Coinbase Prime 106",          type: "exchange" },
  "0xc4109d540ae6c922f9953499cbfa4b5b79fa6e0d": { label: "Coinbase Prime 107",          type: "exchange" },
  "0xe18d30038b7022b874547fd7f5bff2229a21e977": { label: "Coinbase Prime 108",          type: "exchange" },
  "0x6dc20fa4f28223a55eea6f99629c12b93cf68e2f": { label: "Coinbase Prime 109",          type: "exchange" },
  "0xd5bec1e065f06141f8c54624a3d99fabca7c9f93": { label: "Coinbase Prime 110",          type: "exchange" },
  "0x59066500b2ba2be39adcfb046ca971aa30b0fa5b": { label: "Coinbase Prime 111",          type: "exchange" },
  "0x90229967766bc7ce5d3b0564e887528c2d868ee7": { label: "Coinbase Prime 112",          type: "exchange" },
  "0x63db70679349150c9a7097706866344fa314120e": { label: "Coinbase Prime 113",          type: "exchange" },
  "0x5483ed9d614c2facba807cc994af10d7f99def15": { label: "Coinbase Prime 114",          type: "exchange" },
  "0x639a88354e7b6579c5bc3b0a7840295846ea1d6":  { label: "Coinbase Prime 115",          type: "exchange" },
  "0x98172720506a4676fa02f559a93f9a95d8ffc13c": { label: "Coinbase Prime 116",          type: "exchange" },
  "0xca987fdfd2f8847d520af897c3d922445d4c0916": { label: "Coinbase Prime 117",          type: "exchange" },
  "0xe1f41bbc96d1e7dc7925d20d3b9f447d998afd5a": { label: "Coinbase Prime 118",          type: "exchange" },
  "0x93b0ae3af365a14322e141b001bf5078fa38afea": { label: "Coinbase Prime 119",          type: "exchange" },
  "0x6ec3fe46996e966b11f3f8d502493044d5c3cad7": { label: "Coinbase Prime 120",          type: "exchange" },
  "0x472e81153d04774bfef07f1e053f0b7fe4c10867": { label: "Coinbase Prime 121",          type: "exchange" },
  "0xcd699325143158d4f326752f86666546bab29b95": { label: "Coinbase Prime 122",          type: "exchange" },
  "0xfaf2910a6bb055a8c9505767ca985ebaf145b6a":  { label: "Coinbase Prime 123",          type: "exchange" },
  "0x3de7ece96e376622eb8984f84ffa566540ee4b0":  { label: "Coinbase Prime 124",          type: "exchange" },
  "0xc7196fa549e7bff360e61308df2698b47a75c866": { label: "Coinbase Prime 125",          type: "exchange" },
  "0xc05ff719ee679b6c1e5ca4bb702f14a3103546e3": { label: "Coinbase Prime 126",          type: "exchange" },
  "0x0421ed724cf857c645dc23a352c0e887f6602468": { label: "Coinbase Prime 127",          type: "exchange" },
  "0x768fddbe9e7e253e3ed93b32f509e88c6edf819a": { label: "Coinbase Prime 128",          type: "exchange" },
  "0xb2f0f1dcac493b5830ba3dba711383a97eba360c": { label: "Coinbase Prime 129",          type: "exchange" },
  "0x59c29f7d6f16e8e82b04c4a84e43f67b1f45437e": { label: "Coinbase Prime 130",          type: "exchange" },
  "0xae090fe711f7b6130455809cae122485589c7be8": { label: "Coinbase Prime 131",          type: "exchange" },
  "0xa562d463368c9334ccda3d2ed6500b43f3403c9a": { label: "Coinbase Prime 132",          type: "exchange" },
  "0x178b5d76d1eccc7d34dfbe08414a13e092eeba5":  { label: "Coinbase Prime 133",          type: "exchange" },
  "0x3c9ceb0f216682ff576add666aa9f6f5bc8aa182": { label: "Coinbase Prime 134",          type: "exchange" },
  "0x694c47f7b9fdc7dc91e404d707a21964743e1871": { label: "Coinbase Prime 135",          type: "exchange" },
  "0xccf5cf7c4be99291bb71dc6e1e40800f1ded4ca3": { label: "Coinbase Prime 136",          type: "exchange" },
  "0x4f39a36a56369ba6e3299ec5d7dee781ef047785": { label: "Coinbase Prime 137",          type: "exchange" },
  "0xfa0c342378147f92356a70a8fc563e1a36842458": { label: "Coinbase Prime 138",          type: "exchange" },
  "0x5e143312cda68fc3316cc47c144a89ee10cf2de6": { label: "Coinbase Prime 139",          type: "exchange" },
  "0x67b5f3a02c0be9dc1f867646e314861797207e67": { label: "Coinbase Prime 140",          type: "exchange" },
  "0xd8dc2191d8eed828b17db7da7d6d3520dfe83863": { label: "Coinbase Prime 141",          type: "exchange" },
  "0x1199b42abca57ccbdca27f8ea2784ff402b25995": { label: "Coinbase Prime 142",          type: "exchange" },
  "0xd300f9070e8f7aef96b008f6acb60688a2761af9": { label: "Coinbase Prime 143",          type: "exchange" },
  "0xc0543b2203ab4ae6dc0934885918ba5ec7a99cf1": { label: "Coinbase Prime 145",          type: "exchange" },
  "0xbe5fbcf97932ba9d05885d2b7fbba4cceb9e2836": { label: "Coinbase Prime 146",          type: "exchange" },
  "0x13e285e4949099eea8826ba0cbe2e9e22ee4e428": { label: "Coinbase Prime 147",          type: "exchange" },
  "0x25ef064291abeb0803112f8cbc2842574d399225": { label: "Coinbase Prime 148",          type: "exchange" },
  "0xf256cc86549c10f9256f046d9016ef3e12a91a33": { label: "Coinbase Prime 149",          type: "exchange" },
  "0x21763d32489a4c6298bbc44a99994a77e5f19903": { label: "Coinbase Prime 150",          type: "exchange" },
  "0x461293b0e1d0664f6cf8ca9f20dd0b898bed996b": { label: "Coinbase Prime 151",          type: "exchange" },
  "0xb3ba7af1bfda3b2f7bf08db01b5bc34f7463392d": { label: "Coinbase Prime 152",          type: "exchange" },
  "0xbfd7780c9d76aef077241f5e62d6fcee08d0c6a":  { label: "Coinbase Prime 153",          type: "exchange" },
  "0xcd186f70be06d1974bf33d52a074a2e5ba2564dc": { label: "Coinbase Prime 154",          type: "exchange" },
  "0x4fa9e8f236eb1891e2ac7b6fc49f5917bd2e0efc": { label: "Coinbase Prime 155",          type: "exchange" },
  "0x7d0a0cde3c1f11d8e2f35c84638460b529ae8f60": { label: "Coinbase Prime 156",          type: "exchange" },
  "0x58171f16a23c184104d4450622c7855808e145a4": { label: "Coinbase Prime 157",          type: "exchange" },
  "0x4bef27e92bb61dc9b2fa9a414758cb778c655b44": { label: "Coinbase Prime 158",          type: "exchange" },
  "0xa29f490808af6c7043d08e3f65505159123a102c": { label: "Coinbase Prime 159",          type: "exchange" },
  "0xac7d43a1e29b6dbadb53f39e757a0305bb6644cc": { label: "Coinbase Prime 160",          type: "exchange" },
  "0xd5e1a5fa3ff7039678c6cc3fb8b569bf9269789e": { label: "Coinbase Prime 161",          type: "exchange" },
  "0xee9e2611fa4dae0776a64b92cbb42e73a9b5b3a1": { label: "Coinbase Prime 162",          type: "exchange" },
  "0x372f261e570eb43a4b7dc536283b74f2187efed1": { label: "Coinbase Prime 163",          type: "exchange" },
  "0xda3c6e4f62bc8763a1ce5ba29cb31c3db8f73aac": { label: "Coinbase Prime 164",          type: "exchange" },
  "0xed21da9b81a146e6678445401eaffbeea61a8f89": { label: "Coinbase Prime 165",          type: "exchange" },
  "0x161eb1ea01565d4deeed1cf3f9389e0bd8b4aa58": { label: "Coinbase Prime 166",          type: "exchange" },
  "0xafa8deb8c87a8b6e51ff808e5bd9d6fdf6c704b2": { label: "Coinbase Prime 167",          type: "exchange" },
  "0xd9a27e959eea8924470d4735f88c10eba65e91b2": { label: "Coinbase Prime 168",          type: "exchange" },
  "0xe604f73727c90af5482c51888ff299379c79fc6f": { label: "Coinbase Prime 169",          type: "exchange" },
  "0x35ef3d54231912c7d1450be0be96ce037f3d6408": { label: "Coinbase Prime 170",          type: "exchange" },
  "0x61ccf6dd5bc0a24cf524ffbc5ce5842879bdeb33": { label: "Coinbase Prime 171",          type: "exchange" },
  "0xe451a7430a75f8cad390fd0d2defc3fd5884839":  { label: "Coinbase Prime 172",          type: "exchange" },
  "0xe864b304a3c0635dc673a760dc4145e6fbfbba19": { label: "Coinbase Prime 173",          type: "exchange" },
  "0xbe9895146f7af43049ca1c1ae358b0541ea49704": { label: "Coinbase: cbETH Token",       type: "exchange" },
  // ── Bitcoin ────────────────────────────────────────────────────────────────
  "1NDyJtNTjmwk5xPNhjgAMu4HDHigtobu1s": { label: "Binance BTC Hot",  type: "exchange" },
  "34xp4vRoCGJym3xR7yCVPFHoCNxv4Twseo": { label: "Binance BTC Cold", type: "exchange" },
  "bc1qgdjqv0av3q56jvd82tkdjpy7gd6f0tdn5n8vy5": { label: "BitMEX BTC",    type: "exchange" },
  "3E35SFZkfLMGo4qX5aVs1iBnpEiFLSZmBP":          { label: "Kraken BTC",    type: "exchange" },
  "bc1qm34lsc65zpw79lxes69zkqmk6ee3ewf0j77s3h": { label: "Coinbase BTC",  type: "exchange" },
  "3Kzh9qAqVWQhEsfQz7zEQL1EuSx5tyNLNS":          { label: "Bitstamp BTC",  type: "exchange" },
  "1LQoWist8KkaUXSPKZHNvEyfrEkPHzSsCd":          { label: "Huobi BTC Cold", type: "exchange" },
  "1HckjUpRGcrrRAtFaaCAUaGjsPx9oYmLaZ":           { label: "OKX BTC",       type: "exchange" },
  "3QW95MafXv9SqkXxhpKBgqXCgVzugdwsGt":          { label: "Bybit BTC",     type: "exchange" },
  "385cR5DM96n1HvBDMDc1XnYedsFZa8zT4T":           { label: "Bitfinex BTC",  type: "exchange" },
  "1LdRcdxfbSnmCYYNdeYpUnztiYzVfBEQeC":           { label: "Huobi BTC 2",   type: "exchange" },
  "bc1qa5wkgaew2dkv56kfvj49j0av5nml45x9ek9hz6": { label: "Robinhood BTC", type: "exchange" },
  "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh": { label: "Binance BTC 2",  type: "exchange" },
  "1Bh2AAQCnSiXqJWTGVTTTVMFAFPjguegYZ":           { label: "Gate.io BTC",   type: "exchange" },
  "1GR9qNz7zgtaW5HwwVpEJWMnGWhsbsieCG":           { label: "MEXC BTC",      type: "exchange" },
  // ── DAG (Constellation Network) ────────────────────────────────────────────
  // ── DAG Official Entities (type "official") ────────────────────────────────
  // Labelled in reports; count as PRIVATE COMMINGLING (not excluded like exchanges).
  // Team Foundation
  DAG38whfr5CWzMoQg8PajuiukNNojySqyXtZdBhK: { label: "Team Foundation Wallet",    type: "official" },
  DAG7teqwiZjuBivJi7Mx8AkhwnF6w3Q1poUTCViK: { label: "Team Foundation Wallet",    type: "official" },
  DAG7uFTujXArFTuTqELGYGcthacpfQykBX7wsgFv: { label: "Team Foundation Wallet",    type: "official" },
  DAG8MWCDLPxjufRE2tkg3qpWSd7iJKFfsg9H5nCE: { label: "Team Foundation Wallet",    type: "official" },
  DAG2eFDjZ2CMA3M4KMfLw6Vnn7kaJPJqcSCpHU25: { label: "Team Foundation Wallet",    type: "official" },
  DAG2ttEXvYHsMP5qu7ejoBTbuCPmHoDhU5fZi3YL: { label: "Team Foundation Wallet",    type: "official" },
  DAG1ZieMRm7ALEbSjmvwztvtZYu7srPaXwxbC14U: { label: "Team Foundation Wallet",    type: "official" },
  // Stardust Collective
  DAG8vD8BUhCpTnYXEadQVGhHjgxEZZiafbzwmKKh: { label: "Stardust Collective Wallet", type: "official" },
  DAG8VT7bxjs1XXBAzJGYJDaeyNxuThikHeUTp9XY: { label: "Stardust Collective Wallet", type: "official" },
  DAG6qyCvhka9rX9SsAMouHmAoKmADuGW415anB59: { label: "Stardust Collective Wallet", type: "official" },
  // DOR Metagraph
  DAG0o6WSyvc7XfzujwJB1e25mfyzgXoLYDD6wqnk: { label: "DOR Metagraph",             type: "official" },
  DAG4nBD5J3Pr2uHgtS1sa16PqemHrwCcvjdR31Xe: { label: "DOR Metagraph",             type: "official" },
  DAG4YD6rkExLwYyAZzwjYJMxe36PAptKuUKq9uc7: { label: "DOR Metagraph",             type: "official" },
  DAG0CyySf35ftDQDQBnd1bdQ9aPyUdacMghpnCuM: { label: "DOR Metagraph",             type: "official" },
  DAG5fqiGq9L5iLH5R5eV7gBjkucewrcaQ1jVnKYD: { label: "DOR Metagraph",             type: "official" },
  DAG5uDuGhPuh4mQZGNLFCEcdy69txSF4iSfFbdWJ: { label: "DOR Metagraph",             type: "official" },
  DAG6B5mBMoEu3Habtb2ts3QGUD2UquywrQSLSubU: { label: "DOR Metagraph",             type: "official" },
  // DOR Validator Tax
  DAG045Bmio7Jrv3aErTKjAisRnpBKvp16pp1wSqT: { label: "DOR Validator Tax Pool",    type: "official" },
  DAG2JsH1QKj8LrzmcgX2pf9MAcdhQWuihYnZMUNW: { label: "DOR Validator Tax",         type: "official" },
  // DTM Enterprise
  DAG8s4uKsTKV5hNVv9oHWophX1CYKVqJ88hM9MZE: { label: "DTM Enterprise Wallet",     type: "official" },
  DAG06pFXdTtqrx2H11oHyH5rBe6Ccx7XG8WSsPSA: { label: "DTM Enterprise Wallet",     type: "official" },
  // DTM Reward Pool
  DAG0U7R9jXMSiNMU5mgqpvCVuaBwfRBzY77nJZM1: { label: "DTM Reward Pool",           type: "official" },
  DAG0Njmo6JZ3FhkLsipJSppepUHPuTXcSifARfvK: { label: "DTM Reward Pool",           type: "official" },
  // PylonFi DOR Node
  DAG7k3M5aAWdV3S3E5nZXvvQyGprkYbVKxz6gGRS: { label: "PylonFi DOR Node",              type: "official" },
  // Constellation Protocol
  DAG86Joz5S7hkL8N9yqTuVs5vo1bzQLwF3MUTUMX: { label: "Constellation Protocol Wallet", type: "official" },
  // Legacy Stardust / Team entries (not yet reclassified)
  DAG8UsoSR14peffVJKAsf3mqJFnkKSoQEUQDAQKN: { label: "[Stardust Team Foundation]", type: "dag-team" },
  DAG07znCvSyM2xhxPZECrGhVF6WVPMvFWe6Z6EWW: { label: "[Stardust Team Fdn 2]",     type: "dag-team" },
  DAG3yzY9252n8Fkxix7pZo5TH6F9paxSVLsDARK4: { label: "[Stardust Team Fdn 7]",     type: "dag-team" },
  // Treasury
  DAG3tC21XtXvoUD8hTMQzHm7T21MHahuFPVrPBtR: { label: "[DAG Treasury]",            type: "dag-team" },
  DAG1nw5WkZdQf96Df3PkrjLxeHj2EV3oLkWPZQcD: { label: "[DAG Treasury 2]",          type: "dag-team" },
  // Bridge / Infrastructure (DAG only)
  DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B: { label: "Official Bridge / Base Wallet", type: "official" },
  DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz: { label: "DAG Reward / Team Wallet",      type: "genesis"  },
  // Constellation Foundation Wallets
  DAG7R5sZCC87GB2C7oxsLE7EvSkPZyCGtPEqd25n: { label: "Constellation Foundation / Legacy Distribution Wallet", type: "official" },
  DAG8MKzFQkgwxzAMAV1CPyNRwx3stvLTgkKu4QJW: { label: "Constellation Foundation / Reward Distribution Wallet", type: "official" },
  DAG72buDf2jPtHXBZqb2gdcGaWx9JkPYTX1YmSSS: { label: "Constellation Foundation / Core Wallet",                type: "official" },
  DAG6stSuh8C46VVHvFybyCjdC4UPu42xXq2Si9Z3: { label: "Constellation Distribution Wallet (Node Rewards)",      type: "official" },
  // DAG Exchanges
  DAG6Yxge8Tzd8DJDJeL4hMLntnhheHGR4DYSPQvf: { label: "MEXC DAG",        type: "exchange" },
  DAG4TETUwraLYX1mYdC8ymUxxWsoNZPffUpDf4Ar: { label: "Gate.io DAG",      type: "exchange" },
  DAG3Lcv4GEhPH34VHVgbEAf21Y3L2rtjLpXh7QD4: { label: "CoinEX DAG",       type: "exchange" },
  DAG6cStT1VYZdUhpoME23U5zbTveYq78tj7EihFV: { label: "KuCoin DAG",       type: "exchange" },
  DAG5yqn4JRkW5oAMthhBayBtkZzfAvRQnkH1dCG4: { label: "KuCoin DAG 2",     type: "exchange" },
  DAG2rMPHX4w1cMMjowmewRMjD1in53yRURt6Eijh: { label: "KuCoin DAG 3",     type: "exchange" },
  DAG2Evedeb9cS7d28bxF4wwgeryiEqfDo8diZMZg: { label: "KuCoin DAG 4",     type: "exchange" },
  DAG6LvxLSdWoC9uJZPgXtcmkcWBaGYypF6smaPyH: { label: "BitForex DAG",     type: "exchange" },
  DAG1pLpkyX7aTtFZtbF98kgA9QTZRzrsGaFmf4BT: { label: "Uphold DAG Exchange", type: "exchange" },
  DAG3sFdwPJAEJNkv5bJhFQgzCGRkv9mZXPjjK9FW: { label: "Bitrue DAG",       type: "exchange" },
  DAG7xJEbxJmZeJJC6jqfLHQd7JPRf5WmKrJqSvLo: { label: "Bitrue DAG 2",     type: "exchange" },
  DAG4PKqJ68MYKB9bPicGfzUbH3nqmz4q5H6YJZYM: { label: "Poloniex DAG",     type: "exchange" },
  DAG2NuRbQp3vX3X6p4bRKQ2TKe8vHXPqbq9xXGEd: { label: "LBank DAG",        type: "exchange" },
  // High-traffic custodial / exchange intermediary confirmed by intersection analysis
};

const EXPLORER_MAP: Record<string, (h: string) => string> = {
  ethereum: (h) => `https://etherscan.io/tx/${h}`,
  bitcoin: (h) => `https://blockchair.com/bitcoin/transaction/${h}`,
  polygon: (h) => `https://polygonscan.com/tx/${h}`,
  bsc: (h) => `https://bscscan.com/tx/${h}`,
  xrp: (h) => `https://xrpscan.com/tx/${h}`,
  xlm: (h) => `https://stellarchain.io/transactions/${h}`,
  hbar: (h) => `https://hashscan.io/mainnet/transaction/${h}`,
  xdc: (h) => `https://xdcscan.io/txs/${h}`,
  dag: (h) => `https://dagexplorer.io/transaction/${h}`,
};

const WALLET_EXPLORER_MAP: Record<string, (a: string) => string> = {
  ethereum: (a) => `https://etherscan.io/address/${a}`,
  bitcoin: (a) => `https://blockchair.com/bitcoin/address/${a}`,
  polygon: (a) => `https://polygonscan.com/address/${a}`,
  bsc: (a) => `https://bscscan.com/address/${a}`,
  xrp: (a) => `https://xrpscan.com/account/${a}`,
  xlm: (a) => `https://stellarchain.io/accounts/${a}`,
  hbar: (a) => `https://hashscan.io/mainnet/account/${a}`,
  xdc: (a) => `https://xdcscan.io/address/${a}`,
  dag: (a) => `https://dagexplorer.io/address/${a}`,
};

// ─── Trail types ──────────────────────────────────────────────────────────────
interface TrailEntry {
  address: string;
  depth: number;
  parentAddress: string | null;
  knownInfo?: { label: string; type: string };
  isExpanded: boolean;
  isLoading: boolean;
  error?: boolean;
  totalValueUsd: number;
  txCount: number;
  childAddresses: string[];
}

// ─── Origin Trace hop ─────────────────────────────────────────────────────────
interface OriginHop {
  hop: number;
  address: string;
  txHash: string | null;
  txAmount: string;
  txAsset: string;
  txTimestamp: string;
  txMemo?: string | null;
  txDestinationTag?: number | null;
  knownInfo?: { label: string; type: string };
  stopReason?: "exchange" | "dead-end" | "max-hops" | "loop" | null;
  isLoading: boolean;
  error?: string | null;
}

// ─── Transaction type (from API) ──────────────────────────────────────────────
interface Tx {
  hash: string;
  from: string;
  to: string | null;
  value: string;
  valueUsd: number;
  fee: string;
  feeUsd: number;
  timestamp: string;
  blockNumber: number;
  status: "success" | "failed" | "pending";
  direction: "in" | "out" | "self";
  tokenSymbol: string | null;
  tokenName: string | null;
  memo?: string | null;
  destinationTag?: number | null;
}

// ─── XLM asset allowlist + per-asset minimum amounts ─────────────────────────
// Only these 8 assets are shown for XLM wallets; all others are silently dropped.
const XLM_ALLOWED_ASSETS: Record<string, number> = {
  XLM:   1,         // ≥1 XLM — filters 1-stroop spam airdrops that display as "+0.0000"
  USDC:  1,
  VELO:  1000,
  SHX:   1000,
  AQUA:  1000,
  AFR:   1000,
  LSP:   10000,
  SSLX:  10000,
};

/** Returns true when a transaction should be shown for an XLM wallet. */
function xlmPassesFilter(tx: { tokenSymbol?: string | null; value: string }): boolean {
  const asset = (tx.tokenSymbol ?? "XLM").toUpperCase();
  const minAmt = XLM_ALLOWED_ASSETS[asset];
  if (minAmt === undefined) return false;       // asset not in allowlist — drop
  return parseFloat(tx.value) >= minAmt;        // below threshold — drop
}

/** DAG-specific minimum: 1 DAG micro-payments are spam/reward dust — require ≥2 DAG. */
const MIN_AMOUNT_DAG = 2;

/**
 * Global spam / dust filter applied uniformly across ALL reports and ALL chains.
 * XLM: uses the per-asset allowlist (xlmPassesFilter) — XLM≥1, AQUA/AFR/VELO/SHX≥1000, LSP/SSLX≥10000.
 * BTC / ETH: minimum 0.001 native (small coins — even tiny BTC transfers are meaningful).
 * DAG: minimum 2.0 (1 DAG micro-payments from reward wallets are filtered out).
 * Everything else (XRP, HBAR, XDC, Polygon, BSC, …): minimum 1.0 native token.
 * 0-value transactions (spam airdrops, farming, fee-only ops) are always dropped.
 */
function passesSpamFilter(
  tx: { value: string; tokenSymbol?: string | null },
  reportChain: string
): boolean {
  if (reportChain === "xlm") return xlmPassesFilter(tx);
  const v = parseFloat(tx.value || "0");
  if (!isFinite(v) || v === 0) return false;
  const min = reportChain === "bitcoin" || reportChain === "ethereum" ? 0.001
            : reportChain === "dag" ? MIN_AMOUNT_DAG
            : 1.0;
  return v >= min;
}

/**
 * NUCLEAR EARLY GUARD — graph-building analysis filter only.
 * Called as the FIRST check in every BFS loop (buildReachMap / buildReach) and
 * at the fetchTxs return boundary. Never touches ledger display, Trail Trace,
 * or START TRAIL TRACE.
 *
 * XLM whitelist: XLM≥1 · USDC≥1 · VELO/SHX/AQUA/AFR≥1000 · LSP/SSLX≥10000
 * All other XLM tokens (VTRX, airdrop dust, etc.) → rejected.
 * DAG: ≥2  ·  BTC/ETH: ≥0.001  ·  all other chains: ≥1.0
 */
function passesAnalysisFilter(
  tx: { value?: string | null; tokenSymbol?: string | null },
  chain: string
): boolean {
  if (!tx || !tx.value) return false;
  const amt = parseFloat(tx.value);
  if (isNaN(amt) || amt <= 0) return false;

  if (chain === "xlm") {
    const asset = (tx.tokenSymbol ?? "XLM").toUpperCase();
    if (asset === "XLM"  && amt < 1.0)    return false;
    if (asset === "USDC" && amt < 1.0)    return false;
    if (["VELO", "SHX", "AQUA", "AFR"].includes(asset)  && amt < 1000)  return false;
    if (["LSP", "SSLX"].includes(asset)                  && amt < 10000) return false;
    // Any unlisted XLM token (VTRX, airdrops, etc.) is rejected outright
    if (!["XLM", "USDC", "VELO", "SHX", "AQUA", "AFR", "LSP", "SSLX"].includes(asset)) return false;
    return true;
  }

  if (chain === "dag")                                         return amt >= 2;
  if (chain === "bitcoin" || chain === "ethereum")             return amt >= 0.001;
  return amt >= 1.0;
}

// ─── Grouped by (address + direction) ─────────────────────────────────────────
interface GroupedRow {
  address: string;
  direction: "in" | "out";
  totalValue: number;
  txCount: number;
  latestTs: string;
  asset: string;
}

// ─── Multi-wallet analysis color palette ─────────────────────────────────────
const WALLET_COLORS = [
  { dot: "bg-emerald-400", text: "text-emerald-300", bg: "bg-emerald-950/40", border: "border-emerald-500/30" },
  { dot: "bg-blue-400",    text: "text-blue-300",    bg: "bg-blue-950/40",    border: "border-blue-500/30"    },
  { dot: "bg-amber-400",   text: "text-amber-300",   bg: "bg-amber-950/40",   border: "border-amber-500/30"   },
  { dot: "bg-purple-400",  text: "text-purple-300",  bg: "bg-purple-950/40",  border: "border-purple-500/30"  },
  { dot: "bg-rose-400",    text: "text-rose-300",    bg: "bg-rose-950/40",    border: "border-rose-500/30"    },
] as const;

// ─── Multi-wallet commingling types ──────────────────────────────────────────
interface MultiGraphNode {
  address: string;
  depth: number;
  via: string | null;
  pathChain: string[];
  txCount: number;
  totalValueUsd: number;
}

interface MultiSharedEntry {
  address: string;
  knownInfo?: { label: string; type: "exchange" | "genesis" | "defi" | "flagged" | "bridge" | "dag-team" | "official" | "mixer" | "founder" };
  appearances: Array<{
    wallet: string;
    depth: number;
    txCount: number;
    totalValueUsd: number;
    via: string | null;
    pathChain: string[];
  }>;
}

interface MultiAnalysisResult {
  trackedWallets: string[];
  sharedCounterparties: MultiSharedEntry[];
  commonEndpoints: MultiSharedEntry[];
  patterns: Array<{
    id: number;
    sharedAddr: string;
    knownInfo?: { label: string; type: "exchange" | "genesis" | "defi" | "flagged" | "bridge" | "dag-team" | "official" | "mixer" | "founder" };
    totalTxCount: number;
    totalValueUsd: number;
    paths: Array<{ wallet: string; path: string[] }>;
  }>;
}

// ─── Connection Finder types ──────────────────────────────────────────────────
interface TieFinderHop {
  address: string;
  tx: Tx | null;
}

interface TieFinderResult {
  walletA: string;
  walletB: string;
  chain: string;
  maxHops: number;
  commonNodes: Array<{
    address: string;
    pathFromA: TieFinderHop[];
    pathFromB: TieFinderHop[];
  }>;
  nodesScannedA: number;
  nodesScannedB: number;
}

// ─── Commingle Check types ────────────────────────────────────────────────────
interface CommingleFinding {
  sharedAddress: string;
  knownInfo?: { label: string; type: string };
  tier: number;
  // All input wallets that reach this shared node — no wallet is "primary".
  // Ordered by wallet position in the input list (Wallet 1, 2, 3…).
  peerPaths: Array<{ wallet: string; path: string[] }>;
  txCountTarget: number;
}

interface CommingleCheckResult {
  targetWallet: string;
  comparisonWallets: string[];
  chain: string;
  scannedAt: string;
  findings: CommingleFinding[];
  tieredCounts: [number, number, number, number, number, number];
  totalScanned: number;
  // Best TX for each intermediate hop segment: key = "fromAddr::toAddr"
  segmentTxs: Record<string, Tx | null>;
  // Debug stats per intermediate hop wallet: how many pages/ops were fetched
  hopFetchStats: Record<string, { pages: number; txs: number; rateLimitEvents?: number; failReason?: string }>;
  // Filtered transactions for each cluster wallet (for display purposes)
  walletTxs: Record<string, Tx[]>;
  // First-class exchange flow data detected during the scan from raw transaction history.
  // Each entry = one (exchAddr × sourceWallet) pair with ALL matching transactions.
  // Populated from unfiltered tx fetches so no asset/amount filter can drop exchange flows.
  exchFlows: Array<{
    exchAddr: string;
    exchLabel: string;
    exchType: string;
    sourceWallet: string;
    txs: Tx[];
  }>;
}

const DAG_BATCH = 250;
const XRP_INIT = 200;
const XRP_BATCH = 500;
const OTHER_BATCH = 1000;
const MAX_TOTAL = 25000;

// Normalize XDC addresses: xdc-prefix → 0x-prefix, lowercase.
// Safe to call on any chain — returns the address unchanged for non-XDC chains.
const normalizeXdcAddress = (addr: string): string => {
  if (!addr) return addr;
  let a = addr.trim().toLowerCase();
  if (a.startsWith("xdc")) a = "0x" + a.slice(3);
  return a;
};

// Universal address normalizer — applies chain-specific normalization.
// For XDC: xdc-prefix → 0x-prefix + lowercase. All other chains: unchanged.
// Use this for EVERY address that appears in a URL, query key, or fetch call.
const getNormalizedAddress = (addr: string, chain: string): string => {
  if (chain !== "xdc") return addr;
  return normalizeXdcAddress(addr);
};

// Helper to resolve KNOWN_LABELS for any chain — handles XDC xdc→0x normalisation
// and a lowercase fallback so lookups are robust across address formats.
const getKnownInfo = (addr: string, chain: string): { label: string; type: string } | null => {
  if (!addr) return null;
  let lookupAddr = addr.trim();
  if (chain.toLowerCase() === "xdc" && lookupAddr.toLowerCase().startsWith("xdc")) {
    lookupAddr = "0x" + lookupAddr.slice(3).toLowerCase();
  }
  return KNOWN_LABELS[lookupAddr] ?? KNOWN_LABELS[addr] ?? KNOWN_LABELS[addr.toLowerCase()] ?? null;
};

// ─── Peel-chain / layering pattern detector ───────────────────────────────────
// Module-level so it can be called from any report generator without closure.
function detectPeelChainPatterns(txs: Tx[], chain: string): {
  peelChainScore: number;
  patternsDetected: string[];
  suspiciousOutflowCount: number;
  recommendedAction: string;
} {
  if (txs.length === 0) {
    return { peelChainScore: 0, patternsDetected: [], suspiciousOutflowCount: 0, recommendedAction: "Insufficient data." };
  }
  const patterns: string[] = [];
  let score = 0;

  const inTxs  = txs.filter(t => t.direction === "in");
  const outTxs = txs.filter(t => t.direction === "out");
  const outVals = outTxs.map(t => parseFloat(t.value) || 0).filter(v => v > 0);
  const medianOutVal = outVals.length > 0
    ? [...outVals].sort((a, b) => a - b)[Math.floor(outVals.length / 2)]
    : 0;

  // H1: Multiple small outflows shortly after a large inflow
  const largeInflows = inTxs.filter(t => medianOutVal > 0 && (parseFloat(t.value) || 0) > medianOutVal * 5);
  let smallOutAfterLargeIn = 0;
  for (const bigIn of largeInflows) {
    const inTime = new Date(bigIn.timestamp).getTime();
    const followOuts = outTxs.filter(t => {
      const ot = new Date(t.timestamp).getTime();
      return ot > inTime && ot < inTime + 86_400_000 &&
             (parseFloat(t.value) || 0) < (parseFloat(bigIn.value) || 0) * 0.5;
    });
    smallOutAfterLargeIn += followOuts.length;
  }
  if (smallOutAfterLargeIn >= 3) { patterns.push("Multiple small outflows after large inflow"); score += 25; }

  // H2: Many unique counterparties with below-average amounts
  const outCPs    = new Set(outTxs.map(t => t.to).filter(Boolean));
  const avgOutVal = outVals.length > 0 ? outVals.reduce((s, v) => s + v, 0) / outVals.length : 0;
  const smallOuts = outTxs.filter(t => (parseFloat(t.value) || 0) < avgOutVal * 0.3);
  if (outCPs.size >= 5 && outTxs.length > 0 && smallOuts.length / outTxs.length > 0.5) {
    patterns.push("High unique counterparty count with small amounts"); score += 20;
  }

  // H3: Outflows to known exchange addresses (layering endpoint)
  const exchOutCount = outTxs.filter(t => t.to && getKnownInfo(t.to, chain)?.type === "exchange").length;
  if (exchOutCount >= 2) { patterns.push("Repeated outflows to known exchange addresses"); score += 30; }

  // H4: Timing clustering — burst of outflows within 1 hour
  if (outTxs.length >= 3) {
    const sorted = outTxs.map(t => new Date(t.timestamp).getTime()).filter(isFinite).sort((a, b) => a - b);
    let maxCluster = 0;
    for (let i = 0; i < sorted.length; i++) {
      const c = sorted.filter(t => t - sorted[i] >= 0 && t - sorted[i] <= 3_600_000).length;
      if (c > maxCluster) maxCluster = c;
    }
    if (maxCluster >= 4) { patterns.push("Timing clustering of outflows"); score += 15; }
  }

  // H5: XRP destination tags on outflows — exchange deposit layering signal
  if (chain === "xrp") {
    type TxT = Tx & { destinationTag?: number | null };
    const tagOuts = (outTxs as TxT[]).filter(t => t.destinationTag != null);
    if (tagOuts.length >= 2) { patterns.push("XRP destination tags on outflows — exchange deposit layering"); score += 10; }
  }

  score = Math.min(100, score);
  const suspiciousOutflowCount = smallOuts.length + exchOutCount;
  let recommendedAction = "No significant layering signals detected.";
  if      (score >= 60) recommendedAction = "HIGH peel-chain likelihood — trace each outflow hop; subpoena identified exchange endpoints immediately.";
  else if (score >= 30) recommendedAction = "MEDIUM peel-chain signals — expand TX history and investigate exchange deposit addresses.";
  else if (score  >  0) recommendedAction = "LOW signals — monitor for additional layering activity and re-run with full history.";

  return { peelChainScore: score, patternsDetected: patterns, suspiciousOutflowCount, recommendedAction };
}

export default function WalletDetail() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const address = (params.address || "").trim();
  type ChainId = "ethereum" | "bitcoin" | "xrp" | "xlm" | "hbar" | "xdc" | "dag";
  const chain = (new URLSearchParams(window.location.search).get("chain") || "ethereum") as ChainId;
  // For XDC, normalise xdc-prefix → 0x-prefix so the API always gets a valid address.
  // All other chains use the address as-is. Used for EVERY URL and React Query cache key.
  const txAddress = getNormalizedAddress(address, chain);
  // XDC debug: logged on every render; fallbackUsed is set to true after load
  // if all server-side API endpoints returned 0 transactions.
  const [xdcFallbackUsed, setXdcFallbackUsed] = useState(false);
  if (chain === "xdc") {
    console.log(`[XDC DEBUG] Normalized: ${txAddress} | Fallback used: ${xdcFallbackUsed}`);
  }

  // ── Ledger view toggles ──
  const [groupByCounterparty, setGroupByCounterparty] = useState(true);
  type ViewMode = "in-first" | "out-first" | "mixed";
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    try { return (localStorage.getItem("chaintrace-view-mode") as ViewMode) ?? "in-first"; }
    catch { return "in-first"; }
  });
  function setAndSaveViewMode(m: ViewMode) {
    setViewMode(m);
    try { localStorage.setItem("chaintrace-view-mode", m); } catch { /* noop */ }
  }

  // ── Group sort (only active when groupByCounterparty is ON) ──
  type GroupSort = "most-txs" | "highest-value" | "recent" | "exchange-first";
  const [groupSort, setGroupSort] = useState<GroupSort>("most-txs");

  // ── Direction filter (only active when groupByCounterparty is ON) ──
  type DirFilter = "all" | "only-in" | "only-out";
  const [dirFilter, setDirFilter] = useState<DirFilter>("all");

  // ── Minimum amount filter — chain-specific default (BTC/ETH show small transfers) ──
  const defaultMinAmount = chain === "bitcoin" || chain === "ethereum" ? 0.001
                         : chain === "dag" ? MIN_AMOUNT_DAG
                         : 1;
  const [minAmount, setMinAmount] = useState(defaultMinAmount);
  const [minAmountInput, setMinAmountInput] = useState(String(defaultMinAmount));

  // ── All pagination state in one ref — plain mutable object, zero stale-closure risk ──
  // Reading page.current in render always gives the latest value.
  // setAllTxs(page.current.txs) is the only state update needed to trigger a re-render.
  const page = useRef({
    txs: [] as Tx[],
    cursor: null as string | null,
    hasMore: false,
    busy: false,
    error: null as string | null,
    status: null as string | null,
  });

  // allTxs is state ONLY so useMemo dependencies (filteredTxs, groupedRows) re-run on changes.
  // Everything else is read directly from page.current in the render.
  const [allTxs, setAllTxs] = useState<Tx[]>([]);
  const [showDonate, setShowDonate] = useState(false);
  const [copiedDonate, setCopiedDonate] = useState<string | null>(null);
  const copyDonateAddr = (addr: string) => {
    navigator.clipboard.writeText(addr).catch(() => {});
    setCopiedDonate(addr);
    setTimeout(() => setCopiedDonate(null), 2000);
  };

  // ── Multi-wallet selection ──────────────────────────────────────────────────
  const [selectedWallets, setSelectedWallets] = useState<Set<string>>(new Set());
  const toggleSelected = (addr: string) =>
    setSelectedWallets((prev) => { const s = new Set(prev); if (s.has(addr)) s.delete(addr); else s.add(addr); return s; });
  const clearSelected = () => setSelectedWallets(new Set());

  // ── Investigative report modal ─────────────────────────────────────────────
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportCopied, setReportCopied] = useState(false);
  const [reportLinkCopied, setReportLinkCopied] = useState(false);
  const [reportContent, setReportContent] = useState("");
  const [reportTitle, setReportTitle] = useState("");
  const [reportJsonData, setReportJsonData] = useState<unknown>(null);

  // ── Audit log + tamper-evident signature footer ────────────────────────────────
  // Appended to every report. SHA-256 is computed over all content up to (but
  // not including) the seal block itself, so any post-generation alteration
  // changes the hash and can be detected.
  function auditAndSign(
    lines: string[],
    meta: {
      reportType: string;
      chain: string;
      target: string;
      comparisons?: string[];
      depth?: string;
      minAmount?: string;
      nodesScanned?: number;
      walletLabels?: boolean;
      victimWallet?: string;
      victimName?: string;
    }
  ): string {
    const now  = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const dbl  = "═".repeat(64);
    const rule = "─".repeat(66);

    lines.push("");
    lines.push(dbl);
    lines.push("AUDIT LOG \u2014 CHAIN OF CUSTODY");
    lines.push(dbl);
    lines.push(`Report Type     : ${meta.reportType}`);
    lines.push(`Generated by    : CryptoChainTrace User`);
    lines.push(`Timestamp       : ${now}`);
    lines.push(`Chain           : ${meta.chain}`);
    if (meta.walletLabels) {
      lines.push(`Wallet 1        : ${meta.target}`);
      (meta.comparisons ?? []).forEach((w, i) =>
        lines.push(`Wallet ${i + 2}        : ${w}`)
      );
    } else {
      lines.push(`Target Wallet   : ${meta.target}`);
      (meta.comparisons ?? []).forEach((w, i) =>
        lines.push(`Comparison ${String(i + 1).padEnd(5)}: ${w}`)
      );
    }
    if (meta.depth        !== undefined) lines.push(`Depth           : ${meta.depth}`);
    if (meta.minAmount    !== undefined) lines.push(`Min Tx Amount   : ${meta.minAmount}`);
    if (meta.nodesScanned !== undefined) lines.push(`Nodes Scanned   : ${meta.nodesScanned}`);
    lines.push(`Report Version  : v1.2.4`);
    lines.push(`Platform        : cryptochaintrace.vercel.app`);
    lines.push("");
    lines.push(dbl);
    lines.push("Generated by CryptoChainTrace  \u00b7  cryptochaintrace.vercel.app");
    lines.push("\u00a9 2026 Ball Deep Crypto  \u2022  For Official Investigative Use Only");

    const preHash = lines.join("\n");
    const hash    = sha256Sync(preHash);

    lines.push("");
    lines.push(rule);
    lines.push("DIGITAL SIGNATURE / TAMPER-EVIDENT SEAL");
    lines.push(`Report Hash  : ${hash}`);
    lines.push(`Generated    : ${now}`);
    lines.push("This document is cryptographically signed and tamper-evident.");
    lines.push("Any alteration will invalidate this hash.");
    lines.push(rule);
    return lines.join("\n");
  }

  function generateReport(): string {
    const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = chain.toUpperCase();
    const fmtAmt = (v: string, dir: "in" | "out") => {
      const n = parseFloat(v);
      const sign = dir === "in" ? "+" : "−";
      if (!n || isNaN(n)) return `${sign}0.00`;
      // Use enough decimals so tiny BTC/XRP/DAG amounts never round to 0.0000
      const abs = Math.abs(n);
      const decimals = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      return `${sign}${n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
    };
    const fmtDate = (ts: string) => ts ? ts.replace("T", " ").slice(0, 16) + " UTC" : "—";
    const fmtVal  = (v: number)  => v.toLocaleString("en-US", { minimumFractionDigits: 3, maximumFractionDigits: 6 });
    const sep = (label = "") => label
      ? `\n─── ${label} ${"─".repeat(Math.max(0, 60 - label.length - 5))}`
      : "─".repeat(64);
    const lines: string[] = [];
    // ── Private-only filtering — same rule as Commingle Check ──────────────────
    // exchange/bridge/genesis = infrastructure flows → Exchange section only.
    // DAG5KmHp9gFS... = genesis/reward wallet, hard-excluded from all private sections.
    const REPORT_EXCL = new Set(["DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz"]);
    const isExchAddr  = (a: string) => ["exchange", "bridge", "genesis"].includes(KNOWN_LABELS[a]?.type ?? "");
    const isPrivAddr  = (a: string) => !isExchAddr(a) && !REPORT_EXCL.has(a);

    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║        INVESTIGATIVE REPORT — CryptoChainTrace              ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated : ${now}`);
    lines.push(`Chain     : ${chainUp}   |   Selected Wallets : ${selectedWallets.size}`);
    lines.push("");
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);
    lines.push("");

    // Subject wallet
    lines.push(sep("SUBJECT WALLET"));
    lines.push("");
    const rootLabel = KNOWN_LABELS[address];
    lines.push(`  [ROOT]  ${address}`);
    if (rootLabel) lines.push(`          Label   : ${rootLabel.label} (${rootLabel.type})`);
    lines.push(`          Balance : ${wallet?.balance ?? "?"} ${chainUp}`);
    lines.push(`          Txs     : ${wallet?.transactionCount ?? allTxs.length}`);
    lines.push(`          Last    : ${wallet?.lastSeen ? wallet.lastSeen.slice(0, 10) : "unknown"}`);
    lines.push("");

    // Build per-address map from groupedRows (filtered by selection)
    const byAddr = new Map<string, GroupedRow[]>();
    for (const r of groupedRows) {
      if (!selectedWallets.has(r.address)) continue;
      if (!byAddr.has(r.address)) byAddr.set(r.address, []);
      byAddr.get(r.address)!.push(r);
    }
    // Ensure every selected wallet appears even if filtered out by minAmount
    for (const a of selectedWallets) if (!byAddr.has(a)) byAddr.set(a, []);

    // Private-only tree: exchanges, bridges, genesis, and hard-excluded wallets are
    // stripped here and appear exclusively in the Exchange section below.
    const addrs     = Array.from(byAddr.keys());
    const privAddrs = addrs.filter(isPrivAddr);
    lines.push(sep(`TRANSACTION TREE — PRIVATE WALLETS  (${address.slice(0, 10)}...)  →  ${privAddrs.length} private`));
    lines.push("");
    if (privAddrs.length === 0) {
      lines.push("  No private wallet counterparties selected.");
      lines.push("  All selected counterparties are exchange / bridge / official wallets.");
      lines.push("  See the Exchange / Custodial / Bridge / Official Flows section below.");
      lines.push("");
    } else {
      lines.push(`  ${address}${KNOWN_LABELS[address] ? `  ← ${KNOWN_LABELS[address].label.toUpperCase()}` : ""}`);
      lines.push(`  │`);
      privAddrs.forEach((addr, i) => {
        const rows = byAddr.get(addr)!;
        const known = KNOWN_LABELS[addr];
        const isLast = i === privAddrs.length - 1;
        const connector = isLast ? "└──" : "├──";
        const indent    = isLast ? "   " : "│  ";
        const inRow  = rows.find(r => r.direction === "in");
        const outRow = rows.find(r => r.direction === "out");
        const dirLabel = inRow && outRow ? "IN+OUT" : outRow ? "OUT" : "IN";
        const totalTxs = rows.reduce((s, r) => s + r.txCount, 0);
        const totalVal = rows.reduce((s, r) => s + r.totalValue, 0);
        const lastTs = rows.reduce((l, r) => r.latestTs > l ? r.latestTs : l, "").slice(0, 10);
        const labelStr = known ? `  ← ${known.label.toUpperCase()}` : "";

        lines.push(`  ${connector} ${dirLabel}  →  ${addr}${labelStr}`);
        lines.push(`  ${indent}   Total : ${totalTxs.toLocaleString("en-US")} tx${totalTxs !== 1 ? "s" : ""}  |  ${fmtVal(totalVal)} ${chainUp}  |  Last: ${lastTs || "—"}`);

        // Individual transactions for this counterparty
        const txsForAddr = allTxs
          .filter(t => {
            const cp = t.direction === "in" ? t.from : t.to;
            if (cp !== addr) return false;
            return passesAnalysisFilter(t, chain);
          })
          .slice(0, 12);

        if (txsForAddr.length > 0) {
          lines.push(`  ${indent}   │`);
          txsForAddr.forEach((tx, ti) => {
            const txConn     = ti === txsForAddr.length - 1 ? "└──" : "├──";
            const txChildPfx = ti === txsForAddr.length - 1 ? "   " : "│  ";
            const dir    = tx.direction === "in" ? "IN " : "OUT";
            const amt    = fmtAmt(tx.value, tx.direction as "in" | "out");
            const asset  = tx.tokenSymbol || chainUp;
            const usd    = tx.valueUsd > 0 ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]` : "";
            lines.push(`  ${indent}   ${txConn} [${dir}]  From: ${tx.from || "—"} → To: ${tx.to || "—"}`);
            lines.push(`  ${indent}   ${txChildPfx}      Amount : ${amt} ${asset}${usd}`);
            lines.push(`  ${indent}   ${txChildPfx}      TX     : ${tx.hash || "(none)"}`);
            lines.push(`  ${indent}   ${txChildPfx}      Date   : ${fmtDate(tx.timestamp || "")}`);
            if (tx.destinationTag != null) lines.push(`  ${indent}   ${txChildPfx}      Tag    : ${tx.destinationTag}`);
            if (tx.memo)                   lines.push(`  ${indent}   ${txChildPfx}      Memo   : ${tx.memo}`);
          });
          const remaining = totalTxs - txsForAddr.length;
          if (remaining > 0) lines.push(`  ${indent}       (+ ${remaining} more transactions not shown)`);
        }

        if (!isLast) lines.push(`  │`);
      });
      lines.push("");
    }

    // Flow summary — private wallets only; exchanges appear in the Exchange section below.
    const outRows = groupedRows.filter(r => selectedWallets.has(r.address) && r.direction === "out" && isPrivAddr(r.address));
    const inRows  = groupedRows.filter(r => selectedWallets.has(r.address) && r.direction === "in"  && isPrivAddr(r.address));
    if (outRows.length > 0 || inRows.length > 0) {
      lines.push(sep("TRANSACTION FLOW SUMMARY"));
      lines.push("");
      if (outRows.length > 0) {
        lines.push(`  OUTBOUND  (${address.slice(0, 8)}...  →  selected wallets)`);
        for (const r of outRows.slice(0, 10)) {
          const kn = KNOWN_LABELS[r.address];
          lines.push(`    → ${r.address}${kn ? `  [${kn.label}]` : ""}  |  ${r.txCount.toLocaleString("en-US")} tx  |  ${fmtVal(r.totalValue)} ${chainUp}`);
        }
        lines.push("");
      }
      if (inRows.length > 0) {
        lines.push(`  INBOUND   (selected wallets  →  ${address.slice(0, 8)}...)`);
        for (const r of inRows.slice(0, 10)) {
          const kn = KNOWN_LABELS[r.address];
          lines.push(`    ← ${r.address}${kn ? `  [${kn.label}]` : ""}  |  ${r.txCount.toLocaleString("en-US")} tx  |  ${fmtVal(r.totalValue)} ${chainUp}`);
        }
        lines.push("");
      }
    }

    lines.push(sep("NOTE — EXCHANGE / BRIDGE / OFFICIAL FLOWS"));
    lines.push("");
    lines.push("  Exchange, bridge, and official flows are excluded from this report.");
    lines.push("  Use the EXCHANGE FLOWS REPORT (button on the wallet page) to view");
    lines.push("  all transactions touching known exchange and custodial addresses.");
    lines.push("");

    return auditAndSign(lines, {
      reportType: "Wallet Profile Report",
      chain: chain.toUpperCase(),
      target: address,
    });
  }

  function generateTrailReport(): string {
    const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = chain.toUpperCase();
    const sep = (label = "") => label
      ? `\n─── ${label} ${"─".repeat(Math.max(0, 60 - label.length - 5))}`
      : "─".repeat(64);
    const lines: string[] = [];

    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║          TRAIL TRACE REPORT — CryptoChainTrace              ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated : ${now}`);
    lines.push(`Chain     : ${chainUp}   |   Nodes: ${trailEntries.length}   |   Commingling: ${comminglingAddresses.size}`);
    lines.push("");
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);
    lines.push("");

    if (trailEntries.length === 0) {
      lines.push("  No trail data. Run START TRAIL TRACE first.");
      return lines.join("\n");
    }

    const root = trailEntries[0];
    lines.push(sep("ROOT WALLET"));
    lines.push("");
    const rootKnown = KNOWN_LABELS[root.address];
    lines.push(`  [ROOT]  ${root.address}`);
    if (rootKnown) lines.push(`          Label   : ${rootKnown.label.toUpperCase()}`);
    lines.push(`          Tx Count : ${root.txCount}   |   USD: $${root.totalValueUsd.toLocaleString()}`);
    lines.push("");

    lines.push(sep("TRAIL TREE"));
    lines.push("");

    const fmtTrailAmt = (v: string, dir: string) => {
      const n   = parseFloat(v);
      const abs = Math.abs(n);
      const dec = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      const sign = dir === "in" ? "+" : "−";
      return `${sign}${n.toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec })}`;
    };
    const printNode = (entry: TrailEntry, prefix: string, isLast: boolean) => {
      const conn     = isLast ? "└── " : "├── ";
      const childPfx = isLast ? "     " : "│    ";
      const known    = KNOWN_LABELS[entry.address];
      const isComm   = comminglingAddresses.has(entry.address);
      const flags    = [
        known       ? `← ${known.label.toUpperCase()}` : "",
        isComm      ? "⚠ COMMINGLING HUB" : "",
        entry.error ? "! ERROR" : "",
      ].filter(Boolean).join("  ");
      // Full address on connector line — no truncation
      lines.push(`  ${prefix}${conn}${entry.address}${flags ? "  " + flags : ""}`);
      lines.push(`  ${prefix}${childPfx}Depth: ${entry.depth}   Txs: ${entry.txCount}   USD: $${entry.totalValueUsd.toLocaleString()}`);
      // Best IN + OUT transactions for this hop from loaded history
      const hopPool = allTxs.filter(t =>
        (t.direction === "in" ? t.from : t.to) === entry.address &&
        passesSpamFilter(t, chain)
      );
      const bestIn  = hopPool.filter(t => t.direction === "in" ).sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      const bestOut = hopPool.filter(t => t.direction === "out").sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      const hopTxs  = [bestIn, bestOut].filter(Boolean) as Tx[];
      if (hopTxs.length > 0) {
        hopTxs.forEach((tx) => {
          const dir   = tx.direction === "in" ? "IN " : "OUT";
          const asset = (tx as Tx & { tokenSymbol?: string }).tokenSymbol || chainUp;
          const amt   = `${fmtTrailAmt(tx.value, tx.direction)} ${asset}`;
          const usd   = tx.valueUsd > 0
            ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]`
            : "";
          const date  = tx.timestamp ? tx.timestamp.replace("T", " ").slice(0, 16) + " UTC" : "—";
          lines.push(`  ${prefix}${childPfx}[${dir}]  From: ${tx.from || "—"} → To: ${tx.to || "—"}`);
          lines.push(`  ${prefix}${childPfx}       Amount : ${amt}${usd}`);
          lines.push(`  ${prefix}${childPfx}       TX     : ${tx.hash ?? "(none)"}`);
          lines.push(`  ${prefix}${childPfx}       Date   : ${date}`);
          if (tx.destinationTag != null) lines.push(`  ${prefix}${childPfx}       Tag    : ${tx.destinationTag}`);
          if (tx.memo)                   lines.push(`  ${prefix}${childPfx}       Memo   : ${tx.memo}`);
        });
      } else {
        lines.push(`  ${prefix}${childPfx}(no TX history loaded for this hop)`);
      }
      const children = trailEntries.filter(e => e.parentAddress === entry.address);
      children.forEach((child, ci) => printNode(child, prefix + childPfx, ci === children.length - 1));
    };

    const rootChildren = trailEntries.filter(e => e.parentAddress === root.address);
    rootChildren.forEach((child, i) => printNode(child, "", i === rootChildren.length - 1));
    lines.push("");

    // Commingling hubs: exclude exchange/bridge/genesis/hard-excluded addresses —
    // only private wallet addresses should be flagged as commingling hubs.
    const TRAIL_EXCLUDED = new Set(["DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz"]);
    const privateHubs = Array.from(comminglingAddresses).filter((a) => {
      if (TRAIL_EXCLUDED.has(a)) return false;
      const t = KNOWN_LABELS[a]?.type;
      return t !== "exchange" && t !== "bridge" && t !== "genesis";
    });
    if (privateHubs.length > 0) {
      lines.push(sep("COMMINGLING HUBS DETECTED"));
      lines.push("");
      for (const addr of privateHubs) {
        const known = KNOWN_LABELS[addr];
        const entry = trailEntries.find(e => e.address === addr);
        const dagTag = known?.type === "dag-team" ? "  ◄ DAG OFFICIAL ENTITY" : "";
        lines.push(`  ⚠  ${addr}${known ? `  [${known.label.toUpperCase()}]${dagTag}` : ""}`);
        if (entry) lines.push(`       Txs: ${entry.txCount}   Depth: ${entry.depth}   USD: $${entry.totalValueUsd.toLocaleString()}`);
      }
      lines.push("");
    }

    lines.push(sep("NOTE — EXCHANGE / BRIDGE / OFFICIAL FLOWS"));
    lines.push("");
    lines.push("  Exchange, bridge, and official flows are excluded from this report.");
    lines.push("  Use the EXCHANGE FLOWS REPORT (button on the wallet page) to view");
    lines.push("  all transactions touching known exchange and custodial addresses.");
    lines.push("");

    return auditAndSign(lines, {
      reportType: "Trail Trace Report",
      chain: chainUp,
      target: address,
      depth: "6 hops",
    });
  }

  function generateCommingleReport(): string {
    return ((commingleResult: CommingleCheckResult | null): string => {
    if (!commingleResult) return "";
    const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = commingleResult.chain.toUpperCase();
    const sep = (label = "") => label
      ? `\n─── ${label} ${"─".repeat(Math.max(0, 60 - label.length - 5))}`
      : "─".repeat(64);
    const fmtDate = (ts: string) => ts ? ts.replace("T", " ").slice(0, 16) + " UTC" : "—";
    const fmtAmt = (v: string, dir: "in" | "out") => {
      const n = parseFloat(v);
      const sign = dir === "in" ? "+" : "−";
      if (!n || isNaN(n)) return `${sign}0.00`;
      // Use enough decimals so tiny BTC/XRP/DAG amounts never round to 0.0000
      const abs = Math.abs(n);
      const decimals = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      return `${sign}${n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
    };
    const lines: string[] = [];

    // Best single TX between any wallet and a given hop address —
    // checks segmentTxs, walletTxs for that wallet, then allTxs for the target.
    const bestTxForWallet = (wallet: string, hopAddr: string): Tx | null => {
      const segMap = commingleResult.segmentTxs ?? {};
      const seg    = segMap[`${wallet}::${hopAddr}`] ?? segMap[`${hopAddr}::${wallet}`] ?? null;
      if (seg) return seg;
      // Check wallet's own TX pool (wallet's perspective → hopAddr)
      const wPool  = (commingleResult.walletTxs[wallet] ?? [])
        .filter(t => (t.direction === "in" ? t.from : t.to) === hopAddr)
        .sort((a, b) => parseFloat(b.value) - parseFloat(a.value));
      if (wPool.length > 0) return wPool[0];
      // Also check hopAddr's own TX pool (reverse perspective → wallet)
      const hPool  = (commingleResult.walletTxs[hopAddr] ?? [])
        .filter(t => (t.direction === "in" ? t.from : t.to) === wallet)
        .sort((a, b) => parseFloat(b.value) - parseFloat(a.value));
      if (hPool.length > 0) return hPool[0];
      if (wallet === commingleResult.targetWallet) {
        const pool = allTxs
          .filter(t => (t.direction === "in" ? t.from : t.to) === hopAddr && passesAnalysisFilter(t, commingleResult.chain))
          .sort((a, b) => parseFloat(b.value) - parseFloat(a.value));
        if (pool.length > 0) return pool[0];
      }
      return null;
    };

    // Return up to `limit` txs sorted by amount descending (most significant first)
    const keyTxsFor = (addr: string, limit = 5) =>
      allTxs
        .filter((t) =>
          (t.direction === "in" ? t.from : t.to) === addr &&
          passesAnalysisFilter(t, commingleResult.chain) &&
          (commingleMinAmount <= 0 || parseFloat(t.value) >= commingleMinAmount)
        )
        .sort((a, b) => parseFloat(b.value) - parseFloat(a.value))
        .slice(0, limit);
    // Return [highest-value IN tx, highest-value OUT tx] — exactly 2 TXs max
    // This gives the most significant transaction in each direction for investigative clarity.
    const bestInOut = (addr: string): Tx[] => {
      // Primary: allTxs — user-loaded history, direction from target's perspective.
      const pool = allTxs.filter((t) =>
        (t.direction === "in" ? t.from : t.to) === addr &&
        passesAnalysisFilter(t, commingleResult.chain) &&
        (commingleMinAmount <= 0 || parseFloat(t.value) >= commingleMinAmount)
      );
      const top = (dir: "in" | "out") =>
        pool.filter((t) => t.direction === dir)
            .sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      const fromAllTxs = [top("in"), top("out")].filter(Boolean) as Tx[];
      if (fromAllTxs.length > 0) return fromAllTxs;

      // Fallback 1: segmentTxs — hop-fetched full history, unfiltered by asset type.
      // The best (highest-value) TX between target and addr is stored under both key orders.
      const target = commingleResult.targetWallet;
      const segMap = commingleResult.segmentTxs ?? {};
      const segTx = segMap[`${target}::${addr}`] ?? segMap[`${addr}::${target}`] ?? null;
      if (segTx) return [segTx];

      // Fallback 2: walletTxs[target] — exchange scan (up to 2,000 ops, target's POV).
      const wPool = (commingleResult.walletTxs[target] ?? []).filter((t) =>
        (t.direction === "in" ? t.from : t.to) === addr
      );
      const wTop = (dir: "in" | "out") =>
        wPool.filter((t) => t.direction === dir)
             .sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      return [wTop("in"), wTop("out")].filter(Boolean) as Tx[];
    };

    // Format a path array, annotating each hop with its known label
    const fmtPath = (path: string[]) =>
      path.map(addr => {
        const kn = KNOWN_LABELS[addr];
        return kn ? `${addr}  [${kn.label}]` : addr;
      }).join(" → ");

    // Emit a detailed TX block — each TX shows explicit From → To addresses,
    // then Amount / full TX hash / Date on separate indented lines.
    const emitTxs = (txs: Tx[], pad: string) => {
      // Apply global spam filter — drop dust, 0-value ops, and below-chain-minimum TXs.
      const clean = txs.filter(t => passesAnalysisFilter(t, commingleResult.chain));
      if (clean.length === 0) return;
      lines.push(`${pad}│`);
      clean.forEach((tx, ti) => {
        const isLast   = ti === clean.length - 1;
        const conn     = isLast ? "└─" : "├─";
        const childPfx = isLast ? "   " : "│  ";
        const dir      = tx.direction === "in" ? "IN " : "OUT";
        const amt      = fmtAmt(tx.value, tx.direction as "in" | "out");
        const asset    = (tx as Tx & { tokenSymbol?: string }).tokenSymbol || chainUp;
        const usd      = tx.valueUsd > 0
          ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]`
          : "";
        lines.push(`${pad}${conn} [${dir}]  From: ${tx.from || "—"} → To: ${tx.to || "—"}`);
        lines.push(`${pad}${childPfx}  Amount: ${amt} ${asset}${usd}`);
        lines.push(`${pad}${childPfx}  TX    : ${tx.hash || "(none)"}`);
        lines.push(`${pad}${childPfx}  Date  : ${fmtDate(tx.timestamp || "")}`);
        if (tx.destinationTag != null) lines.push(`${pad}${childPfx}  ↳ Destination Tag : ${tx.destinationTag}`);
        if (tx.memo)                   lines.push(`${pad}${childPfx}  ↳ Memo            : ${tx.memo}`);
      });
    };

    // Emit one intermediate hop row: both wallet addresses + best cached TX.
    // Tries key fa::ta first, then ta::fa (covers both fetch directions).
    // Uses "Transactions — Hop N" label so the PDF renderer applies hop-tx-label CSS.
    const emitHopSegment = (fa: string, ta: string, hopNum: number) => {
      const fKn = KNOWN_LABELS[fa]; const tKn = KNOWN_LABELS[ta];
      // Hop address lines — explicit From / To before the TX block
      lines.push(`       Hop ${hopNum}:  ${fa}${fKn ? `  [${fKn.label}]` : ""}`);
      lines.push(`                →  ${ta}${tKn ? `  [${tKn.label}]` : ""}`);
      // Look up best TX — try both key directions since fetching is one-sided
      const map = commingleResult.segmentTxs ?? {};
      const segTx = map[`${fa}::${ta}`] ?? map[`${ta}::${fa}`] ?? null;
      if (segTx) {
        lines.push(`       Transactions — Hop ${hopNum}:`);
        emitTxs([segTx], "       ");
      } else {
        lines.push(`       Transactions — Hop ${hopNum}: (TX not in fetched history — path may be indirect)`);
      }
    };

    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║        COMMINGLING CHECK REPORT — CryptoChainTrace          ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated    : ${now}`);
    lines.push(`Chain        : ${chainUp}`);
    lines.push(`Wallet 1     : ${commingleResult.targetWallet}`);
    commingleResult.comparisonWallets.forEach((w, i) => {
      lines.push(`Wallet ${i + 2}     : ${w}`);
    });
    lines.push(`Depth        : 6 tiers   |   Nodes Scanned: ${commingleResult.totalScanned}`);
    lines.push(`Min Tx Amount: ${commingleMinAmount <= 0 ? "None (all transactions included)" : `${commingleMinAmount} ${chainUp} (dust/spam/fees filtered out)`}`);
    lines.push("");
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);
    lines.push("");
    const hopStats = commingleResult.hopFetchStats ?? {};
    const hopEntries = Object.entries(hopStats);
    if (hopEntries.length > 0) {
      lines.push(`── HOP WALLET FETCH DEPTH (max 25,000 ops each) ──────────────`);
      for (const [addr, s] of hopEntries) {
        const kn = KNOWN_LABELS[addr];
        const tag = kn ? `  [${kn.label}]` : "";
        lines.push(`  ${addr}${tag}`);
        if (s.pages === 0) {
          lines.push(`    FAILED: ${s.failReason ?? "unknown error — 0 pages fetched"}`);
        } else {
          const rlNote = s.rateLimitEvents ? `  [rate-limited × ${s.rateLimitEvents} → waited & retried]` : "";
          const stopNote = s.failReason ? `  (stopped: ${s.failReason})` : "";
          lines.push(`    Fetched: ${s.txs} ops across ${s.pages} page${s.pages !== 1 ? "s" : ""}${rlNote}${stopNote}`);
        }
      }
      lines.push(`──────────────────────────────────────────────────────────────`);
      lines.push("");
    }

    const { findings: rawFindings } = commingleResult;
    // Hard-excluded addresses — stripped from ALL sections of the report entirely.
    // These are genesis/official wallets that should never appear as commingling evidence.
    const EXCLUDED_ADDRS = new Set(["DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz"]);
    const findings = rawFindings.filter((f) => !EXCLUDED_ADDRS.has(f.sharedAddress));
    // Separate private wallets from exchange/custodial nodes.
    // Only true exchanges, bridges, hot wallets, and custodial wallets are excluded —
    // genesis, official, protocol, dag-team, defi, and flagged count as private evidence.
    const isExch = (f: CommingleFinding) => {
      const t = (f.knownInfo ?? KNOWN_LABELS[f.sharedAddress])?.type ?? "";
      return ["exchange", "bridge", "hot", "custodial"].includes(t);
    };
    const privFindings = findings.filter((f) => !isExch(f));
    const exchFindings = findings.filter((f) => isExch(f));
    const t1priv = findings.filter((f) => f.tier === 1 && !isExch(f));
    const t1exch = findings.filter((f) => f.tier === 1 && isExch(f));
    const t2priv = findings.filter((f) => f.tier === 2 && !isExch(f));
    const t2exch = findings.filter((f) => f.tier === 2 && isExch(f));
    const t3priv = findings.filter((f) => f.tier === 3 && !isExch(f));
    const t3exch = findings.filter((f) => f.tier === 3 && isExch(f));
    const t4priv = findings.filter((f) => f.tier === 4 && !isExch(f));
    const t4exch = findings.filter((f) => f.tier === 4 && isExch(f));
    const t5priv = findings.filter((f) => f.tier === 5 && !isExch(f));
    const t5exch = findings.filter((f) => f.tier === 5 && isExch(f));
    const t6priv = findings.filter((f) => f.tier === 6 && !isExch(f));
    const t6exch = findings.filter((f) => f.tier === 6 && isExch(f));

    // ── Group connectivity — Union-Find over all input wallets ──────────────
    // Edges come from private findings: each finding links targetWallet ↔ comparison wallets.
    const allInputWallets = [commingleResult.targetWallet, ...commingleResult.comparisonWallets];
    const _ufP: Record<string, string> = {};
    allInputWallets.forEach(w => { _ufP[w] = w; });
    const _ufFind = (x: string): string => {
      if (_ufP[x] !== x) _ufP[x] = _ufFind(_ufP[x]);
      return _ufP[x];
    };
    const _ufUnion = (a: string, b: string) => { _ufP[_ufFind(a)] = _ufFind(b); };
    privFindings.forEach(f => {
      // Union ALL input wallets that share this finding — peerPaths covers every wallet
      // that reaches this node, regardless of which wallet is "viewed" or "primary".
      const walletsInFinding = f.peerPaths
        .map(p => p.wallet)
        .filter(w => allInputWallets.includes(w));
      for (let i = 1; i < walletsInFinding.length; i++) {
        _ufUnion(walletsInFinding[0], walletsInFinding[i]);
      }
    });
    const _compMap: Record<string, string[]> = {};
    allInputWallets.forEach(w => {
      const r = _ufFind(w);
      if (!_compMap[r]) _compMap[r] = [];
      _compMap[r].push(w);
    });
    const _clusters     = Object.values(_compMap).filter(g => g.length >= 2);
    const connectedWallets = new Set<string>(_clusters.flatMap(g => g));
    const isolatedWallets  = allInputWallets.filter(w => !connectedWallets.has(w));

    lines.push(sep("SUMMARY"));
    lines.push("");
    const dagTeamFindings = privFindings.filter((f) => (f.knownInfo ?? KNOWN_LABELS[f.sharedAddress])?.type === "dag-team");
    lines.push(`  Total Shared Nodes : ${findings.length}`);
    lines.push(`    ► Private wallets      : ${privFindings.length}  ← wallet-to-wallet commingling (key evidence)`);
    if (dagTeamFindings.length > 0) {
      lines.push(`         incl. ${dagTeamFindings.length} known DAG official entity(s)  ← marked ◄ DAG OFFICIAL ENTITY`);
    }
    lines.push(`    ► Exchange/Bridge/Offcl: ${exchFindings.length}  ← on-ramp / off-ramp / infrastructure flows`);
    lines.push("");
    lines.push(`  Tier breakdown:`);
    lines.push(`    Tier 1 (direct)  : ${t1priv.length} private  +  ${t1exch.length} exchange/official`);
    lines.push(`    Tier 2 (depth 2) : ${t2priv.length} private  +  ${t2exch.length} exchange/official`);
    lines.push(`    Tier 3 (depth 3) : ${t3priv.length} private  +  ${t3exch.length} exchange/official`);
    lines.push(`    Tier 4 (depth 4) : ${t4priv.length} private  +  ${t4exch.length} exchange/official`);
    lines.push(`    Tier 5 (depth 5) : ${t5priv.length} private  +  ${t5exch.length} exchange/official`);
    lines.push(`    Tier 6 (depth 6) : ${t6priv.length} private  +  ${t6exch.length} exchange/official`);
    lines.push("");

    if (findings.length === 0) {
      lines.push("  No shared nodes found within 6 tiers. Wallets appear unconnected.");
      lines.push("");
    } else {
      // Renders every connected wallet's trail + single best TX for a shared node finding.
      const renderSharedNodeWallets = (f: CommingleFinding) => {
        // All wallets are equal peers — label by position in the overall input list.
        // Only include wallets that are part of a connected cluster (2+ wallets).
        const allWallets: Array<{ wLabel: string; wallet: string; path: string[] }> = f.peerPaths
          .map(p => ({
            wLabel: `WALLET ${allInputWallets.indexOf(p.wallet) + 1}`,
            wallet: p.wallet,
            path: p.path,
          }))
          .filter(({ wallet }) => connectedWallets.has(wallet));
        allWallets.forEach(({ wLabel, wallet, path }, wi) => {
          const isLastW = wi === allWallets.length - 1;
          const wConn   = isLastW ? "  └──" : "  ├──";
          const wPfx    = isLastW ? "       " : "  │    ";
          const knW     = KNOWN_LABELS[wallet];
          lines.push(`${wConn} ${wLabel}  ${wallet}${knW ? `  [${knW.label}]` : ""}`);
          if (path.length > 0) {
            lines.push(`${wPfx}Trail & Transactions:`);
            for (let h = 0; h < path.length; h++) {
              const addr = path[h];
              const kn   = KNOWN_LABELS[addr];
              const lbl  = kn ? `  [${kn.label}]` : "";
              if (h === 0) {
                lines.push(`${wPfx}  ${addr}${lbl}  ← ${wLabel}`);
              } else {
                lines.push(`${wPfx}  ↓  Hop ${h}`);
                lines.push(`${wPfx}  ${addr}${lbl}${h === path.length - 1 ? "  ← SHARED NODE" : ""}`);
                const segTx = bestTxForWallet(path[h - 1], path[h]);
                if (segTx) {
                  emitTxs([segTx], `${wPfx}  `);
                }
              }
            }
          } else {
            lines.push(`${wPfx}  (no path data)`);
          }
          lines.push("");
        });
      };

      // Helper: render private sub-section within a tier.
      const renderPrivExch = (
        priv: CommingleFinding[], exch: CommingleFinding[],
        maxShow: number
      ) => {
        if (priv.length > 0) {
          lines.push(`  ★ PRIVATE WALLET CONNECTIONS (${priv.length}) — INVESTIGATE FIRST`);
          lines.push("");
          priv.slice(0, maxShow).forEach((f, i) => {
            const fKn = f.knownInfo ?? KNOWN_LABELS[f.sharedAddress];
            const isDagTeamNode = fKn?.type === "dag-team";
            const dagTag = isDagTeamNode ? "  ◄ DAG OFFICIAL ENTITY" : "";
            lines.push(`  ${String(i + 1).padStart(2, "0")}. ${f.sharedAddress}${fKn ? `  [${fKn.label.toUpperCase()}]${dagTag}` : ""}`);
            lines.push(`       TX Count : ${f.txCountTarget}   |   Connected by: ${f.peerPaths.length} wallet(s)`);
            lines.push("");
            renderSharedNodeWallets(f);
            lines.push("");
          });
          if (priv.length > maxShow) lines.push(`  … and ${priv.length - maxShow} more private connections`);
          lines.push("");
        }
        if (priv.length === 0) {
          lines.push("  None found.");
          lines.push("");
        }
      };

      // ── Group Connectivity Summary ───────────────────────────────────────────
      lines.push(sep("GROUP CONNECTIVITY SUMMARY"));
      lines.push("");
      if (_clusters.length > 0) {
        _clusters.forEach((cluster) => {
          const allConnected = cluster.length === allInputWallets.length;
          const prefix = allConnected
            ? `All ${cluster.length} of ${allInputWallets.length} input wallets form one connected commingling cluster`
            : `Only ${cluster.length} of ${allInputWallets.length} input wallets are connected`;
          lines.push(`  ${prefix} through the following shared node(s):`);
          cluster.forEach(w => {
            const idx = allInputWallets.indexOf(w);
            lines.push(`    • Wallet ${idx + 1}: ${w}`);
          });
          lines.push("");
          const clusterSet   = new Set(cluster);
          const clusterNodes = privFindings.filter(f =>
            f.peerPaths.some(p => clusterSet.has(p.wallet))
          );
          lines.push(`  Shared private node${clusterNodes.length !== 1 ? "s" : ""} (${clusterNodes.length} total):`);
          clusterNodes.slice(0, 8).forEach(f => {
            const kn = KNOWN_LABELS[f.sharedAddress];
            lines.push(`    • ${f.sharedAddress}${kn ? `  [${kn.label}]` : ""}  (Tier ${f.tier})`);
          });
          if (clusterNodes.length > 8) lines.push(`    … and ${clusterNodes.length - 8} more shared nodes`);
          if (isolatedWallets.length > 0) {
            lines.push("");
            lines.push(`  The following wallet${isolatedWallets.length !== 1 ? "s were" : " was"} excluded — zero connection to any other input wallet:`);
            isolatedWallets.forEach(w => {
              const idx = allInputWallets.indexOf(w);
              lines.push(`    ✗ Wallet ${idx + 1}: ${w}`);
            });
          }
        });
      } else {
        lines.push(`  No private-wallet connections detected between any input wallets.`);
        lines.push(`  All ${allInputWallets.length} input wallets appear isolated from each other.`);
      }
      lines.push("");

      // ── Tier 1 ──────────────────────────────────────────────────────────────
      lines.push(sep("TIER 1 — DIRECT SHARED COUNTERPARTIES"));
      lines.push("");
      // T1: best IN+OUT to shared wallet; exchange TX detail in consolidated section
      renderPrivExch(t1priv, t1exch, 20);

      // ── Tier 2 ──────────────────────────────────────────────────────────────
      lines.push(sep("TIER 2 — SECOND-DEGREE SHARED NODES"));
      lines.push("");
      // T2: full trail trace + best IN+OUT to first hop; exchange TX detail in consolidated section
      renderPrivExch(t2priv, t2exch, 20);

      // ── Tier 3–6 ────────────────────────────────────────────────────────────
      const t3to6priv = [...t3priv.slice(0, 10), ...t4priv.slice(0, 10), ...t5priv.slice(0, 5), ...t6priv.slice(0, 5)];
      if (t3to6priv.length > 0) {
        lines.push(sep("TIER 3–6 — DEEP SHARED NODES"));
        lines.push("");
        if (t3to6priv.length > 0) {
          lines.push(`  ★ PRIVATE WALLET CONNECTIONS (${t3priv.length + t4priv.length + t5priv.length + t6priv.length}) — INVESTIGATE`);
          lines.push("");
          t3to6priv.forEach((f, i) => {
            const fKn = f.knownInfo ?? KNOWN_LABELS[f.sharedAddress];
            const isDagTeamNode = fKn?.type === "dag-team";
            const dagTag = isDagTeamNode ? "  ◄ DAG OFFICIAL ENTITY" : "";
            lines.push(`  ${String(i + 1).padStart(2, "0")}. ${f.sharedAddress}  (Tier ${f.tier})${fKn ? `  [${fKn.label.toUpperCase()}]${dagTag}` : ""}`);
            lines.push(`       TX Count : ${f.txCountTarget}   |   Connected by: ${f.peerPaths.length} wallet(s)`);
            lines.push("");
            renderSharedNodeWallets(f);
            lines.push("");
          });
          const deepTotal = t3priv.length + t4priv.length + t5priv.length + t6priv.length;
          if (deepTotal > 20) lines.push(`  … and ${deepTotal - 20} more`);
          lines.push("");
        }
      }

      lines.push(sep("NOTE — EXCHANGE / BRIDGE / OFFICIAL FLOWS"));
      lines.push("");
      lines.push("  Exchange, bridge, and official flows are excluded from this report.");
      lines.push("  Use the dedicated EXCHANGE FLOWS REPORT to view all transactions");
      lines.push("  touching known exchange, bridge, and official protocol addresses.");
      lines.push("");
    }

    lines.push(sep("ASSESSMENT"));
    lines.push("");
    if (findings.length === 0) {
      lines.push("  LOW RISK — No shared nodes found within 6 tiers of separation.");
      lines.push("  The wallets under analysis do not appear to share any common");
      lines.push("  counterparties, intermediaries, or endpoints.");
    } else if (t1priv.length > 0) {
      lines.push("  HIGH RISK — Direct private wallet connections detected (Tier 1).");
      lines.push("  The selected wallets transact with the same private addresses");
      lines.push("  directly. This is a strong commingling indicator.");
      if (t1exch.length > 0)
        lines.push(`  NOTE: ${t1exch.length} shared exchange(s) also present — normal on-ramp/off-ramp use.`);
    } else if (t1exch.length > 0 && privFindings.length === 0) {
      lines.push("  EXCHANGE EXPOSURE ONLY — No private wallet commingling detected.");
      lines.push("  Both wallets route funds through common exchange(s). This is");
      lines.push("  expected for exchange users and is not itself commingling evidence.");
      lines.push(`  Shared exchange(s): ${exchFindings.slice(0, 5).map((f) => f.knownInfo?.label ?? f.sharedAddress).join(", ")}`);
    } else if (t1exch.length > 0 && privFindings.length > 0) {
      lines.push("  MEDIUM RISK — Exchange flows at Tier 1, private connections at deeper tiers.");
      lines.push("  No direct private commingling. Shared exchange flows are normal.");
      lines.push("  Investigate the private connections found at deeper tiers.");
    } else if (t2priv.length > 0) {
      lines.push("  MEDIUM RISK — Shared private nodes at Tier 2 detected.");
      lines.push("  Wallets share common 2nd-degree private connections. May indicate");
      lines.push("  indirect fund commingling or use of shared intermediaries.");
    } else {
      lines.push("  LOW-MEDIUM RISK — Shared nodes at Tier 3–6 or exchange-only.");
      lines.push("  Connections are distal and may reflect shared service usage");
      lines.push("  rather than direct commingling.");
    }
    lines.push("");
    return auditAndSign(lines, {
      reportType: "Commingling Check Report",
      chain: chainUp,
      target: commingleResult.targetWallet,
      comparisons: commingleResult.comparisonWallets,
      depth: "6 tiers",
      minAmount: commingleMinAmount <= 0
        ? "None (all transactions included)"
        : `${commingleMinAmount} ${chainUp}`,
      nodesScanned: commingleResult.totalScanned,
      walletLabels: true,
    });
  })(commingleResultRef.current ?? commingleResult);
  }

  // ── Intersection / Funnel Analysis Report ─────────────────────────────────────
  function generateMultiReport(walletTxMap: Map<string, Tx[]>): string {
    return ((multiResult: MultiAnalysisResult | null): string => {
    if (!multiResult) return "";
    const now     = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = chain.toUpperCase();
    const sep = (label = "") => label
      ? `\n─── ${label} ${"─".repeat(Math.max(0, 60 - label.length - 5))}`
      : "─".repeat(64);
    const fmtDate  = (ts: string) => ts ? ts.replace("T", " ").slice(0, 16) + " UTC" : "—";
    const fmtAmt2  = (v: string, dir: "in" | "out") => {
      const n    = parseFloat(v);
      const sign = dir === "in" ? "+" : "−";
      if (!n || isNaN(n)) return `${sign}0.00`;
      const abs  = Math.abs(n);
      const dec  = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      return `${sign}${n.toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec })}`;
    };
    const lines: string[] = [];
    const MULTI_EXCL  = new Set([
      "DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz",
      "DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B",
    ]);
    const isExchType  = (addr: string) => ["exchange", "bridge", "hot", "custodial"].includes(KNOWN_LABELS[addr]?.type ?? "");

    // Render a single directional hop TX without spam-filter gating.
    // Used exclusively for hop-by-hop path rendering where any non-zero TX is evidence.
    const emitHopTx = (tx: Tx, pad: string) => {
      const dir   = tx.direction === "in" ? "IN " : "OUT";
      const amt   = fmtAmt2(tx.value, tx.direction as "in" | "out");
      const asset = tx.tokenSymbol || chainUp;
      const usd   = tx.valueUsd > 0
        ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]`
        : "";
      lines.push(`${pad}└─ [${dir}]  From: ${tx.from ?? "—"} → To: ${tx.to ?? "—"}`);
      lines.push(`${pad}   Amount: ${amt} ${asset}${usd}`);
      lines.push(`${pad}   TX    : ${tx.hash ?? "(none)"}`);
      lines.push(`${pad}   Date  : ${fmtDate(tx.timestamp ?? "")}`);
      if (tx.destinationTag != null) lines.push(`${pad}   ↳ Destination Tag : ${tx.destinationTag}`);
      if (tx.memo)                   lines.push(`${pad}   ↳ Memo            : ${tx.memo}`);
    };

    const emitTxBlock = (txs: Tx[], pad: string) => {
      // Apply global spam filter — drop dust, 0-value ops, and below-chain-minimum TXs.
      const clean = txs.filter(t => passesAnalysisFilter(t, chain));
      if (clean.length === 0) return;
      lines.push(`${pad}│`);
      clean.forEach((tx, ti) => {
        const isLast   = ti === clean.length - 1;
        const conn     = isLast ? "└─" : "├─";
        const childPfx = isLast ? "   " : "│  ";
        const dir      = tx.direction === "in" ? "IN " : "OUT";
        const amt      = fmtAmt2(tx.value, tx.direction as "in" | "out");
        const asset    = (tx as Tx & { tokenSymbol?: string }).tokenSymbol || chainUp;
        const usd      = tx.valueUsd > 0
          ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]`
          : "";
        lines.push(`${pad}${conn} [${dir}]  From: ${tx.from ?? "—"} → To: ${tx.to ?? "—"}`);
        lines.push(`${pad}${childPfx}  Amount: ${amt} ${asset}${usd}`);
        lines.push(`${pad}${childPfx}  TX    : ${tx.hash ?? "(none)"}`);
        lines.push(`${pad}${childPfx}  Date  : ${fmtDate(tx.timestamp ?? "")}`);
        if (tx.destinationTag != null) lines.push(`${pad}${childPfx}  ↳ Destination Tag : ${tx.destinationTag}`);
        if (tx.memo)                   lines.push(`${pad}${childPfx}  ↳ Memo            : ${tx.memo}`);
      });
    };

    const bestInOut2 = (addr: string): Tx[] => {
      const pool = allTxs.filter(t =>
        (t.direction === "in" ? t.from : t.to) === addr &&
        passesAnalysisFilter(t, chain)
      );
      const top  = (dir: "in" | "out") =>
        pool.filter(t => t.direction === dir).sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      return [top("in"), top("out")].filter(Boolean) as Tx[];
    };

    // Pair-specific hop TX lookup with two-stage fallback.
    // Searches the COMBINED TX history of ALL tracked wallets (walletTxMap) so that
    // hops involving W2/W3/… are found even when allTxs only has the focused wallet's records.
    // Stage 1 — normalized pair match (EVM checksummed vs lowercase, null to/from safe).
    // Stage 2 — direction-based counterparty fallback for chains with partial address fields.
    const findHopTx = (fa: string, ta: string): Tx | null => {
      const evm  = ["ethereum", "polygon", "bsc"].includes(chain);
      const norm = (a: string | null | undefined) => evm ? (a ?? "").toLowerCase() : (a ?? "");
      const faN  = norm(fa);
      const taN  = norm(ta);
      // Flatten all wallets' TX histories into one deduplicated pool
      const seen  = new Set<string>();
      const combined: Tx[] = [];
      for (const txs of walletTxMap.values()) {
        for (const t of txs) {
          if (!seen.has(t.hash)) { seen.add(t.hash); combined.push(t); }
        }
      }
      // Use value > 0 filter only — passesSpamFilter would silently discard valid hop TXs
      // whose amounts fall below the chain minimum.  The hop renderer handles display filtering.
      const clean = combined.filter(t => parseFloat(t.value || "0") > 0);
      // Stage 1: normalized pair match — most precise
      const pair = clean.filter(t =>
        (norm(t.from) === faN && norm(t.to) === taN) ||
        (norm(t.from) === taN && norm(t.to) === faN)
      );
      if (pair.length > 0)
        return pair.sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      // Stage 2: direction-based counterparty lookup for ta
      const cpty = clean.filter(t => norm(t.direction === "in" ? t.from : t.to) === taN);
      if (cpty.length > 0)
        return cpty.sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      return null;
    };

    // Deduplicated shared entries (sharedCounterparties + commonEndpoints)
    const seenM    = new Set<string>();
    const allUniq  = [...multiResult.sharedCounterparties, ...multiResult.commonEndpoints]
      .filter(s => { if (seenM.has(s.address)) return false; seenM.add(s.address); return !MULTI_EXCL.has(s.address); });
    const privPoints = allUniq.filter(s => !isExchType(s.address));
    const exchPoints = allUniq.filter(s => isExchType(s.address));

    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║  INTERSECTION / FUNNEL ANALYSIS — CryptoChainTrace          ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated    : ${now}`);
    lines.push(`Chain        : ${chainUp}`);
    multiResult.trackedWallets.forEach((w, i) => {
      const kn = KNOWN_LABELS[w];
      lines.push(`Wallet ${String(i + 1).padStart(2, " ")}    : ${w}${kn ? `  [${kn.label}]` : ""}`);
    });
    lines.push(`Total Wallets: ${multiResult.trackedWallets.length}`);
    lines.push(`Depth        : up to 6 hops from each wallet (connections graph)`);
    lines.push(sep());
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);

    // ── § 1 — Private Convergence Points ──────────────────────────────────────
    lines.push(sep("PRIVATE CONVERGENCE POINTS"));
    lines.push(`  Private addresses reached within 6 hops of 2+ tracked wallets.`);
    lines.push(`  These are the core investigative findings — potential funneling / mixing hubs.`);
    lines.push(`  Exchanges, bridges, and official nodes are EXCLUDED from this report.`);
    lines.push("");
    if (privPoints.length === 0) {
      lines.push("  No private convergence detected at depth 1–6.");
      lines.push("  Tracked wallets do not share private intermediaries within scanned depth.");
      lines.push("  Try loading more TX history and re-running for deeper coverage.");
      lines.push("");
    } else {
      // Sort descending: most wallets sharing the node first, then by total txCount
      const sortedPriv = [...privPoints].sort((a, b) =>
        b.appearances.length - a.appearances.length ||
        b.appearances.reduce((s, ap) => s + ap.txCount, 0) -
        a.appearances.reduce((s, ap) => s + ap.txCount, 0)
      );
      const criticalNodes = sortedPriv.slice(0, 10);
      const summaryNodes  = sortedPriv.slice(10, 30);

      // Returns the single highest-amount analysis-filtered TX from allTxs touching hopAddr.
      const bestSingle = (hopAddr: string): Tx | null => {
        const pool = allTxs.filter(t =>
          ((t.direction === "in" ? t.from : t.to) === hopAddr) &&
          passesAnalysisFilter(t, chain)
        );
        if (pool.length === 0) return null;
        return pool.sort((a, b) => parseFloat(b.value) - parseFloat(a.value))[0];
      };

      // ── Top 10 critical nodes — full hop-by-hop TX expansion ───────────────
      if (criticalNodes.length > 0) {
        lines.push(`  ★ TOP ${criticalNodes.length} CRITICAL SHARED NODES — FULL HOP TRAIL`);
        lines.push(`  Ranked by number of tracked wallets that converge on this address.`);
        lines.push("");
        criticalNodes.forEach((entry, i) => {
          const kn       = KNOWN_LABELS[entry.address];
          const label    = kn ? `  [${kn.label.toUpperCase()}]` : "";
          const teamNote = kn?.type === "dag-team" ? "  ◄ OFFICIAL DAG ENTITY — labeled, not anonymous" : "";
          lines.push(`  ${String(i + 1).padStart(2, "0")}. ${entry.address}${label}${teamNote}`);
          lines.push(`       Shared by : ${entry.appearances.length}/${multiResult.trackedWallets.length} tracked wallets  ◄ CRITICAL NODE`);
          lines.push("");
          entry.appearances.forEach((app, appIdx) => {
            const idx      = multiResult.trackedWallets.indexOf(app.wallet);
            const wLabel   = idx === 0 ? "PRIMARY" : `WALLET ${idx + 1}`;
            const isLast   = appIdx === entry.appearances.length - 1;
            const conn     = isLast ? "└──" : "├──";
            const childPfx = isLast ? "    " : "│   ";
            lines.push(`       ${conn} ${wLabel}  |  ${app.txCount} tx${app.txCount !== 1 ? "s" : ""}  |  depth-${app.depth}${app.totalValueUsd > 0 ? `  |  $${app.totalValueUsd.toFixed(2)} USD` : ""}`);
            lines.push(`       ${childPfx}  Trail & Transactions:`);
            const hops = app.pathChain.length > 1 ? app.pathChain : [app.wallet, entry.address];
            const rootKn = KNOWN_LABELS[hops[0]];
            lines.push(`       ${childPfx}    ${hops[0]}${rootKn ? `  [${rootKn.label}]` : ""}  ← ${wLabel}`);
            for (let h = 1; h < hops.length; h++) {
              const fa     = hops[h - 1];
              const ta     = hops[h];
              const taKn   = KNOWN_LABELS[ta];
              const taLbl  = taKn ? `  [${taKn.label}]` : "";
              const isLast = h === hops.length - 1;
              lines.push(`       ${childPfx}    ↓  Hop ${h}`);
              lines.push(`       ${childPfx}    ${ta}${taLbl}${isLast ? "  ← SHARED NODE" : ""}`);
              lines.push(`       ${childPfx}    Transactions — Hop ${h}:`);
              const hopTx = findHopTx(fa, ta);
              if (hopTx) {
                emitHopTx(hopTx, `       ${childPfx}    `);
              } else {
                lines.push(`       ${childPfx}    (TX not in loaded history — path may be indirect or cross-wallet)`);
              }
              lines.push("");
            }
            lines.push("");
          });
          lines.push("");
        });
      }

      // ── Remaining nodes 11-30 — summarized (existing format, no TX detail) ──
      if (summaryNodes.length > 0) {
        lines.push(`  ADDITIONAL SHARED NODES — SUMMARY`);
        lines.push("");
        summaryNodes.forEach((entry, i) => {
          const kn       = KNOWN_LABELS[entry.address];
          const label    = kn ? `  [${kn.label.toUpperCase()}]` : "";
          const teamNote = kn?.type === "dag-team" ? "  ◄ OFFICIAL DAG ENTITY — labeled, not anonymous" : "";
          lines.push(`  ${String(i + 11).padStart(2, "0")}. ${entry.address}${label}${teamNote}`);
          lines.push(`       Shared by : ${entry.appearances.length}/${multiResult.trackedWallets.length} tracked wallets`);
          lines.push("");
          entry.appearances.forEach((app, appIdx) => {
            const idx      = multiResult.trackedWallets.indexOf(app.wallet);
            const wLabel   = idx === 0 ? "PRIMARY" : `WALLET ${idx + 1}`;
            const isLast   = appIdx === entry.appearances.length - 1;
            const conn     = isLast ? "└──" : "├──";
            const childPfx = isLast ? "    " : "│   ";
            const trail: string[] = app.pathChain.length > 1
              ? app.pathChain.map((a, si) => {
                  const kl  = KNOWN_LABELS[a];
                  const lbl = kl ? `  [${kl.label}]` : "";
                  if (si === 0) return `${a}${lbl}  ← ${wLabel}`;
                  if (si === app.pathChain.length - 1) return `${a}${lbl}  ← SHARED NODE`;
                  return `${a}${lbl}`;
                })
              : [`${app.wallet}  ← ${wLabel}`, `${entry.address}  ← SHARED NODE`];
            lines.push(`       ${conn} ${wLabel}  |  ${app.txCount} tx${app.txCount !== 1 ? "s" : ""}  |  depth-${app.depth}${app.totalValueUsd > 0 ? `  |  $${app.totalValueUsd.toFixed(2)} USD` : ""}`);
            lines.push(`       ${childPfx}  Trail:`);
            trail.forEach((step, si) => {
              if (si === 0) {
                lines.push(`       ${childPfx}    ${step}`);
              } else {
                lines.push(`       ${childPfx}    ↓  Hop ${si}`);
                lines.push(`       ${childPfx}    ${step}`);
              }
            });
            const hopAddr  = app.pathChain.length > 1 ? app.pathChain[1] : entry.address;
            const hopShort = hopAddr.length > 16 ? `${hopAddr.slice(0, 8)}…${hopAddr.slice(-4)}` : hopAddr;
            const bestTxs  = bestInOut2(hopAddr);
            if (bestTxs.length > 0) {
              lines.push(`       ${childPfx}  Best TX  (${wLabel} ↔ ${hopShort}):`);
              emitTxBlock(bestTxs, `       ${childPfx}  `);
            } else {
              lines.push(`       ${childPfx}  Best TX  : no loaded history for this hop`);
            }
            lines.push("");
          });
          lines.push("");
        });
      }

      if (privPoints.length > 30) lines.push(`  … and ${privPoints.length - 30} more private convergence points`);
      lines.push("");
    }

    // ── Investigative Summary ──────────────────────────────────────────────────
    lines.push(sep("INVESTIGATIVE SUMMARY"));
    lines.push(`  Tracked Wallets    : ${multiResult.trackedWallets.length}`);
    lines.push(`  Private Convergence: ${privPoints.length} node${privPoints.length !== 1 ? "s" : ""}`);
    lines.push(`  Exchange Nodes     : ${exchPoints.length} node${exchPoints.length !== 1 ? "s" : ""}`);
    lines.push(`  Total Shared       : ${allUniq.length}`);
    lines.push("");
    if (privPoints.length > 0) {
      lines.push(`  ⚠  CONVERGENCE DETECTED — ${privPoints.length} private address${privPoints.length !== 1 ? "es" : ""} appear`);
      lines.push(`     in the transaction graph of 2+ tracked wallets.`);
      lines.push(`     These represent potential money-funneling / commingling hubs.`);
      lines.push(`     Investigative action: subpoena / KYC for each convergence address listed above.`);
    } else {
      lines.push(`  No private convergence detected within depth-6.`);
      lines.push(`  Load more TX history and re-run for broader coverage.`);
    }
    if (exchPoints.length > 0) {
      lines.push("");
      lines.push(`  EXCHANGE EXPOSURE — ${exchPoints.length} shared exchange/custodian node${exchPoints.length !== 1 ? "s" : ""} detected.`);
      lines.push(`  File subpoena / KYC requests with listed exchanges for account-holder records.`);
    }
    lines.push("");
    return auditAndSign(lines, {
      reportType: "Intersection / Funnel Analysis",
      chain: chainUp,
      target: multiResult.trackedWallets[0] ?? address,
      comparisons: multiResult.trackedWallets.slice(1),
      depth: "6",
      nodesScanned: multiResult.sharedCounterparties.length + multiResult.commonEndpoints.length,
    });
  })(multiResultRef.current ?? multiResult);
  }

  // ── EXCHANGE FLOWS REPORT — all IN/OUT TXs touching known exchanges/bridges ──
  function generateExchangeFlowsReport(): string {
    const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = chain.toUpperCase();
    const rule = "─".repeat(64);
    const dbl  = "═".repeat(64);
    const sep  = (label = "") => label
      ? `\n─── ${label} ${"─".repeat(Math.max(0, 58 - label.length))}`
      : rule;
    const fmtDate = (ts: string) =>
      ts ? ts.replace("T", " ").slice(0, 16) + " UTC" : "—";
    const fmtAmt = (v: string | number, dir: string) => {
      const n = typeof v === "number" ? v : parseFloat(v as string);
      if (!isFinite(n)) return (dir === "in" ? "+" : "−") + "0.0000";
      const abs = Math.abs(n);
      const dec = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      return (dir === "in" ? "+" : "−") + abs.toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec });
    };

    const lines: string[] = [];
    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║      EXCHANGE FLOWS REPORT — CryptoChainTrace               ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated    : ${now}`);
    lines.push(`Chain        : ${chainUp}`);
    lines.push(`Target       : ${address}`);
    lines.push(`Loaded TXs   : ${allTxs.length.toLocaleString()}`);
    lines.push(rule);
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);
    lines.push("");

    // Determine if an address is an exchange/bridge/genesis that should appear in this report
    const isExchType = (t?: string) =>
      t === "exchange" || t === "bridge" || t === "genesis";

    // Clean display-name map — root exchange name → bracket label.
    // Mirrors the same map in generateCommingleReport / toBracketLabel.
    // Add new entries here as additional exchange addresses are added to KNOWN_LABELS.
    const EXCH_DISPLAY: Record<string, string> = {
      Coinbase:     "Coinbase Deposits",
      Kraken:       "Kraken",
      Binance:      "Binance",
      "Binance.US": "Binance.US",
      MEXC:         "MEXC",
      Bybit:        "Bybit",
      Bitfinex:     "Bitfinex",
      Bitstamp:     "Bitstamp",
      OKX:          "OKX",
      Huobi:        "Huobi",
      Uphold:       "Uphold",
      ChangeNOW:    "ChangeNOW",
      // Bridge / infrastructure
      Stellar:      "Stellar Foundation",
      // Additional exchanges — extend this list as needed
    };
    const toDisplayLabel = (lbl: string): string => {
      const firstWord = lbl.split(/\s+/)[0];
      return EXCH_DISPLAY[firstWord] ?? firstWord;
    };

    // Group TXs by exchange counterparty — primary source: target wallet's loaded history
    const exchTxMap = new Map<string, typeof allTxs>();
    for (const tx of allTxs) {
      const counterparty = tx.direction === "in" ? tx.from : tx.to;
      if (!counterparty) continue;
      const kn = KNOWN_LABELS[counterparty];
      if (!kn || !isExchType(kn.type)) continue;
      if (!exchTxMap.has(counterparty)) exchTxMap.set(counterparty, []);
      exchTxMap.get(counterparty)!.push(tx);
    }

    // Supplement from segmentTxs — hop wallet transactions captured during the Commingle
    // Check scan (fetchHopPages). If a Commingle Check was run before this report, its
    // segmentTxs holds hop→exchange TXs (e.g. GAZSPN→Kraken, GD6OZZ→Coinbase) that are
    // not visible in allTxs (which reflects only the target wallet's own history).
    // segmentTxs keys are "walletA::walletB" with both directions stored as the same TX.
    const segData = (commingleResultRef.current ?? commingleResult)?.segmentTxs ?? {};
    for (const segKey of Object.keys(segData)) {
      const cut = segKey.indexOf("::");
      if (cut < 0) continue;
      const fa = segKey.slice(0, cut);
      const ta = segKey.slice(cut + 2);
      // Check both sides — either address could be the known exchange
      for (const [exchAddr] of [[fa, ta], [ta, fa]] as [string, string][]) {
        const kn = KNOWN_LABELS[exchAddr];
        if (!kn || !isExchType(kn.type)) continue;
        const tx = segData[segKey];
        if (!tx) continue;
        // Dedup by hash before inserting
        const existing = exchTxMap.get(exchAddr);
        if (existing) {
          if (!existing.find(t => t.hash === tx.hash)) existing.push(tx);
        } else {
          exchTxMap.set(exchAddr, [tx]);
        }
      }
    }

    if (exchTxMap.size === 0) {
      lines.push(`  No exchange, bridge, or protocol transactions found in the`);
      lines.push(`  ${allTxs.length.toLocaleString()} loaded transactions.`);
      lines.push(`  Load full transaction history and re-run for complete coverage.`);
    } else {
      // Uphold DAG always first; then sort by label
      const UPHOLD_DAG = "DAG1pLpkyX7aTtFZtbF98kgA9QTZRzrsGaFmf4BT";
      const entries = Array.from(exchTxMap.entries()).sort(([a], [b]) => {
        if (a === UPHOLD_DAG) return -1;
        if (b === UPHOLD_DAG) return 1;
        return (KNOWN_LABELS[a]?.label ?? a).localeCompare(KNOWN_LABELS[b]?.label ?? b);
      });

      const totalTxs = entries.reduce((s, [, v]) => s + v.length, 0);
      lines.push(`  Found: ${entries.length} exchange/protocol address${entries.length !== 1 ? "es" : ""} with activity`);
      lines.push(`  Total exchange TXs: ${totalTxs.toLocaleString()}`);

      for (const [addr, txs] of entries) {
        const kn = KNOWN_LABELS[addr];
        const typeTag = kn?.type === "bridge" ? "BRIDGE" : kn?.type === "genesis" ? "PROTOCOL" : kn?.type === "founder" ? "FOUNDER" : kn?.type === "mixer" ? "MIXER" : "EXCHANGE";
        const displayLbl = toDisplayLabel(kn?.label ?? addr);
        const headerLabel = `[${displayLbl}]  ◄ ${typeTag} FLOW`;
        lines.push(sep(headerLabel));
        lines.push(`  Address : ${addr}`);
        lines.push(`  Type    : ${typeTag} · ${displayLbl}`);

        const inTxs  = txs.filter(t => t.direction === "in");
        const outTxs = txs.filter(t => t.direction === "out");
        const totalIn  = inTxs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        const totalOut = outTxs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        lines.push(`  IN  TXs : ${inTxs.length}   Total Received : +${totalIn.toFixed(4)} ${chainUp}`);
        lines.push(`  OUT TXs : ${outTxs.length}   Total Sent     : −${totalOut.toFixed(4)} ${chainUp}`);
        lines.push("");

        const sortByDate = (a: Tx, b: Tx) =>
          new Date(b.timestamp ?? 0).getTime() - new Date(a.timestamp ?? 0).getTime();
        // Apply global spam filter — only real-value txs in reports
        const cleanTxs = txs.filter(t => passesAnalysisFilter(t, chain)).sort(sortByDate);
        const renderExchBranch = (block: (typeof txs), addTrailingBlank: boolean) => {
          block.forEach((tx, i) => {
            const isLast = i === block.length - 1;
            const conn    = isLast ? "└─" : "├─";
            const childPx = isLast ? "   " : "│  ";
            const dir = tx.direction === "in" ? "IN " : "OUT";
            const asset = (tx as typeof tx & { tokenSymbol?: string }).tokenSymbol ?? chainUp;
            const usd = tx.valueUsd && tx.valueUsd > 0
              ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]`
              : "";
            lines.push(`${conn} [${dir}]  From: ${tx.from ?? "—"}`);
            lines.push(`${childPx}         To  : ${tx.to   ?? "—"}`);
            lines.push(`${childPx}  Amount : ${fmtAmt(tx.value, tx.direction)} ${asset}${usd}`);
            lines.push(`${childPx}  TX     : ${tx.hash ?? "(no hash)"}`);
            lines.push(`${childPx}  Date   : ${fmtDate(tx.timestamp ?? "")}`);
            if ((tx as typeof tx & { destinationTag?: number | null }).destinationTag != null)
              lines.push(`${childPx}  ↳ Destination Tag : ${(tx as typeof tx & { destinationTag?: number | null }).destinationTag}`);
            if (tx.memo) lines.push(`${childPx}  ↳ Memo : ${tx.memo}`);
            if (!isLast) lines.push(childPx);
          });
          if (addTrailingBlank) lines.push("");
        };
        if (cleanTxs.length > 0) renderExchBranch(cleanTxs, true);
        lines.push("");
      }
    }

    lines.push(sep("INVESTIGATIVE SUMMARY"));
    if (exchTxMap.size > 0) {
      lines.push(`  Exchange activity detected on this wallet.`);
      lines.push(`  File subpoena / KYC requests with each listed exchange to obtain`);
      lines.push(`  account-holder identity, IP logs, and transaction records.`);
      lines.push(`  Exchange addresses, TX hashes, and dates are documented above.`);
    } else {
      lines.push(`  No exchange transactions found in ${allTxs.length.toLocaleString()} loaded TXs.`);
      lines.push(`  Load full transaction history for complete coverage.`);
    }
    lines.push("");
    return auditAndSign(lines, {
      reportType: "Exchange Flows Report",
      chain: chainUp,
      target: address,
    });
  }

  // ── MULTI-WALLET EXCHANGE FLOWS REPORT ────────────────────────────────────
  // Combined exchange/bridge flows across 2+ wallets. walletTxMap: wallet → its TXs.
  function generateMultiExchangeFlowsReport(walletTxMap: Map<string, Tx[]>): string {
    const now     = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = chain.toUpperCase();
    const rule    = "─".repeat(64);
    const sep     = (label = "") => label
      ? `\n─── ${label} ${"─".repeat(Math.max(0, 58 - label.length))}`
      : rule;
    const fmtDate = (ts: string) => ts ? ts.replace("T", " ").slice(0, 16) + " UTC" : "—";
    const fmtAmt  = (v: string | number, dir: string) => {
      const n   = typeof v === "number" ? v : parseFloat(v as string);
      if (!isFinite(n)) return (dir === "in" ? "+" : "−") + "0.0000";
      const abs = Math.abs(n);
      const dec = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      return (dir === "in" ? "+" : "−") + abs.toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec });
    };

    const isExchType = (t?: string) =>
      t === "exchange" || t === "bridge" || t === "genesis";
    const EXCH_DISPLAY: Record<string, string> = {
      Coinbase: "Coinbase Deposits", Kraken: "Kraken", Binance: "Binance",
      "Binance.US": "Binance.US", MEXC: "MEXC", Bybit: "Bybit", Bitfinex: "Bitfinex",
      Bitstamp: "Bitstamp", OKX: "OKX", Huobi: "Huobi", Uphold: "Uphold",
      ChangeNOW: "ChangeNOW", Stellar: "Stellar Foundation",
    };
    const toDisplayLabel = (lbl: string) => EXCH_DISPLAY[lbl.split(/\s+/)[0]] ?? lbl.split(/\s+/)[0];

    const walletList = Array.from(walletTxMap.keys());

    const lines: string[] = [];
    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║  MULTI-WALLET EXCHANGE FLOWS — CryptoChainTrace             ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated    : ${now}`);
    lines.push(`Chain        : ${chainUp}`);
    lines.push(`Wallets      : ${walletList.length}`);
    walletList.forEach((w, i) => {
      const kn = KNOWN_LABELS[w];
      lines.push(`  W${i + 1} : ${w}${kn ? `  [${kn.label}]` : ""}`);
    });
    lines.push(rule);
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);
    lines.push(``);

    // Build exchAddr → { wallet → Tx[] } map
    type WalletTxs = Map<string, Tx[]>;
    const exchMap = new Map<string, WalletTxs>();
    for (const [wallet, txs] of walletTxMap) {
      for (const tx of txs) {
        if (!passesAnalysisFilter(tx, chain)) continue;
        const cp = tx.direction === "in" ? tx.from : tx.to;
        if (!cp) continue;
        const kn = KNOWN_LABELS[cp];
        if (!kn || !isExchType(kn.type)) continue;
        if (!exchMap.has(cp)) exchMap.set(cp, new Map());
        const wMap = exchMap.get(cp)!;
        if (!wMap.has(wallet)) wMap.set(wallet, []);
        wMap.get(wallet)!.push(tx);
      }
    }

    if (exchMap.size === 0) {
      lines.push(`  No exchange, bridge, or protocol transactions found across all wallets.`);
      lines.push(`  Load full transaction history on each wallet and re-run.`);
    } else {
      const UPHOLD_DAG = "DAG1pLpkyX7aTtFZtbF98kgA9QTZRzrsGaFmf4BT";
      const entries = Array.from(exchMap.entries()).sort(([a], [b]) => {
        if (a === UPHOLD_DAG) return -1;
        if (b === UPHOLD_DAG) return 1;
        return (KNOWN_LABELS[a]?.label ?? a).localeCompare(KNOWN_LABELS[b]?.label ?? b);
      });

      const totalTxs = entries.reduce((s, [, wm]) =>
        s + Array.from(wm.values()).reduce((ss, txs) => ss + txs.length, 0), 0);
      lines.push(`  Found: ${entries.length} exchange/protocol address${entries.length !== 1 ? "es" : ""} across ${walletList.length} wallets`);
      lines.push(`  Total exchange TXs: ${totalTxs.toLocaleString()}`);

      for (const [addr, wMap] of entries) {
        const kn = KNOWN_LABELS[addr];
        const typeTag    = kn?.type === "bridge" ? "BRIDGE" : kn?.type === "genesis" ? "PROTOCOL" : kn?.type === "founder" ? "FOUNDER" : kn?.type === "mixer" ? "MIXER" : "EXCHANGE";
        const displayLbl = toDisplayLabel(kn?.label ?? addr);
        lines.push(sep(`[${displayLbl}]  ◄ ${typeTag} FLOW`));
        lines.push(`  Address  : ${addr}`);
        lines.push(`  Type     : ${typeTag} · ${displayLbl}`);

        const allTxsForExch = Array.from(wMap.values()).flat();
        const inTxsAll  = allTxsForExch.filter(t => t.direction === "in");
        const outTxsAll = allTxsForExch.filter(t => t.direction === "out");
        const totalIn   = inTxsAll.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        const totalOut  = outTxsAll.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        const totalInUsd  = inTxsAll.reduce((s, t) => s + (t.valueUsd > 0 ? t.valueUsd : 0), 0);
        const totalOutUsd = outTxsAll.reduce((s, t) => s + (t.valueUsd > 0 ? t.valueUsd : 0), 0);
        const usdInStr  = totalInUsd  > 0 ? `  [$${totalInUsd.toLocaleString("en-US",  { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]` : "";
        const usdOutStr = totalOutUsd > 0 ? `  [$${totalOutUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]` : "";
        lines.push(`  Combined : ${allTxsForExch.length} tx${allTxsForExch.length !== 1 ? "s" : ""} across ${wMap.size} wallet${wMap.size !== 1 ? "s" : ""}`);
        lines.push(`  IN  TXs  : ${inTxsAll.length}   Total Received : +${totalIn.toFixed(4)} ${chainUp}${usdInStr}`);
        lines.push(`  OUT TXs  : ${outTxsAll.length}   Total Sent     : −${totalOut.toFixed(4)} ${chainUp}${usdOutStr}`);

        // Per-wallet stats line
        walletList.forEach((w, wi) => {
          const wtxs = wMap.get(w);
          if (!wtxs || wtxs.length === 0) return;
          const wInT  = wtxs.filter(t => t.direction === "in");
          const wOutT = wtxs.filter(t => t.direction === "out");
          const wIn   = wInT.reduce((s, t)  => s + (parseFloat(t.value) || 0), 0);
          const wOut  = wOutT.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
          const wInUsd  = wInT.reduce((s, t)  => s + (t.valueUsd > 0 ? t.valueUsd : 0), 0);
          const wOutUsd = wOutT.reduce((s, t) => s + (t.valueUsd > 0 ? t.valueUsd : 0), 0);
          const wUsdStr = (wInUsd > 0 || wOutUsd > 0)
            ? `   USD: IN $${wInUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / OUT $${wOutUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
            : "";
          const wLabel = wi === 0 ? "PRIMARY" : `W${wi + 1}`;
          lines.push(`  ${wLabel.padEnd(7)}: IN ${wInT.length} tx (+${wIn.toFixed(4)})   OUT ${wOutT.length} tx (−${wOut.toFixed(4)}) ${chainUp}${wUsdStr}`);
        });
        lines.push(``);

        // Per-wallet TX detail blocks
        const sortByDate = (a: Tx, b: Tx) =>
          new Date(b.timestamp ?? 0).getTime() - new Date(a.timestamp ?? 0).getTime();

        walletList.forEach((w, wi) => {
          const wtxs = wMap.get(w);
          if (!wtxs || wtxs.length === 0) return;
          const wLabel  = wi === 0 ? "PRIMARY" : `W${wi + 1}`;
          const wShort  = w.length > 20 ? `${w.slice(0, 10)}…${w.slice(-6)}` : w;
          lines.push(`  ── ${wLabel} (${wShort}) ──`);
          const clean = wtxs.filter(t => passesAnalysisFilter(t, chain)).sort(sortByDate);
          clean.forEach((tx, i) => {
            const isLast  = i === clean.length - 1;
            const conn    = isLast ? "└─" : "├─";
            const childPx = isLast ? "   " : "│  ";
            const dir     = tx.direction === "in" ? "IN " : "OUT";
            const asset   = (tx as Tx & { tokenSymbol?: string }).tokenSymbol ?? chainUp;
            const usd     = tx.valueUsd > 0
              ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]`
              : "";
            lines.push(`${conn} [${dir}]  From: ${tx.from ?? "—"}`);
            lines.push(`${childPx}         To  : ${tx.to   ?? "—"}`);
            lines.push(`${childPx}  Amount : ${fmtAmt(tx.value, tx.direction)} ${asset}${usd}`);
            lines.push(`${childPx}  TX     : ${tx.hash ?? "(no hash)"}`);
            lines.push(`${childPx}  Date   : ${fmtDate(tx.timestamp ?? "")}`);
            if ((tx as Tx & { destinationTag?: number | null }).destinationTag != null)
              lines.push(`${childPx}  ↳ Destination Tag : ${(tx as Tx & { destinationTag?: number | null }).destinationTag}`);
            if (tx.memo) lines.push(`${childPx}  ↳ Memo : ${tx.memo}`);
            if (!isLast) lines.push(childPx);
          });
          lines.push(``);
        });
      }
    }

    lines.push(sep("INVESTIGATIVE SUMMARY"));
    lines.push(`  Tracked Wallets : ${walletList.length}`);
    lines.push(`  Exchange Nodes  : ${exchMap.size}`);
    if (exchMap.size > 0) {
      lines.push(`  Exchange activity detected across tracked wallets.`);
      lines.push(`  File subpoena / KYC requests with each listed exchange to obtain`);
      lines.push(`  account-holder identity, IP logs, and transaction records.`);
    } else {
      lines.push(`  No exchange transactions found. Load full TX history and re-run.`);
    }
    lines.push(``);
    return auditAndSign(lines, {
      reportType: "Multi-Wallet Exchange Flows Report",
      chain: chainUp,
      target: walletList[0] ?? address,
      comparisons: walletList.slice(1),
    });
  }

  // ── SUBPOENA TARGETS — aggregates exchange hits for law enforcement use ──────
  function generateSubpoenaTargets(
    commingleResult: CommingleCheckResult | null,
    _multiResult: MultiAnalysisResult | null,
    exchWalletTxMap: Map<string, Tx[]>,
  ): string {
    const chainUp = chain.toUpperCase();
    const rule    = "─".repeat(64);
    const US_REGULATED = new Set([
      "Coinbase", "COINBASE", "Kraken", "KRAKEN", "Gemini", "GEMINI",
      "Bitstamp", "BITSTAMP", "Uphold", "UPHOLD", "Robinhood", "ROBINHOOD",
      "Binance.US", "BINANCE.US", "Bittrex", "BITTREX", "eToro", "ETORO",
      "ETORO", "eETORO",
    ]);

    type ExchEntry = { exchAddr: string; exchLabel: string; exchType: string; txs: Tx[]; sourceWallets: Set<string> };
    const exchMap = new Map<string, ExchEntry>();

    const addTx = (exchAddr: string, exchLabel: string, exchType: string, tx: Tx, wallet: string) => {
      if (!exchMap.has(exchAddr)) exchMap.set(exchAddr, { exchAddr, exchLabel, exchType, txs: [], sourceWallets: new Set() });
      const e = exchMap.get(exchAddr)!;
      if (!e.txs.find(t => t.hash === tx.hash)) e.txs.push(tx);
      e.sourceWallets.add(wallet);
    };

    for (const flow of (commingleResult?.exchFlows ?? [])) {
      for (const tx of flow.txs) addTx(flow.exchAddr, flow.exchLabel, flow.exchType, tx, flow.sourceWallet);
    }
    for (const [wallet, txs] of exchWalletTxMap) {
      for (const tx of txs) {
        const cp = tx.direction === "in" ? tx.from : tx.to;
        if (!cp) continue;
        const kn = getKnownInfo(cp, chain);
        if (!kn || !["exchange", "bridge", "genesis"].includes(kn.type)) continue;
        addTx(cp, kn.label, kn.type, tx, wallet);
      }
    }

    if (exchMap.size === 0) return "  No exchange targets identified. Load full TX history and re-run.";

    // Stable: US-regulated first → tx count → address tie-breaker
    const sorted = Array.from(exchMap.values()).sort((a, b) => {
      const aUS = US_REGULATED.has(a.exchLabel.split(/\s+/)[0]) ? 0 : 1;
      const bUS = US_REGULATED.has(b.exchLabel.split(/\s+/)[0]) ? 0 : 1;
      if (aUS !== bUS) return aUS - bUS;
      if (b.txs.length !== a.txs.length) return b.txs.length - a.txs.length;
      return a.exchAddr.localeCompare(b.exchAddr);
    });

    const out: string[] = [];
    out.push(`  ${sorted.length} subpoena target${sorted.length !== 1 ? "s" : ""} across ${exchMap.size} exchange address${exchMap.size !== 1 ? "es" : ""}.`);
    out.push(``);

    const FULL_DETAIL_LIMIT = 15;
    sorted.forEach((entry, idx) => {
      const isUS = US_REGULATED.has(entry.exchLabel.split(/\s+/)[0]);
      const vol  = entry.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
      const usd  = entry.txs.reduce((s, t) => s + (t.valueUsd > 0 ? t.valueUsd : 0), 0);
      const usdStr = usd > 0
        ? `  [$${usd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}]`
        : "";

      if (idx === FULL_DETAIL_LIMIT) {
        out.push(``);
        out.push(`  ${"─".repeat(74)}`);
        out.push(`  LOWER-PRIORITY TARGETS — ${sorted.length - FULL_DETAIL_LIMIT} remaining (condensed)`);
        out.push(`  ${"─".repeat(74)}`);
        out.push(`  #    Exchange                 Address                  Txs    Volume`);
        out.push(`  ${"─".repeat(74)}`);
      }

      if (idx >= FULL_DETAIL_LIMIT) {
        const rank   = `#${idx + 1}`.padEnd(4);
        const name   = (entry.exchLabel + (isUS ? " ★" : "")).slice(0, 24).padEnd(24);
        const addr   = `${entry.exchAddr.slice(0, 10)}…${entry.exchAddr.slice(-5)}`.padEnd(18);
        const txC    = String(entry.txs.length).padStart(4);
        const volFmt = `${vol.toFixed(0)} ${chainUp}`;
        out.push(`  ${rank} ${name} ${addr} ${txC}  ${volFmt}`);
        if (idx === sorted.length - 1) out.push(`  ${"─".repeat(74)}`);
        return;
      }

      // Full detail for top FULL_DETAIL_LIMIT entries
      const flagUS = isUS ? "  ★ US-REGULATED — HIGH PRIORITY" : "";
      const inTxs  = entry.txs.filter(t => t.direction === "in");
      const outTxs = entry.txs.filter(t => t.direction === "out");
      const peel   = detectPeelChainPatterns(entry.txs, chain);

      const reasons: string[] = [];
      if (isUS)                         reasons.push("US-regulated — KYC/AML records legally accessible via 18 U.S.C. § 2703");
      if (entry.sourceWallets.size > 1) reasons.push(`Shared by ${entry.sourceWallets.size} tracked wallets — direct commingling evidence`);
      if (peel.peelChainScore >= 30)    reasons.push(`Peel-chain score ${peel.peelChainScore}/100 — layering pattern detected`);
      if (inTxs.length > 0 && outTxs.length > 0) reasons.push("Bidirectional flows — possible custodial account with balance");
      if (reasons.length === 0)         reasons.push("Exchange deposit — holder identity obtainable via KYC subpoena");

      out.push(`  TARGET ${idx + 1}/${sorted.length}${flagUS}`);
      out.push(`  Exchange  : ${entry.exchLabel}  [${entry.exchType.toUpperCase()}]`);
      out.push(`  Address   : ${entry.exchAddr}`);
      out.push(`  Txs       : ${entry.txs.length}  (IN: ${inTxs.length}  OUT: ${outTxs.length})`);
      out.push(`  Volume    : ${vol.toFixed(4)} ${chainUp}${usdStr}`);
      out.push(`  Wallets sending to this address (${entry.sourceWallets.size}):`);
      Array.from(entry.sourceWallets).forEach(w => {
        const knW = getKnownInfo(w, chain);
        out.push(`    · ${w}${knW ? `  [${knW.label}]` : ""}`);
      });
      reasons.forEach(r => out.push(`  ✓ ${r}`));
      out.push(`  SCOPE: Account holder identity, registration IP, linked bank/payment accounts,`);
      out.push(`         complete TX history, withdrawal destinations, KYC/AML documentation.`);
      if (peel.patternsDetected.length > 0) {
        out.push(`  PEEL SIGNALS: ${peel.patternsDetected.join(" · ")}`);
      }
      out.push(`  ${rule}`);
    });

    return out.join("\n");
  }

  // ── EXECUTIVE SUMMARY — combines Commingle + Funnel + Exchange reports ───────
  function generateExecutiveSummary(
    _commingleText: string,
    _funnelText: string,
    _exchangeText: string,
    victimWalletAddr: string,
    victimPersonName: string,
    exchWalletTxMap?: Map<string, Tx[]>,
  ): string {
    const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = chain.toUpperCase();
    const lines: string[] = [];

    const cr = commingleResultRef.current;
    const mr = multiResultRef.current;

    const tier1Count    = cr?.tieredCounts[0] ?? 0;
    const totalFindings = cr?.findings.length ?? 0;
    const privFindings  = cr?.findings.filter(f => f.knownInfo?.type !== "exchange").length ?? 0;
    const exchFindings  = cr?.findings.filter(f => f.knownInfo?.type === "exchange").length ?? 0;
    const exchFlows     = cr?.exchFlows ?? [];
    const uniqueExchanges = [...new Set(exchFlows.map(f => f.exchLabel))];
    const riskStr = tier1Count > 0 ? "⚠  HIGH RISK — Direct commingling detected"
                  : totalFindings > 0 ? "△  MEDIUM RISK — Indirect commingling detected"
                  : "✓  LOW RISK — No commingling detected within scanned depth";

    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║   EXECUTIVE SUMMARY — FULL PACKAGE REPORT                   ║`);
    lines.push(`║   CryptoChainTrace — Blockchain Intelligence                ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated     : ${now}`);
    lines.push(`Chain         : ${chainUp}`);
    lines.push(`Primary Wallet: ${address}`);
    if (cr) {
      // Show only known/labeled wallets in the header — omit unlabeled to keep it concise
      const allHeaderW = [address, ...cr.comparisonWallets];
      const labeledHeaderW = allHeaderW.filter(w => !!KNOWN_LABELS[w]);
      const unlabeledHeaderCount = allHeaderW.length - labeledHeaderW.length;
      labeledHeaderW.forEach(w => {
        lines.push(`Notable Wallet: ${w}  [${KNOWN_LABELS[w]!.label}]`);
      });
      if (unlabeledHeaderCount > 0) {
        lines.push(`Other Wallets : ${unlabeledHeaderCount} unlabeled (full list in Commingle Check Report)`);
      }
      lines.push(`Total Wallets : ${cr.comparisonWallets.length + 1}`);
    }
    if (victimWalletAddr) {
      const vKn = KNOWN_LABELS[victimWalletAddr];
      lines.push(`Victim Wallet : ${victimWalletAddr}${vKn ? `  [${vKn.label}]` : ""}  (${victimPersonName})`);
    }
    lines.push(`${"─".repeat(64)}`);
    lines.push(`OVERALL RISK ASSESSMENT: ${riskStr}`);
    lines.push(`${"─".repeat(64)}`);
    // ── Key Findings & Top Priority Actions ─────────────────────────────────
    {
      lines.push(``);
      lines.push(`╔${"═".repeat(62)}╗`);
      lines.push(`║  KEY FINDINGS & TOP PRIORITY ACTIONS                         ║`);
      lines.push(`╚${"═".repeat(62)}╝`);
      lines.push(``);
      let kfN = 0;
      const kfItem = (header: string, detail: string) => {
        kfN++;
        lines.push(`   ${kfN}. ${header}`);
        lines.push(`      ${detail}`);
        lines.push(``);
      };
      // 1. Commingling
      if (tier1Count > 0) {
        kfItem(
          `⚠  CRITICAL COMMINGLING — ${tier1Count} DIRECT shared address${tier1Count !== 1 ? "es" : ""} between tracked wallets.`,
          `Strong evidence of coordinated fund movement. File joint investigation immediately.`
        );
      } else if (totalFindings > 0) {
        kfItem(
          `△  INDIRECT COMMINGLING — ${totalFindings} shared node${totalFindings !== 1 ? "s" : ""} across tiers 2–6.`,
          `Wallets share counterparties at multiple hops — consistent with coordinated use. See §1.`
        );
      } else {
        kfItem(
          `✓  LOW RISK — No commingling detected in loaded TX history.`,
          `Expand wallet set or use "Load All History" on each wallet and re-run Full Package.`
        );
      }
      // 2. Top exchange subpoena target (US-first)
      if (exchFlows.length > 0) {
        const kfUS  = new Set(["Coinbase","COINBASE","Kraken","KRAKEN","Gemini","GEMINI","Bitstamp","BITSTAMP","Uphold","UPHOLD","Robinhood","ROBINHOOD","Binance.US","BINANCE.US","Bittrex","BITTREX","eToro","ETORO"]);
        // Stable: US-regulated → volume → address tie-breaker
        const kfTop = [...exchFlows].sort((a, b) => {
          const uA = kfUS.has(a.exchLabel.split(/\s+/)[0]) ? 0 : 1;
          const uB = kfUS.has(b.exchLabel.split(/\s+/)[0]) ? 0 : 1;
          if (uA !== uB) return uA - uB;
          const vA = a.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
          const vB = b.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
          if (vB !== vA) return vB - vA;
          return a.exchAddr.localeCompare(b.exchAddr);
        })[0];
        const tfVol = kfTop.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        const isUS  = kfUS.has(kfTop.exchLabel.split(/\s+/)[0]);
        kfItem(
          `★  SUBPOENA — File immediately with ${kfTop.exchLabel}${isUS ? " (US-regulated ★)" : ""}.`,
          `${kfTop.txs.length} txs · ${tfVol.toLocaleString("en-US", { maximumFractionDigits: 0 })} ${chainUp} · ${kfTop.exchAddr.slice(0,12)}…${kfTop.exchAddr.slice(-6)} — See §7 Template 1.`
        );
      }
      // 3. Peel-chain layering
      {
        const pcKF = new Map<string, Tx[]>();
        for (const [w, txs] of Object.entries(cr?.walletTxs ?? {})) pcKF.set(w, txs);
        if (exchWalletTxMap) for (const [w, txs] of exchWalletTxMap) if (!pcKF.has(w)) pcKF.set(w, txs);
        // Stable: highest peel score first; wallet address tie-breaker
        const pcArr = Array.from(pcKF.entries()).map(([w, txs]) => ({ wallet: w, score: detectPeelChainPatterns(txs, chain).peelChainScore })).sort((a, b) => b.score - a.score || a.wallet.localeCompare(b.wallet));
        if (pcArr.length > 0 && pcArr[0].score >= 40) {
          const allW = cr ? [address, ...cr.comparisonWallets] : [address];
          const wi   = allW.indexOf(pcArr[0].wallet);
          const lbl  = wi >= 0 ? `W${wi + 1}` : `${pcArr[0].wallet.slice(0,10)}…`;
          const cnt  = pcArr.filter(x => x.score >= 40).length;
          kfItem(
            `🔍  PEEL-CHAIN LAYERING — ${cnt} wallet${cnt !== 1 ? "s" : ""} show layering signals. Top: ${lbl} (${pcArr[0].score}/100 — ${pcArr[0].score >= 55 ? "HIGH" : "MODERATE"}).`,
            `Include in subpoena to establish structuring/layering pattern. See §5 for full scores.`
          );
        }
      }
      // 4. Private convergence nodes
      if (mr) {
        const pvAll = [...mr.sharedCounterparties, ...mr.commonEndpoints].filter(s => !["exchange","bridge"].includes(s.knownInfo?.type ?? ""));
        if (pvAll.length > 0) {
          kfItem(
            `🔗  PRIVATE CONVERGENCE — ${pvAll.length} non-exchange node${pvAll.length !== 1 ? "s" : ""} shared by multiple wallets.`,
            `Top: ${pvAll[0].address.slice(0,12)}…${pvAll[0].address.slice(-6)} (${pvAll[0].appearances.length} wallets). Supports common control / conspiracy theory.`
          );
        }
      }
      // 5. Data coverage warning
      {
        const totalLoaded = Object.values(cr?.walletTxs ?? {}).reduce((s, txs) => s + txs.length, 0);
        if (totalLoaded < 200) {
          kfItem(
            `📊  DATA COVERAGE — Only ${totalLoaded} transactions loaded across all wallets.`,
            `Click "Load All History" on each wallet, then re-run Full Package for maximum coverage.`
          );
        }
      }
      if (kfN === 0) {
        lines.push(`   Run Full Package with loaded transaction history to generate key findings.`);
        lines.push(``);
      }
    }

    // ── MASTER DATA REQUEST — placed here for immediate law enforcement access ──
    {
      const mDiv  = "═".repeat(67);
      const mDash = "─".repeat(67);
      lines.push(``);
      lines.push(`   ${mDiv}`);
      lines.push(`   MASTER DATA REQUEST — USE IN ALL SUBPOENAS & KYC LETTERS`);
      lines.push(`   ${mDiv}`);
      lines.push(`   The following categories constitute a legally comprehensive data request`);
      lines.push(`   suitable for any cryptocurrency exchange subject to U.S. jurisdiction,`);
      lines.push(`   MLAT treaty obligations, or voluntary disclosure obligations. Each item`);
      lines.push(`   is specifically drafted to foreclose partial or evasive responses.`);
      lines.push(`   Include the full list — or cite this section by reference — in any`);
      lines.push(`   subpoena, Section 2703 request, legal hold letter, or MLAT filing.`);
      lines.push(``);
      const masterSectionsTop: Array<[string, string[]]> = [
        ["A. ACCOUNT HOLDER IDENTITY & KYC DOCUMENTS", [
          " 1. The full legal name(s) of all account holders as provided during registration",
          "    and as updated at any point, including all prior names and aliases of record.",
          " 2. Dates of birth, places of birth, and all government-issued identification",
          "    documents submitted at any stage of the account lifecycle, including passport",
          "    numbers, driver's license numbers, national ID numbers, and issuing jurisdiction.",
          " 3. All email addresses, phone numbers (including mobile/WhatsApp), usernames,",
          "    display names, and account aliases — both currently active and historical.",
          " 4. All physical addresses and mailing addresses provided, including billing",
          "    addresses associated with any linked payment method.",
          " 5. Declared nationality, citizenship status, country of tax residence, and",
          "    source-of-funds declarations (SoF) submitted at account opening or update.",
          " 6. All KYC/AML documentation submitted at any stage, including but not limited",
          "    to: proof of identity, proof of address, source-of-wealth declarations,",
          "    and political exposure person (PEP) screening results.",
          " 7. Enhanced Due Diligence (EDD) records, account verification tier, and the",
          "    specific documentation used to achieve each verification level.",
          " 8. All photographs, selfie images, and liveness-check biometric data submitted",
          "    during identity verification — including the date and device of submission.",
          " 9. Employer information, business name, and occupation as declared by the",
          "    account holder at any time.",
        ]],
        ["B. IP ADDRESSES, DEVICE FINGERPRINTS & SESSION LOGS", [
          "10. The full IP address logs associated with: (a) initial account registration;",
          "    (b) all subsequent logins, whether successful or failed; (c) all transactions",
          "    including deposits, withdrawals, and trades; (d) all password reset events;",
          "    (e) all two-factor authentication (2FA) enrollment or modification events;",
          "    (f) all changes to account security settings — each with complete timestamps.",
          "11. Geolocation data derived from IP addresses, including city, region, country,",
          "    and ISP or hosting provider for each recorded IP address.",
          "12. Device fingerprint records including device IDs, hardware identifiers,",
          "    browser fingerprints, and any other device-identifying attributes captured.",
          "13. User-agent strings, browser names/versions, OS versions, and app versions",
          "    recorded for each authenticated session.",
          "14. Mobile device information: device model, IMEI, IMSI, SIM details, OS version.",
          "15. Complete session logs including session tokens, duration, and all actions",
          "    taken during each authenticated session.",
          "16. VPN, proxy, Tor exit node, or anonymizing service usage detected by the platform.",
          "17. API key records: all keys created, permissions, IP addresses used, and logs.",
        ]],
        ["C. TRANSACTION HISTORY & BLOCKCHAIN ADDRESSES", [
          "18. The complete on-chain transaction history: all deposits, withdrawals, and",
          "    internal transfers — timestamps (UTC), counterparty addresses, amounts in",
          "    native asset and USD equivalent, TX hashes, and block numbers.",
          "19. All blockchain wallet addresses ever associated with this account: deposit,",
          "    withdrawal, and whitelisted addresses — active, archived, or removed.",
          "20. All internal transfer records (account-to-account / sub-account).",
          "21. All fiat on-ramp/off-ramp records: originating bank, beneficiary bank,",
          "    wire reference numbers, ACH batch IDs, dates, and amounts.",
          "22. Complete trade history: spot, margin, futures, and options — price, volume,",
          "    fees, timestamps.",
          "23. Staking, lending, earn, rewards, and airdrop records with amounts and dates.",
        ]],
        ["D. LINKED PAYMENT METHODS & FINANCIAL ACCOUNTS", [
          "24. All bank accounts ever linked: bank name, account holder name(s), full or",
          "    masked account number, routing / IBAN / SWIFT/BIC, and linking date.",
          "25. All credit/debit cards ever linked: card type, last 4 digits, cardholder",
          "    name, issuing bank name, and dates added/removed.",
          "26. All third-party payment processor records: PayPal, Venmo, Apple Pay,",
          "    Google Pay, Zelle, Square, Cash App, and any regional processors.",
          "27. All withdrawal destination records: full beneficiary wallet address or bank",
          "    account details for every withdrawal ever processed.",
          "28. P2P trading counterparties and payment method details.",
        ]],
        ["E. COMPLIANCE, SUSPICIOUS ACTIVITY & INTERNAL RECORDS", [
          "29. All Suspicious Activity Reports (SARs) filed with FinCEN or any FIU in",
          "    connection with this account or any transactions on the subject address(es).",
          "30. All Currency Transaction Reports (CTRs) filed in connection with this account.",
          "31. All account restrictions, holds, freezes, suspensions, and closures — with",
          "    specific compliance reason and date for each action.",
          "32. All internal AML monitoring alerts: alert type, score, triggering transaction,",
          "    and disposition (cleared, escalated, or SAR filed).",
          "33. All internal risk scores, customer risk ratings, and AML tier classifications.",
          "34. All communications between account holder and exchange (email, chat, tickets).",
          "35. All accounts linked by shared device fingerprint, IP address, email domain,",
          "    phone number, payment method, or KYC documents.",
          "36. Referral network records: who referred this account and who it referred.",
          "37. All chargeback, dispute, and fraud investigation records.",
        ]],
        ["F. CORPORATE / BUSINESS ACCOUNT RECORDS (if applicable)", [
          "38. Business registration: articles of incorporation, EIN/TIN, registered address,",
          "    jurisdiction of incorporation, and date of formation.",
          "39. Beneficial ownership: all individuals with ≥10% ownership or control,",
          "    with supporting KYC documentation.",
          "40. All authorized signatories, account administrators, and their KYC documents.",
          "41. Corporate resolution authorizing the exchange account.",
        ]],
        ["G. ADVANCED & ANCILLARY DATA", [
          "42. Cold/hot wallet segregation records for large institutional deposits.",
          "43. Custodial/omnibus account records, including sub-ledger entries.",
          "44. Any data previously provided to other law enforcement agencies on this",
          "    account — including the requesting agency and date of production.",
          "45. Any legal holds, preservation notices, or court orders previously received",
          "    by the exchange related to this account.",
        ]],
        ["H. MANDATORY PRESERVATION DIRECTIVE", [
          "Pursuant to 18 U.S.C. § 2703(f), you are directed to IMMEDIATELY AND COMPLETELY",
          "PRESERVE all records, data, logs, metadata, and communications related to the",
          "account(s) and address(es) identified in this request — including all categories",
          "A through G above — from the date of receipt until explicit written release.",
          "",
          "This obligation applies notwithstanding any routine data deletion policies or",
          "automated purge processes. Intentional or negligent destruction, alteration, or",
          "concealment of records subject to this directive may constitute obstruction of",
          "justice under 18 U.S.C. § 1519, exposing your organization and responsible",
          "individuals to criminal liability.",
        ]],
      ];
      for (const [secTitle, items] of masterSectionsTop) {
        lines.push(`   ${mDash}`);
        lines.push(`   ${secTitle}`);
        lines.push(`   ${mDash}`);
        for (const item of items) lines.push(`   ${item}`);
        lines.push(``);
      }
    }

    lines.push(``);
    lines.push(`1. COMMINGLING CHECK SUMMARY`);
    lines.push(`   ${"─".repeat(60)}`);
    if (cr) {
      lines.push(`   Wallets Scanned     : ${cr.comparisonWallets.length + 1}`);
      lines.push(`   Addresses Mapped    : ${cr.totalScanned}`);
      lines.push(`   Tier 1 (direct)    : ${cr.tieredCounts[0]} shared node${cr.tieredCounts[0] !== 1 ? "s" : ""}`);
      lines.push(`   Tier 2 (2-hop)     : ${cr.tieredCounts[1]} shared node${cr.tieredCounts[1] !== 1 ? "s" : ""}`);
      lines.push(`   Tiers 3–6          : ${cr.tieredCounts[2] + cr.tieredCounts[3] + cr.tieredCounts[4] + cr.tieredCounts[5]} shared node${(cr.tieredCounts[2] + cr.tieredCounts[3] + cr.tieredCounts[4] + cr.tieredCounts[5]) !== 1 ? "s" : ""}`);
      lines.push(`   Private Convergence: ${privFindings} address${privFindings !== 1 ? "es" : ""}`);
      lines.push(`   Exchange Shared    : ${exchFindings} address${exchFindings !== 1 ? "es" : ""}`);
      // Peel-chain risk summary
      {
        const pcWalletMap = new Map<string, Tx[]>();
        for (const [w, txs] of Object.entries(cr.walletTxs)) pcWalletMap.set(w, txs);
        if (exchWalletTxMap) for (const [w, txs] of exchWalletTxMap) if (!pcWalletMap.has(w)) pcWalletMap.set(w, txs);
        if (pcWalletMap.size > 0) {
          const pcScores = Array.from(pcWalletMap.values()).map(txs => detectPeelChainPatterns(txs, chain).peelChainScore);
          const pcHigh   = pcScores.filter(s => s >= 55).length;
          const pcMed    = pcScores.filter(s => s >= 40 && s < 55).length;
          const pcTotal  = pcHigh + pcMed;
          if (pcTotal > 0) {
            lines.push(`   Peel-Chain Risk    : ${pcTotal} wallet${pcTotal !== 1 ? "s" : ""} show moderate-to-high layering signals (40–100/100)`);
            lines.push(`     · High risk (≥55): ${pcHigh} wallet${pcHigh !== 1 ? "s" : ""}   · Moderate (40–54): ${pcMed} wallet${pcMed !== 1 ? "s" : ""}`);
            lines.push(`     See §5 Subpoena Targets for full peel-chain signal details.`);
          } else {
            lines.push(`   Peel-Chain Risk    : No moderate-to-high layering signals in loaded TX history`);
          }
        }
      }
      if (tier1Count > 0) {
        lines.push(``);
        lines.push(`   ⚠ CRITICAL: ${tier1Count} DIRECT shared address${tier1Count !== 1 ? "es" : ""} detected.`);
        lines.push(`   All tracked wallets share at least one direct counterparty — strong evidence`);
        lines.push(`   of coordinated fund movement. See Commingling Check section for full details.`);
      } else if (totalFindings > 0) {
        lines.push(``);
        lines.push(`   △ INDIRECT: ${totalFindings} shared address${totalFindings !== 1 ? "es" : ""} at depth 2+.`);
        lines.push(`   Wallets share intermediary addresses — may indicate shared services or`);
        lines.push(`   indirect commingling. Review findings in the full report below.`);
      } else {
        lines.push(``);
        lines.push(`   ✓ No commingling detected within 6-tier depth. Load more TX history`);
        lines.push(`   and re-run for deeper coverage.`);
      }
    } else {
      lines.push(`   (No commingle data — comparison wallets required)`);
    }

    lines.push(``);
    lines.push(`2. INTERSECTION / FUNNEL ANALYSIS SUMMARY`);
    lines.push(`   ${"─".repeat(60)}`);
    if (mr) {
      const allShared = [...new Map([...mr.sharedCounterparties, ...mr.commonEndpoints].map(s => [s.address, s])).values()];
      const privShared = allShared.filter(s => !["exchange","bridge","hot","custodial"].includes(s.knownInfo?.type ?? ""));
      const exchShared = allShared.filter(s => ["exchange","bridge"].includes(s.knownInfo?.type ?? ""));
      lines.push(`   Tracked Wallets         : ${mr.trackedWallets.length}`);
      lines.push(`   Private Convergence     : ${privShared.length} node${privShared.length !== 1 ? "s" : ""}`);
      lines.push(`   Exchange/Bridge Shared  : ${exchShared.length} node${exchShared.length !== 1 ? "s" : ""}`);
      if (privShared.length > 0) {
        lines.push(``);
        lines.push(`   ⚠ ${privShared.length} private address${privShared.length !== 1 ? "es" : ""} reached by 2+ wallets within 6 hops.`);
        const top = privShared[0];
        lines.push(`   Top convergence: ${top.address}  (${top.appearances.length}/${mr.trackedWallets.length} wallets)`);
      } else {
        lines.push(``);
        lines.push(`   ✓ No private convergence at depth 1–6.`);
      }
    } else {
      lines.push(`   (No funnel data available)`);
    }

    lines.push(``);
    lines.push(`3. EXCHANGE FLOWS SUMMARY`);
    lines.push(`   ${"─".repeat(60)}`);
    if (exchFlows.length > 0) {
      lines.push(`   Exchange Contacts : ${uniqueExchanges.length} exchange${uniqueExchanges.length !== 1 ? "s" : ""} identified`);
      uniqueExchanges.forEach(e => lines.push(`   · ${e}`));
      lines.push(``);
      lines.push(`   ACTION: File subpoena / KYC requests with all exchanges listed above.`);
      lines.push(`   Request: account holder identity, IP logs, linked payment methods, full TX records.`);
    } else {
      lines.push(`   No exchange flows in loaded TX history. Load full history and re-run.`);
    }

    lines.push(``);
    lines.push(`4. RECOMMENDED INVESTIGATIVE ACTIONS`);
    lines.push(`   ${"─".repeat(60)}`);
    let priority = 1;
    if (victimWalletAddr) {
      lines.push(`   VICTIM  : ${victimPersonName}  —  ${victimWalletAddr}`);
      lines.push(``);
    }
    if (tier1Count > 0) {
      lines.push(`   ★ P${priority++}: Subpoena all Tier 1 commingled addresses immediately.`);
      lines.push(`      Direct shared counterparties = highest-confidence evidence of coordination.`);
    }
    if (exchFlows.length > 0) {
      lines.push(`   ★ P${priority++}: File KYC/subpoena with ${uniqueExchanges.length} exchange${uniqueExchanges.length !== 1 ? "s" : ""}:`);
      uniqueExchanges.forEach(e => lines.push(`      · ${e}`));
    }
    if (mr && [...mr.sharedCounterparties, ...mr.commonEndpoints].length > 0) {
      lines.push(`   ★ P${priority++}: Investigate private convergence nodes from funnel analysis.`);
      lines.push(`      Addresses shared by 2+ wallets within 6 hops — potential mixing intermediaries.`);
    }
    if (priority === 1) {
      lines.push(`   · No high-priority findings. Load full TX history and re-run for broader coverage.`);
      lines.push(`   · Consider expanding the wallet list to include additional suspect addresses.`);
    }

    // ─── SECTION 5: RECOMMENDED SUBPOENA TARGETS ─────────────────────────────
    lines.push(``);
    lines.push(`5. RECOMMENDED SUBPOENA TARGETS`);
    lines.push(`   ${"─".repeat(60)}`);
    {
      // Build sorted exchange target list for the top-10 summary box
      const US_REG_S5 = new Set([
        "Coinbase","COINBASE","Kraken","KRAKEN","Gemini","GEMINI",
        "Bitstamp","BITSTAMP","Uphold","UPHOLD","Robinhood","ROBINHOOD",
        "Binance.US","BINANCE.US","Bittrex","BITTREX","eToro","ETORO",
      ]);
      type T10E = { addr: string; label: string; vol: number; usd: number; wallets: Set<string>; txCount: number; peelScore: number };
      const t10Map = new Map<string, T10E>();
      const addT10 = (addr: string, label: string, tx: Tx, wallet: string) => {
        if (!t10Map.has(addr)) t10Map.set(addr, { addr, label, vol: 0, usd: 0, wallets: new Set(), txCount: 0, peelScore: 0 });
        const e = t10Map.get(addr)!;
        e.txCount++;
        e.vol += parseFloat(tx.value) || 0;
        if (tx.valueUsd > 0) e.usd += tx.valueUsd;
        e.wallets.add(wallet);
      };
      for (const flow of (cr?.exchFlows ?? [])) {
        for (const tx of flow.txs) addT10(flow.exchAddr, flow.exchLabel, tx, flow.sourceWallet);
      }
      for (const [wallet, txs] of (exchWalletTxMap ?? new Map())) {
        for (const tx of txs) {
          const cp = tx.direction === "in" ? tx.from : tx.to;
          if (!cp) continue;
          const kn5 = getKnownInfo(cp, chain);
          if (!kn5 || !["exchange","bridge","genesis"].includes(kn5.type)) continue;
          addT10(cp, kn5.label, tx, wallet);
        }
      }
      // Compute peel scores per exchange (from flows into that exchange)
      for (const [addr, e] of t10Map) {
        const flowTxs = (cr?.exchFlows ?? []).filter(f => f.exchAddr === addr).flatMap(f => f.txs);
        if (flowTxs.length > 0) e.peelScore = detectPeelChainPatterns(flowTxs, chain).peelChainScore;
      }
      // Stable: US-regulated → wallet count → volume → address tie-breaker
      const sorted5 = Array.from(t10Map.values()).sort((a, b) => {
        const aUS = US_REG_S5.has(a.label.split(/\s+/)[0]) ? 0 : 1;
        const bUS = US_REG_S5.has(b.label.split(/\s+/)[0]) ? 0 : 1;
        if (aUS !== bUS) return aUS - bUS;
        if (a.wallets.size !== b.wallets.size) return b.wallets.size - a.wallets.size;
        if (b.vol !== a.vol) return b.vol - a.vol;
        return a.addr.localeCompare(b.addr);
      });
      const top10 = sorted5.slice(0, 10);

      if (top10.length > 0) {
        lines.push(`   Below are the ${top10.length} highest-priority exchange addresses for immediate subpoena /`);
        lines.push(`   KYC requests, ranked by US regulatory reach, commingling strength, and volume.`);
        lines.push(``);
        const col90 = "─".repeat(92);
        lines.push(`   ${col90}`);
        lines.push(`   #   Exchange               Address                   Volume              Wlts  Peel    Reason`);
        lines.push(`   ${col90}`);
        top10.forEach((e, i) => {
          const isUS  = US_REG_S5.has(e.label.split(/\s+/)[0]);
          const rank  = `#${i + 1}`.padEnd(3);
          const name  = (e.label + (isUS ? " ★" : "")).slice(0, 23).padEnd(23);
          const addr  = `${e.addr.slice(0, 10)}…${e.addr.slice(-5)}`.padEnd(17);
          const vol   = `${e.vol.toLocaleString("en-US", { maximumFractionDigits: 0 })} ${chainUp}`.padEnd(19);
          const wlts  = String(e.wallets.size).padStart(4);
          const peel  = (e.peelScore > 0 ? `${e.peelScore}/100` : "N/A").padEnd(7);
          const why   = isUS               ? "US-regulated ★"
                      : e.wallets.size > 1 ? `${e.wallets.size} wallets commingled`
                      : e.peelScore >= 30  ? "Peel-chain signals"
                      :                     "Exchange deposit";
          lines.push(`   ${rank} ${name} ${addr} ${vol} ${wlts}  ${peel} ${why}`);
        });
        lines.push(`   ${col90}`);
        lines.push(``);
        lines.push(`   Full target details (all identified exchange addresses):`);
        lines.push(`   ${"─".repeat(60)}`);
      }
    }
    lines.push(generateSubpoenaTargets(cr, mr, exchWalletTxMap ?? new Map()));

    // ─── SECTION 6: KEY FLOW VISUALIZATION ───────────────────────────────────
    lines.push(``);
    lines.push(`6. KEY FLOW VISUALIZATION`);
    lines.push(`   ${"─".repeat(60)}`);
    {
      const shortA  = (a: string) => a.length > 14 ? `${a.slice(0, 8)}…${a.slice(-6)}` : a;
      const fmtV    = (v: number) =>
        v >= 1_000_000 ? `${(v / 1_000_000).toFixed(2)}M ${chainUp}`
        : v >= 1_000   ? `${(v / 1_000).toFixed(2)}K ${chainUp}`
        :                `${v.toFixed(4)} ${chainUp}`;
      const allWallets = cr ? [address, ...cr.comparisonWallets] : [address];

      // Sort exchange flows by volume descending for all subsequent use
      // Stable: highest volume first; address tie-breaker
      const sortedFlows = [...exchFlows].sort((a, b) => {
        const vA = a.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        const vB = b.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        if (vB !== vA) return vB - vA;
        return a.exchAddr.localeCompare(b.exchAddr);
      }).slice(0, 10);

      // Peel scores per wallet (for insights bullet)
      const pcMap6 = new Map<string, Tx[]>();
      for (const [w, txs] of Object.entries(cr?.walletTxs ?? {})) pcMap6.set(w, txs);
      if (exchWalletTxMap) for (const [w, txs] of exchWalletTxMap) if (!pcMap6.has(w)) pcMap6.set(w, txs);
      // Stable: highest peel score first; wallet address tie-breaker
      const walletPeels = Array.from(pcMap6.entries())
        .map(([w, txs]) => ({ wallet: w, score: detectPeelChainPatterns(txs, chain).peelChainScore }))
        .sort((a, b) => b.score - a.score || a.wallet.localeCompare(b.wallet));
      const topPeel    = walletPeels[0];
      const totalVol6  = sortedFlows.reduce((s, f) => s + f.txs.reduce((ss, t) => ss + (parseFloat(t.value) || 0), 0), 0);
      const uniqueExch6 = new Set(sortedFlows.map(f => f.exchAddr)).size;

      // ── Key Visualization Insights ────────────────────────────────────────
      lines.push(`   Key Visualization Insights:`);
      if (sortedFlows.length > 0) {
        const tf   = sortedFlows[0];
        const tfVol = tf.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
        const tfWI  = allWallets.indexOf(tf.sourceWallet);
        const tfSrc = tfWI >= 0 ? `W${tfWI + 1}` : shortA(tf.sourceWallet);
        lines.push(`   · Top flow: ${tfSrc} → ${tf.exchLabel} — ${fmtV(tfVol)} (${tf.txs.length} tx${tf.txs.length !== 1 ? "s" : ""})`);
      }
      if (mr) {
        const privCount = [...mr.sharedCounterparties, ...mr.commonEndpoints]
          .filter(s => !["exchange","bridge"].includes(s.knownInfo?.type ?? "")).length;
        if (privCount > 0) {
          const topN = [...mr.sharedCounterparties, ...mr.commonEndpoints]
            .filter(s => !["exchange","bridge"].includes(s.knownInfo?.type ?? ""))[0];
          lines.push(`   · ${privCount} private convergence node${privCount !== 1 ? "s" : ""} shared by 2+ wallets — top: ${shortA(topN.address)} (${topN.appearances.length} wallets)`);
        }
      }
      if (topPeel && topPeel.score >= 30) {
        const tpWI  = allWallets.indexOf(topPeel.wallet);
        const tpLbl = tpWI >= 0 ? `W${tpWI + 1}` : shortA(topPeel.wallet);
        lines.push(`   · Highest peel-chain score: ${tpLbl} — ${topPeel.score}/100 (${topPeel.score >= 55 ? "HIGH" : "MODERATE"} layering risk — immediate subpoena recommended)`);
      }
      if (totalVol6 > 0) {
        lines.push(`   · Total exchange-directed volume: ${fmtV(totalVol6)} across ${uniqueExch6} exchange address${uniqueExch6 !== 1 ? "es" : ""}`);
      }
      lines.push(``);

      // ── ASCII Flow Summary — top 10 by volume ────────────────────────────
      lines.push(`   ASCII Flow Summary (top ${sortedFlows.length} highest-volume flows):`);
      if (sortedFlows.length > 0) {
        for (const f of sortedFlows) {
          const vol  = f.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
          const wi   = allWallets.indexOf(f.sourceWallet);
          const src  = wi >= 0 ? `W${wi + 1}` : shortA(f.sourceWallet);
          const volFmt = vol.toLocaleString("en-US", { maximumFractionDigits: 2 });
          lines.push(`   ${src} → [${volFmt} ${chainUp}] → ${f.exchLabel} (${shortA(f.exchAddr)})`);
        }
      } else {
        lines.push(`   (No exchange flows detected in loaded history)`);
      }
      if (mr) {
        const privNodes = [...mr.sharedCounterparties, ...mr.commonEndpoints]
          .filter(s => !["exchange","bridge"].includes(s.knownInfo?.type ?? ""))
          .slice(0, 6);
        if (privNodes.length > 0) {
          lines.push(``);
          lines.push(`   Shared Private Convergence Nodes:`);
          for (const n of privNodes) {
            const kn6  = getKnownInfo(n.address, chain);
            const lbl6 = kn6 ? ` (${kn6.label})` : "";
            const ws6  = n.appearances.slice(0, 6).map(a => {
              const wi2 = allWallets.indexOf(a.wallet);
              return wi2 >= 0 ? `W${wi2 + 1}` : shortA(a.wallet);
            }).join(", ");
            lines.push(`   • ${shortA(n.address)}${lbl6} ← shared by ${ws6} (${n.appearances.length} wallet${n.appearances.length !== 1 ? "s" : ""})`);
          }
        }
      }

      // ── Mermaid.js Flowchart — hub-and-spoke ─────────────────────────────
      lines.push(``);
      lines.push(`   Mermaid.js Flowchart — paste into https://mermaid.live :`);
      lines.push(`   ${"─".repeat(60)}`);
      {
        const mermaid: string[] = ["graph LR"];
        const mNodeMap = new Map<string, string>();
        let mIdx = 0;
        const mId = (a: string) => { if (!mNodeMap.has(a)) mNodeMap.set(a, `N${mIdx++}`); return mNodeMap.get(a)!; };
        // Top 8 highest-volume flows → hub-and-spoke, only wallets with active edges
        const hubFlows = sortedFlows.slice(0, Math.min(8, sortedFlows.length));
        const activeWallets = new Set(hubFlows.map(f => f.sourceWallet));
        allWallets.forEach((w, i) => {
          if (activeWallets.has(w)) {
            mermaid.push(`  ${mId(w)}["W${i + 1}\\n${shortA(w)}"]`);
          }
        });
        for (const f of hubFlows) {
          const vol = f.txs.reduce((s, t) => s + (parseFloat(t.value) || 0), 0);
          const kn  = getKnownInfo(f.exchAddr, chain);
          mermaid.push(`  ${mId(f.exchAddr)}["${(kn?.label ?? shortA(f.exchAddr)).replace(/"/g, "'")}\\nEXCHANGE"]`);
          mermaid.push(`  ${mId(f.sourceWallet)} -->|"${fmtV(vol)}"| ${mId(f.exchAddr)}`);
        }
        // Shared convergence nodes (dashed)
        if (mr) {
          const privSh = [...mr.sharedCounterparties, ...mr.commonEndpoints]
            .filter(s => !["exchange","bridge"].includes(s.knownInfo?.type ?? ""))
            .slice(0, 3);
          for (const n of privSh) {
            mermaid.push(`  ${mId(n.address)}["SHARED\\n${shortA(n.address)}"]`);
            // Only connect wallets that actually appear in this shared node
            n.appearances.slice(0, 5).forEach(a => {
              if (allWallets.includes(a.wallet)) {
                mermaid.push(`  ${mId(a.wallet)} -.->|"shared"| ${mId(n.address)}`);
              }
            });
          }
        }
        mermaid.forEach(l => lines.push(`   ${l}`));
      }
      lines.push(`   ${"─".repeat(60)}`);

      lines.push(``);
      lines.push(`   [Graph JSON export omitted from this report to reduce length.]`);
      lines.push(`   [Run the standalone Exchange Flows report to generate and copy the full JSON block.]`);
    }


    lines.push(``);
    lines.push(`${"═".repeat(64)}`);
    lines.push(`FULL REPORTS FOLLOW IN THREE SECTIONS BELOW.`);
    lines.push(`Each section is independently signed with a tamper-evident SHA-256 hash.`);
    lines.push(`${"═".repeat(64)}`);

    return auditAndSign(lines, {
      reportType: "Full Package — Executive Summary",
      chain: chainUp,
      target: address,
      victimWallet: victimWalletAddr || "(not specified)",
      victimName: victimPersonName || "(not specified)",
    });
  }

  // ── Victim → Thief Path Trace report generator ────────────────────────────
  function generatePathTraceReport(
    steps: Array<{ wallet: string; txHash: string }>,
    hopData: Array<{ from: string; to: string; knownHash: string; tx: Tx | null; allTxs: Tx[] }>,
    expandTxs: Tx[]
  ): string {
    const chainUp = chain.toUpperCase();
    const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const rule = "─".repeat(66);
    const sepSection = (label = "") =>
      label ? `\n${rule}\n  ${label}\n${rule}` : rule;

    const fmtDate = (ts: string) => ts ? ts.replace("T", " ").slice(0, 16) + " UTC" : "—";
    const fmtAmt  = (v: string, dir: "in" | "out") => {
      const n = parseFloat(v);
      const sign = dir === "in" ? "+" : "−";
      if (!n || isNaN(n)) return `${sign}0.00`;
      const abs = Math.abs(n);
      const decimals = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      return `${sign}${n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
    };
    const emitTx = (tx: Tx, pad = "") => {
      const dir    = tx.direction === "in" ? "IN " : "OUT";
      const asset  = (tx as Tx & { tokenSymbol?: string }).tokenSymbol ?? chainUp;
      const usd    = tx.valueUsd && tx.valueUsd > 0
        ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD]`
        : "";
      const lines: string[] = [];
      lines.push(`${pad}  Direction : [${dir}]`);
      lines.push(`${pad}  Amount    : ${fmtAmt(tx.value, tx.direction as "in" | "out")} ${asset}${usd}`);
      lines.push(`${pad}  From      : ${tx.from ?? "—"}`);
      lines.push(`${pad}  To        : ${tx.to ?? "—"}`);
      lines.push(`${pad}  TX Hash   : ${tx.hash ?? "(no hash)"}`);
      lines.push(`${pad}  Date      : ${fmtDate(tx.timestamp ?? "")}`);
      if ((tx as Tx & { destinationTag?: number | null }).destinationTag != null)
        lines.push(`${pad}  ↳ Destination Tag : ${(tx as Tx & { destinationTag?: number | null }).destinationTag}`);
      if (tx.memo) lines.push(`${pad}  ↳ Memo    : ${tx.memo}`);
      return lines;
    };

    const walletAddrs = steps.map(s => s.wallet);
    const lines: string[] = [];
    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║    VICTIM → THIEF PATH TRACE — CryptoChainTrace             ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated    : ${now}`);
    lines.push(`Chain        : ${chainUp}`);
    steps.forEach((s, i) => {
      const role = i === 0 ? "VICTIM" : i === 1 ? "THIEF" : `HOP ${i + 1}`;
      const kn = KNOWN_LABELS[s.wallet];
      lines.push(`${role.padEnd(12)} : ${s.wallet}${kn ? `  [${kn.label}]` : ""}`);
      if (s.txHash) lines.push(`${"".padEnd(14)}  TX → ${s.txHash}`);
    });
    lines.push(`Total Hops   : ${hopData.length}`);
    lines.push("");
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);
    lines.push("");

    // ── Per-hop details ────────────────────────────────────────────────────
    let originAmount: number | null = null;

    hopData.forEach((hop, idx) => {
      const fromKn   = KNOWN_LABELS[hop.from];
      const toKn     = KNOWN_LABELS[hop.to];
      const fromRole = idx === 0 ? "VICTIM" : `HOP ${idx + 1}`;
      const toRole   = idx === hopData.length - 1 ? "FINAL DESTINATION" : `HOP ${idx + 2}`;

      lines.push(sepSection(`HOP ${idx + 1}  —  ${fromRole} → ${toRole}`));
      lines.push(`  FROM      : ${hop.from}${fromKn ? `  [${fromKn.label.toUpperCase()}]` : "  (unidentified)"}`);
      lines.push(`  TO        : ${hop.to}${toKn   ? `  [${toKn.label.toUpperCase()}]`   : "  (unidentified)"}`);
      if (hop.knownHash) lines.push(`  Known TX  : ${hop.knownHash}`);
      lines.push("");

      // Primary TX — the user-specified hash, or best match from fetched history
      const primaryTx = hop.tx;
      if (primaryTx) {
        const amt = parseFloat(primaryTx.value) || 0;
        if (idx === 0 && originAmount === null && amt > 0) originAmount = amt;
        const taintPct = originAmount && originAmount > 0 && amt > 0
          ? ((amt / originAmount) * 100).toFixed(1)
          : null;
        if (taintPct !== null) lines.push(`  Taint     : ${taintPct}% of original stolen funds reached this point`);
        lines.push(`  ─ Transaction Detail ─`);
        emitTx(primaryTx, "  ").forEach(l => lines.push(l));
      } else if (hop.knownHash) {
        lines.push(`  ⚠  TX ${hop.knownHash.slice(0, 16)}…`);
        lines.push(`     not found in loaded history. Load full TX history on this wallet for full detail.`);
      } else {
        lines.push(`  ⚠  No TX hash provided and no matching transaction found between these wallets.`);
        lines.push(`     Load full TX history on the Hop ${idx + 1} wallet to locate the transaction.`);
      }

      // Additional transactions between this pair (supporting evidence) — spam filtered
      const extras = hop.allTxs.filter(t => t.hash !== primaryTx?.hash && passesSpamFilter(t, chain)).slice(0, 5);
      if (extras.length > 0) {
        lines.push("");
        lines.push(`  Additional transactions between these wallets (${extras.length} shown):`);
        extras.forEach((tx, ti) => {
          const isLast  = ti === extras.length - 1;
          const conn    = isLast ? "└─" : "├─";
          const childPx = isLast ? "   " : "│  ";
          const dir  = tx.direction === "in" ? "IN " : "OUT";
          const asset = (tx as Tx & { tokenSymbol?: string }).tokenSymbol ?? chainUp;
          const usd = tx.valueUsd && tx.valueUsd > 0
            ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD]`
            : "";
          lines.push(`  ${conn} [${dir}]  ${fmtAmt(tx.value, tx.direction as "in" | "out")} ${asset}${usd}  ${fmtDate(tx.timestamp ?? "")}`);
          lines.push(`  ${childPx}  Hash: ${tx.hash ?? "(none)"}`);
          if (tx.memo) lines.push(`  ${childPx}  Memo: ${tx.memo}`);
        });
      }
      lines.push("");
    });

    // ── Wallet clustering ─────────────────────────────────────────────────
    lines.push(sepSection("WALLET CLUSTERING"));
    const seenPositions = new Map<string, number[]>();
    walletAddrs.forEach((w, i) => {
      if (!seenPositions.has(w)) seenPositions.set(w, []);
      seenPositions.get(w)!.push(i + 1);
    });
    const clusters = [...seenPositions.entries()].filter(([, pos]) => pos.length > 1);
    if (clusters.length === 0) {
      lines.push("  No repeated wallets — each hop uses a distinct address.");
    } else {
      lines.push(`  ${clusters.length} wallet(s) appear at multiple path positions (potential mixing / address reuse):`);
      clusters.forEach(([addr, pos]) => {
        const kn = KNOWN_LABELS[addr];
        lines.push(`  • ${addr}${kn ? `  [${kn.label}]` : ""}`);
        lines.push(`    Positions : ${pos.join(", ")}`);
      });
    }
    lines.push("");

    // ── Expand from final wallet ──────────────────────────────────────────
    const lastAddr = walletAddrs[walletAddrs.length - 1];
    lines.push(sepSection(`EXPAND FROM FINAL WALLET — ${lastAddr}`));
    if (expandTxs.length === 0) {
      lines.push("  No further activity found from the final wallet in loaded history.");
      lines.push("  Load full TX history on the final wallet to expand the trail.");
    } else {
      lines.push(`  ${expandTxs.length} further transaction${expandTxs.length !== 1 ? "s" : ""} from the final wallet (newest first):`);
      lines.push("");
      expandTxs.forEach((tx, ti) => {
        const isLast  = ti === expandTxs.length - 1;
        const conn    = isLast ? "└─" : "├─";
        const childPx = isLast ? "   " : "│  ";
        const dir     = tx.direction === "in" ? "IN " : "OUT";
        const cp      = tx.direction === "in" ? tx.from : tx.to;
        const cpKn    = cp ? KNOWN_LABELS[cp] : null;
        const asset   = (tx as Tx & { tokenSymbol?: string }).tokenSymbol ?? chainUp;
        const usd     = tx.valueUsd && tx.valueUsd > 0
          ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD]`
          : "";
        lines.push(`${conn} [${dir}]  ${fmtAmt(tx.value, tx.direction as "in" | "out")} ${asset}${usd}`);
        lines.push(`${childPx}  Counterparty : ${cp ?? "—"}${cpKn ? `  [${cpKn.label}]` : ""}`);
        lines.push(`${childPx}  TX Hash      : ${tx.hash ?? "(no hash)"}`);
        lines.push(`${childPx}  Date         : ${fmtDate(tx.timestamp ?? "")}`);
        if (tx.memo) lines.push(`${childPx}  ↳ Memo       : ${tx.memo}`);
        if (!isLast) lines.push(childPx);
      });
    }
    lines.push("");

    // ── Trail summary ─────────────────────────────────────────────────────
    lines.push(sepSection("TRAIL SUMMARY"));
    const lastKn = KNOWN_LABELS[lastAddr];
    if (lastKn?.type === "exchange") {
      lines.push(`  ✦ FUNDS SENT TO EXCHANGE`);
      lines.push(`    Exchange : ${lastKn.label}`);
      lines.push(`    Address  : ${lastAddr}`);
      lines.push(`    Action   : File subpoena / KYC request with ${lastKn.label} to obtain account-holder`);
      lines.push(`               identity, IP logs, and transaction records.`);
    } else if (lastKn?.type === "bridge") {
      lines.push(`  ✦ FUNDS CROSSED A BRIDGE — trail continues on destination chain`);
      lines.push(`    Bridge  : ${lastKn.label}`);
      lines.push(`    Address : ${lastAddr}`);
      lines.push(`    Action  : Identify destination chain and continue trace there.`);
    } else {
      lines.push(`  ✦ TRAIL ENDS HERE — final wallet is an unidentified private address`);
      lines.push(`    Address : ${lastAddr}`);
      lines.push(`    Action  : Monitor for future activity. Load full TX history and expand trail.`);
    }
    lines.push("");
    lines.push(`  Victim         : ${walletAddrs[0]}`);
    lines.push(`  Thief          : ${walletAddrs[1]}`);
    lines.push(`  Total Hops     : ${hopData.length}`);
    if (originAmount !== null) {
      lines.push(`  Origin Amount  : ${(originAmount as number).toFixed(8)} ${chainUp} (first hop TX)`);
    }
    lines.push("");

    return auditAndSign(lines, {
      reportType: "Victim → Thief Path Trace Report",
      chain: chainUp,
      target: walletAddrs[0],
      comparisons: walletAddrs.slice(1),
      depth: `${hopData.length} hop${hopData.length !== 1 ? "s" : ""}`,
      walletLabels: true,
    });
  }

  // ── Connection Finder Report ───────────────────────────────────────────────
  function generateTieFinderReport(): string {
    if (!tieResult) return "";
    const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";
    const chainUp = tieResult.chain.toUpperCase();
    const rule = "─".repeat(66);
    const sep = (label = "") =>
      label ? `\n${rule}\n  ${label}\n${rule}` : rule;
    const fmtDate = (ts: string) => ts ? ts.replace("T", " ").slice(0, 16) + " UTC" : "—";
    const fmtAmt = (v: string, dir: "in" | "out") => {
      const n = parseFloat(v);
      const sign = dir === "in" ? "+" : "−";
      if (!n || isNaN(n)) return `${sign}0.00`;
      const abs = Math.abs(n);
      const decimals = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
      return `${sign}${n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
    };
    const emitTx = (tx: Tx, pad = "") => {
      const dir   = tx.direction === "in" ? "IN " : "OUT";
      const asset = (tx as Tx & { tokenSymbol?: string }).tokenSymbol || chainUp;
      const usd   = tx.valueUsd > 0 ? `  [$${tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD]` : "";
      const out: string[] = [];
      out.push(`${pad}  Direction : [${dir}]`);
      out.push(`${pad}  Amount    : ${fmtAmt(tx.value, tx.direction as "in" | "out")} ${asset}${usd}`);
      out.push(`${pad}  From      : ${tx.from || "—"}`);
      out.push(`${pad}  To        : ${tx.to || "—"}`);
      out.push(`${pad}  TX Hash   : ${tx.hash || "(none)"}`);
      out.push(`${pad}  Date      : ${fmtDate(tx.timestamp || "")}`);
      if ((tx as Tx & { destinationTag?: number | null }).destinationTag != null)
        out.push(`${pad}  ↳ Dest Tag : ${(tx as Tx & { destinationTag?: number | null }).destinationTag}`);
      if (tx.memo) out.push(`${pad}  ↳ Memo     : ${tx.memo}`);
      return out;
    };

    const lines: string[] = [];
    lines.push(`╔══════════════════════════════════════════════════════════════╗`);
    lines.push(`║      CONNECTION FINDER REPORT — CryptoChainTrace            ║`);
    lines.push(`╚══════════════════════════════════════════════════════════════╝`);
    lines.push(`CRYPTOCHAINTRACE — BLOCKCHAIN INTELLIGENCE`);
    lines.push(`AGENCY / LAW ENFORCEMENT EDITION`);
    lines.push(`${"─".repeat(64)}`);
    lines.push(`Generated  : ${now}`);
    lines.push(`Chain      : ${chainUp}`);
    lines.push(`Wallet A   : ${tieResult.walletA}`);
    lines.push(`Wallet B   : ${tieResult.walletB}`);
    lines.push(`Max Hops   : ${tieResult.maxHops}`);
    lines.push(`Scanned    : ${tieResult.nodesScannedA} nodes from A  |  ${tieResult.nodesScannedB} nodes from B`);
    lines.push("");
    lines.push(`NOTE: TX details are pulled from the full combined transaction history of ALL tracked wallets + all discovered intermediate addresses along each path.`);
    lines.push(`      All wallets are treated equally — no single wallet is the "primary".`);
    lines.push(`      The report now shows complete hop-by-hop records wherever the transaction data exists in any loaded history.`);
    lines.push("");

    if (tieResult.commonNodes.length === 0) {
      lines.push(sep("RESULT — NO CONNECTION FOUND"));
      lines.push("");
      lines.push(`  NO VERIFIABLE PRIVATE-WALLET CONNECTION found within ${tieResult.maxHops} hops.`);
      lines.push(`  Wallet A and Wallet B share no common private-wallet counterparty`);
      lines.push(`  within the search depth. Exchange/bridge/protocol addresses are`);
      lines.push(`  excluded. Consider increasing Max Hops or loading more TX history.`);
      lines.push("");
    } else {
      lines.push(sep("RESULT — VERIFIED CONNECTION CONFIRMED"));
      lines.push("");
      lines.push(`  ✔ CONNECTION CONFIRMED — ${tieResult.commonNodes.length} common node(s) found.`);
      lines.push(`  Both wallets transact through the same intermediate address(es).`);
      lines.push("");

      tieResult.commonNodes.forEach((node, ni) => {
        const kn = KNOWN_LABELS[node.address];
        lines.push(sep(`COMMON NODE ${ni + 1} of ${tieResult!.commonNodes.length}`));
        lines.push("");
        lines.push(`  Address  : ${node.address}${kn ? `  [${kn.label.toUpperCase()}]` : "  [PRIVATE WALLET]"}`);
        lines.push(`  Wallet A reaches this node in ${node.pathFromA.length - 1} hop(s)`);
        lines.push(`  Wallet B reaches this node in ${node.pathFromB.length - 1} hop(s)`);
        lines.push("");

        const renderPath = (path: TieFinderHop[], label: string) => {
          lines.push(`  ── ${label} → Common Node:`);
          lines.push("");
          path.forEach((hop, idx) => {
            const hKn  = KNOWN_LABELS[hop.address];
            const hLbl = hKn ? `  [${hKn.label}]` : "";
            if (idx === 0) {
              lines.push(`  ${hop.address}${hLbl}  ← ${label}`);
            } else {
              lines.push(`  ↓  Hop ${idx}`);
              lines.push(`  ${hop.address}${hLbl}${idx === path.length - 1 ? "  ← COMMON NODE" : ""}`);
              if (hop.tx) emitTx(hop.tx, "  ").forEach(l => lines.push(l));
            }
          });
          lines.push("");
        };

        renderPath(node.pathFromA, "WALLET A");
        renderPath(node.pathFromB, "WALLET B");
      });
    }

    return auditAndSign(lines, {
      reportType: "Connection Finder Report",
      chain: chainUp,
      target: tieResult.walletA,
      comparisons: [tieResult.walletB],
      depth: `${tieResult.maxHops} hops`,
      nodesScanned: tieResult.nodesScannedA + tieResult.nodesScannedB,
    });
  }

  // ── Run Victim → Thief Path Trace ─────────────────────────────────────────
  async function runPathTrace() {
    const steps = pathSteps
      .map(s => ({ wallet: s.wallet.trim(), txHash: s.txHash.trim() }))
      .filter(s => s.wallet);
    if (steps.length < 2) {
      setPathError("Enter at least a victim wallet and a thief wallet.");
      return;
    }
    setPathLoading(true);
    setPathError(null);
    setPathProgress("Starting path analysis…");

    try {
      const hopData: Array<{ from: string; to: string; knownHash: string; tx: Tx | null; allTxs: Tx[] }> = [];

      for (let i = 0; i < steps.length - 1; i++) {
        const fromAddr  = steps[i].wallet;
        const toAddr    = steps[i + 1].wallet;
        const knownHash = steps[i].txHash; // TX hash on the FROM side of this hop
        setPathProgress(`Fetching hop ${i + 1}/${steps.length - 1}…`);

        // Search allTxs (loaded history on current wallet) for matching TXs
        const inLoaded = allTxs.filter(t => {
          const self = t.direction === "in" ? t.to  : t.from;
          const cp   = t.direction === "in" ? t.from : t.to;
          return (self === fromAddr && cp === toAddr) || (self === toAddr && cp === fromAddr);
        });

        let txPool: Tx[] = inLoaded;

        // Also fetch directly from the from-wallet if we don't already have enough
        if (txPool.length === 0 || knownHash) {
          try {
            const resp = await fetch(
              `/api/wallets/${encodeURIComponent(fromAddr)}/transactions?chain=${chain}&limit=50`
            );
            if (resp.ok) {
              const data = await resp.json() as { transactions?: Tx[] };
              const fetched = (data.transactions ?? []).filter(t => {
                const cp = t.direction === "in" ? t.from : t.to;
                return cp === toAddr;
              });
              // Merge: deduplicate by hash
              const seen = new Set(txPool.map(t => t.hash).filter(Boolean));
              txPool = [...txPool, ...fetched.filter(t => !seen.has(t.hash))];
            }
          } catch { /* best-effort */ }
        }

        // Find the primary TX — prefer the user-specified hash; fall back to largest-value match
        let primaryTx: Tx | null = null;
        if (knownHash) {
          primaryTx = txPool.find(t => t.hash === knownHash) ?? null;
          // If not found by hash in the filtered pool, search all of allTxs by hash directly
          if (!primaryTx) {
            primaryTx = allTxs.find(t => t.hash === knownHash) ?? null;
          }
        }
        if (!primaryTx && txPool.length > 0) {
          primaryTx = txPool.reduce((best, t) =>
            parseFloat(t.value) > parseFloat(best.value) ? t : best
          );
        }

        hopData.push({ from: fromAddr, to: toAddr, knownHash, tx: primaryTx, allTxs: txPool });
      }

      // ── Expand from final wallet ─────────────────────────────────────────
      setPathProgress("Fetching final-wallet expansion…");
      const lastAddr = steps[steps.length - 1].wallet;
      let expandTxs: Tx[] = [];
      try {
        // Check allTxs first (already filtered and clean)
        const inLoadedExpand = allTxs.filter(t => {
          const self = t.direction === "in" ? t.to : t.from;
          return self === lastAddr;
        });
        if (inLoadedExpand.length > 0) {
          expandTxs = inLoadedExpand.slice(0, 20);
        } else {
          const resp = await fetch(
            `/api/wallets/${encodeURIComponent(lastAddr)}/transactions?chain=${chain}&limit=25`
          );
          if (resp.ok) {
            const data = await resp.json() as { transactions?: Tx[] };
            expandTxs = (data.transactions ?? []).slice(0, 20);
          }
        }
      } catch { /* best-effort */ }

      setPathProgress("Generating report…");
      const rpt   = generatePathTraceReport(steps, hopData, expandTxs);
      const title = `Victim → Thief Path Trace — ${chain.toUpperCase()} — ${steps[0].wallet.slice(0, 12)}`;
      setReportContent(rpt);
      setReportTitle(title);
      setReportJsonData({
        reportType:    "path-trace",
        generatedAt:   new Date().toISOString(),
        chain,
        victimAddress: steps[0].wallet,
        thiefAddress:  steps[1].wallet,
        pathSteps:     steps,
        hops:          hopData.map(h => ({ from: h.from, to: h.to, knownHash: h.knownHash, txFound: !!h.tx })),
        reportText:    rpt,
      });
      setShowReportModal(true);
    } catch (err) {
      setPathError(err instanceof Error ? err.message : "Analysis failed — try again");
    } finally {
      setPathLoading(false);
      setPathProgress("");
    }
  }

  // Commit new pagination data: sort newest-first, mutate the ref, trigger re-render.
  function commit(txs: Tx[], cursor: string | null, more: boolean) {
    // Apply XLM allowlist at the earliest possible point — before allTxs is ever set.
    // Every downstream consumer (ledger, commingle, trail, exchange flows, etc.) receives
    // only the 8 allowed assets at or above their per-asset minimum amounts.
    const clean = chain === "xlm" ? txs.filter(xlmPassesFilter) : txs;
    const sorted = [...clean].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    page.current.txs = sorted;
    page.current.cursor = cursor;
    page.current.hasMore = more;
    setAllTxs(sorted); // single state update → one React re-render
  }

  // ── Saved wallets (localStorage) ──
  // ── Multi-wallet commingling analysis (declared early so setMultiWallets is in scope for toggleSavedWallet) ──
  const [showMultiPanel, setShowMultiPanel] = useState(false);
  const [multiWallets, setMultiWallets] = useState<string[]>([]);
  const [multiWalletInput, setMultiWalletInput] = useState("");
  const [multiResult, setMultiResult] = useState<MultiAnalysisResult | null>(null);
  const [multiLoading, setMultiLoading] = useState(false);
  const [multiProgress, setMultiProgress] = useState("");
  const [multiError, setMultiError] = useState<string | null>(null);
  const [multiNotice, setMultiNotice] = useState<string | null>(null);
  const [multiExchLoading, setMultiExchLoading] = useState(false);
  const [multiIntersectLoading, setMultiIntersectLoading] = useState(false);

  // ── Commingle Check ──
  const [showComminglePanel, setShowComminglePanel] = useState(false);
  const [commingleWallets, setCommingleWallets] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem("chaintrace-commingle-wallets");
      const all: string[] = raw ? JSON.parse(raw) : [];
      return all.filter((w) => w !== address);
    } catch { return []; }
  });
  const [commingleWalletInput, setCommingleWalletInput] = useState("");
  const [commingleLoading, setCommingleLoading] = useState(false);
  const [commingleProgress, setCommingleProgress] = useState("");
  const [commingleResult, setCommingleResult] = useState<CommingleCheckResult | null>(null);
  const [commingleError, setCommingleError] = useState<string | null>(null);
  const [commingleReportCopied, setCommingleReportCopied] = useState(false);
  const [commingleToast, setCommingleToast] = useState<string | null>(null);
  const [commingleMinAmount, setCommingleMinAmount] = useState(1.0);
  const [commingleMinAmountInput, setCommingleMinAmountInput] = useState("1");
  // ── Full Package ──────────────────────────────────────────────────────────────
  const commingleResultRef = useRef<CommingleCheckResult | null>(null);
  const multiResultRef = useRef<MultiAnalysisResult | null>(null);
  const [fullPkgLoading, setFullPkgLoading] = useState(false);
  const [fullPkgProgress, setFullPkgProgress] = useState("");
  const [victimWallet, setVictimWallet] = useState("rh64D3AcJkFRgyZe5XYFp4jEVLn43NCqaH");
  const [victimName, setVictimName] = useState("Ball Deep Crypto");
  const comminglePanelRef = useRef<HTMLDivElement>(null);
  const pathPanelRef      = useRef<HTMLDivElement>(null);

  // ── Victim → Thief Path Trace ─────────────────────────────────────────────
  const [showPathPanel,   setShowPathPanel]   = useState(false);
  const [pathSteps,       setPathSteps]       = useState<Array<{wallet:string; txHash:string}>>([{wallet:"",txHash:""},{wallet:"",txHash:""}]);
  const [pathLoading,     setPathLoading]     = useState(false);
  const [pathProgress,    setPathProgress]    = useState("");
  const [pathError,       setPathError]       = useState<string | null>(null);

  const addToCommingle = useCallback((addr: string) => {
    if (!addr) return;
    setCommingleWallets((prev) => {
      if (prev.includes(addr)) return prev;
      const next = [...prev, addr];
      try { localStorage.setItem("chaintrace-commingle-wallets", JSON.stringify(next)); } catch { /* noop */ }
      return next;
    });
    setCommingleToast("Added to Commingle Check");
    setTimeout(() => setCommingleToast(null), 2500);
  }, []);

  const [savedWallets, setSavedWallets] = useState<Set<string>>(() => {
    try {
      const raw = localStorage.getItem("chaintrace-saved-wallets");
      return raw ? new Set<string>(JSON.parse(raw) as string[]) : new Set<string>();
    } catch { return new Set<string>(); }
  });

  const toggleSavedWallet = useCallback((addr: string) => {
    setSavedWallets((prev) => {
      const next = new Set(prev);
      if (next.has(addr)) next.delete(addr);
      else next.add(addr);
      try { localStorage.setItem("chaintrace-saved-wallets", JSON.stringify([...next])); } catch { /* noop */ }
      return next;
    });
  }, []);

  // TRACKED: adds counterparty to Multi-Wallet Analysis pool only (not to watchlist/selectedWallets)
  const toggleTracked = useCallback((addr: string) => {
    setMultiWallets((prev) => {
      const removing = prev.includes(addr);
      if (!removing) setShowMultiPanel(true);
      return removing ? prev.filter(a => a !== addr) : [...prev, addr];
    });
  }, []);

  // ── Counterparty context menu ──
  const [activeMenu, setActiveMenu] = useState<{ addr: string; x: number; y: number } | null>(null);

  // ── Trail trace ──
  const [showTrailPanel, setShowTrailPanel] = useState(false);
  const [trailEntries, setTrailEntries] = useState<TrailEntry[]>([]);
  const [showNodeTree, setShowNodeTree] = useState(true);
  const fetchingRef = useRef(new Set<string>());
  const trailPanelRef = useRef<HTMLDivElement>(null);
  const multiPanelRef = useRef<HTMLDivElement>(null);

  // ── Origin Trace (TRACE TO ORIGIN) ──
  const [showOriginPanel, setShowOriginPanel] = useState(false);
  const [originHops, setOriginHops] = useState<OriginHop[]>([]);
  const [originLoading, setOriginLoading] = useState(false);
  const [originMode, setOriginMode] = useState<"standard" | "deep">("standard");
  const [originStatus, setOriginStatus] = useState("");
  const originPanelRef = useRef<HTMLDivElement>(null);
  const originAbortRef = useRef<boolean>(false);

  // ── Connection Finder ──
  const [showTiePanel, setShowTiePanel] = useState(false);
  const [tieBWallet, setTieBWallet] = useState("");
  const [tieMaxHops, setTieMaxHops] = useState(6);
  const [tieLoading, setTieLoading] = useState(false);
  const [tieProgress, setTieProgress] = useState("");
  const [tieResult, setTieResult] = useState<TieFinderResult | null>(null);
  const [tieError, setTieError] = useState<string | null>(null);
  const tiePanelRef = useRef<HTMLDivElement>(null);

  // (multi-wallet state moved above toggleSavedWallet — see above)

  // ── Blocks React Query background-refetches from overwriting accumulated txs ──
  const txInitializedRef = useRef(false);

  // Initial batch size — derived from chain only, stable per session
  const initLimit = chain === "dag" ? DAG_BATCH : chain === "xrp" ? XRP_INIT : OTHER_BATCH;

  // Close menu on outside click
  useEffect(() => {
    const handler = () => setActiveMenu(null);
    window.addEventListener("click", handler);
    return () => window.removeEventListener("click", handler);
  }, []);

  // ── Reset everything when the wallet address, chain, or initLimit changes ──
  useEffect(() => {
    txInitializedRef.current = false;
    page.current = { txs: [], cursor: null, hasMore: false, busy: false, error: null, status: null };
    setAllTxs([]);
    setMinAmount(1);
    setMinAmountInput("1");
    if (address && chain) saveRecentSearch(address, chain);
  }, [address, chain, initLimit]); // eslint-disable-line react-hooks/exhaustive-deps

  const { data: wallet, isLoading: walletLoading, error: walletError } = useGetWallet(
    txAddress, { chain },
    {
      query: {
        enabled: !!txAddress,
        queryKey: getGetWalletQueryKey(txAddress, { chain }),
        staleTime: chain === "xdc" ? 0 : Infinity,
        refetchOnWindowFocus: false,
        refetchOnMount: chain === "xdc" ? true : false,
        refetchOnReconnect: false,
      },
    }
  );

  // Initial page — staleTime: Infinity + refetchOnWindowFocus: false prevent background
  // refetches from racing with accumulated Load More state.
  // XLM exception: use staleTime:0 + refetchOnMount:true so a stale empty result (from a
  // previously merged/closed account fetch) is never served permanently — a fresh fetch
  // always runs on navigation. The txInitializedRef guard below prevents accumulated
  // Load More pages from being overwritten by a background re-fetch.
  const xlmChain = chain === "xlm";
  const xdcChain = chain === "xdc";
  const { data: transactionsData, isLoading: txLoading } = useGetWalletTransactions(
    txAddress, { chain, page: 1, limit: initLimit },
    {
      query: {
        enabled: !!txAddress,
        queryKey: getGetWalletTransactionsQueryKey(txAddress, { chain, page: 1, limit: initLimit }),
        // XDC: always fetch fresh — xdc-prefix vs 0x-prefix addresses may have
        // been cached as empty results; force refetch every time to avoid stale empties.
        // XLM: same reason (merged/closed accounts).  All others: Infinity (stable).
        staleTime: (xlmChain || xdcChain) ? 0 : Infinity,
        refetchOnWindowFocus: false,
        refetchOnMount: (xlmChain || xdcChain) ? true : false,
        refetchOnReconnect: false,
      },
    }
  );
  // Message + explorer link returned by the server when Horizon has no history for this XLM address
  const xlmMessage     = transactionsData?.message     ?? null;
  const xlmHistoryLink = transactionsData?.historyLink ?? null;
  // Archive gap warning — shown as a non-intrusive banner above the ledger even when some
  // transactions were found, to alert the user that older history exists on stellar.expert.
  const xlmArchiveWarning = (chain === "xlm" ? transactionsData?.archiveWarning : null) ?? null;
  const xlmArchiveLink    = (chain === "xlm" ? transactionsData?.archiveLink    : null) ?? null;

  // ── Sync initial React Query page into local state (once per wallet/chain) ──
  // txInitializedRef blocks subsequent RQ background-refetches from overwriting
  // transactions already accumulated by Load More clicks.
  useEffect(() => {
    if (!transactionsData?.transactions || txInitializedRef.current) return;
    txInitializedRef.current = true;
    commit(
      transactionsData.transactions as Tx[],
      transactionsData.nextCursor ?? null,
      transactionsData.hasMore ?? false,
    );
  }, [transactionsData]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Fetch one page from the backend (max 2 attempts) ──
  async function fetchPage(cursor: string, limit: number): Promise<{ transactions: Tx[]; nextCursor: string | null; hasMore: boolean }> {
    const url = `/api/wallets/${encodeURIComponent(txAddress)}/transactions?chain=${chain}&limit=${limit}&cursor=${encodeURIComponent(cursor)}`;
    let lastErr: Error | null = null;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const res = await fetch(url);
        if (!res.ok) {
          const body = await res.text().catch(() => "");
          lastErr = new Error(`HTTP ${res.status}${body ? `: ${body.slice(0, 100)}` : ""}`);
          if (attempt < 2) { await new Promise(r => setTimeout(r, 800)); continue; }
          throw lastErr;
        }
        return res.json() as Promise<{ transactions: Tx[]; nextCursor: string | null; hasMore: boolean }>;
      } catch (err) {
        lastErr = err instanceof Error ? err : new Error(String(err));
        if (attempt < 2) { await new Promise(r => setTimeout(r, 800)); }
      }
    }
    console.error(`[fetchPage] Failed after 2 attempts for ${txAddress} (${chain}):`, lastErr?.message);
    throw lastErr!;
  }

  const loadMoreLabel = chain === "dag" ? "LOAD MORE (+250)" : chain === "xrp" ? "LOAD MORE (+500)" : "LOAD MORE (+1000)";

  // ── Load More: fetch one batch, append, re-render ──
  // page.current is always current — no stale closure possible.
  async function loadMore() {
    if (page.current.busy || !page.current.hasMore || !page.current.cursor) return;

    // Snapshot cursor + existing list at call time
    const cursor = page.current.cursor;
    const existing = page.current.txs;

    page.current.busy = true;
    page.current.error = null;
    page.current.status = null;
    setAllTxs([...existing]); // force re-render so button goes to LOADING state

    const limit = chain === "dag" ? DAG_BATCH : chain === "xrp" ? XRP_BATCH : OTHER_BATCH;
    try {
      const data = await fetchPage(cursor, limit);
      const seen = new Set(existing.map((t) => t.hash || `${t.from}:${t.to}:${t.timestamp}`));
      const newTxs = (data.transactions ?? []).filter(
        (t) => !seen.has(t.hash || `${t.from}:${t.to}:${t.timestamp}`)
      );
      const merged = [...existing, ...newTxs]; // append — never replace
      page.current.status = `Added ${newTxs.length} transactions · Total: ${merged.length.toLocaleString()}`;
      commit(merged, data.nextCursor ?? null, data.hasMore && merged.length < MAX_TOTAL);
    } catch (err) {
      page.current.error = err instanceof Error ? err.message : "Unknown error — try again";
      setAllTxs([...existing]); // re-render to show error
    } finally {
      page.current.busy = false;
      setAllTxs([...page.current.txs]); // ensure final re-render with busy=false
    }
  }

  // ── Load All: loop one batch at a time, commit after each page ──
  async function loadAll() {
    if (page.current.busy || !page.current.hasMore || !page.current.cursor) return;
    if (page.current.txs.length > 20000) {
      if (!window.confirm(
        `You already have ${page.current.txs.length.toLocaleString()} transactions.\nLoading more may slow your browser.\n\nContinue?`
      )) return;
    }

    page.current.busy = true;
    page.current.error = null;

    const limit = chain === "dag" ? DAG_BATCH : chain === "xrp" ? XRP_BATCH : OTHER_BATCH;
    let cursor: string | null = page.current.cursor;
    let accumulated = [...page.current.txs];
    let pageNum = 0;

    try {
      while (cursor && accumulated.length < MAX_TOTAL) {
        pageNum++;
        page.current.status = `Loading page ${pageNum} · ${accumulated.length.toLocaleString()} loaded so far…`;
        const liveClean = chain === "xlm" ? accumulated.filter(xlmPassesFilter) : accumulated;
        setAllTxs([...liveClean].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())); // live sorted update

        const data = await fetchPage(cursor, limit);
        const seen = new Set(accumulated.map((t) => t.hash || `${t.from}:${t.to}:${t.timestamp}`));
        const newTxs = (data.transactions ?? []).filter(
          (t) => !seen.has(t.hash || `${t.from}:${t.to}:${t.timestamp}`)
        );
        accumulated = [...accumulated, ...newTxs];
        cursor = data.nextCursor ?? null;
        commit([...accumulated], cursor, data.hasMore && accumulated.length < MAX_TOTAL);
        if (!data.hasMore || !cursor) break;
      }
      page.current.status = `Full history loaded · ${accumulated.length.toLocaleString()} total`;
    } catch (err) {
      page.current.error = err instanceof Error ? err.message : "Unknown error — try again";
    } finally {
      page.current.busy = false;
      setAllTxs([...page.current.txs]);
    }
  }

  // ── Apply minimum amount filter + view mode sort ──
  const filteredTxs = useMemo(() => {
    const base = chain === "xlm"
      ? allTxs.filter(xlmPassesFilter)
      : minAmount <= 0 ? allTxs : allTxs.filter((tx) => parseFloat(tx.value) >= minAmount);
    if (viewMode === "mixed") return base; // already newest-first from commit()
    // Partition into IN, OUT, self — each sub-list is already newest-first (stable after partition)
    const ins = base.filter((t) => t.direction === "in");
    const outs = base.filter((t) => t.direction === "out");
    const self = base.filter((t) => t.direction === "self");
    if (viewMode === "in-first") return [...ins, ...outs, ...self];
    return [...outs, ...ins, ...self]; // out-first
  }, [allTxs, minAmount, viewMode]);

  // ── Group by (address + direction) ──
  const groupedRows = useMemo((): GroupedRow[] => {
    const map = new Map<string, GroupedRow>();
    for (const tx of allTxs) {
      if (tx.direction === "self") continue;
      const cp = tx.direction === "in" ? tx.from : tx.to;
      if (!cp) continue;
      const val = parseFloat(tx.value) || 0;
      if (chain === "xlm" ? !xlmPassesFilter(tx) : val < minAmount) continue;
      const key = `${cp}:${tx.direction}`;
      const existing = map.get(key);
      if (existing) {
        existing.txCount++;
        existing.totalValue += val;
        if (tx.timestamp && tx.timestamp > existing.latestTs) existing.latestTs = tx.timestamp;
      } else {
        map.set(key, {
          address: cp,
          direction: tx.direction as "in" | "out",
          totalValue: val,
          txCount: 1,
          latestTs: tx.timestamp || "",
          asset: tx.tokenSymbol || chain.toUpperCase(),
        });
      }
    }
    const allRows = Array.from(map.values());
    const rows = dirFilter === "only-in"
      ? allRows.filter((r) => r.direction === "in")
      : dirFilter === "only-out"
        ? allRows.filter((r) => r.direction === "out")
        : allRows;
    // Direction grouping (viewMode) as primary, groupSort as secondary within each group
    rows.sort((a, b) => {
      if (viewMode !== "mixed" && a.direction !== b.direction) {
        if (viewMode === "in-first") return a.direction === "in" ? -1 : 1;
        if (viewMode === "out-first") return a.direction === "out" ? -1 : 1;
      }
      if (groupSort === "exchange-first") {
        const aKnown = KNOWN_LABELS[a.address];
        const bKnown = KNOWN_LABELS[b.address];
        const aIsExchange = aKnown?.type === "exchange" ? 0 : aKnown ? 1 : 2;
        const bIsExchange = bKnown?.type === "exchange" ? 0 : bKnown ? 1 : 2;
        if (aIsExchange !== bIsExchange) return aIsExchange - bIsExchange;
        return b.txCount - a.txCount;
      }
      if (groupSort === "most-txs")      return b.txCount - a.txCount;
      if (groupSort === "highest-value") return b.totalValue - a.totalValue;
      return new Date(b.latestTs).getTime() - new Date(a.latestTs).getTime();
    });
    return rows;
  }, [allTxs, minAmount, viewMode, groupSort, chain, dirFilter]);

  // ── Commingling detection ──
  const comminglingAddresses = useMemo(() => {
    const parentSets = new Map<string, Set<string>>();
    for (const e of trailEntries) {
      if (!e.parentAddress) continue;
      if (!parentSets.has(e.address)) parentSets.set(e.address, new Set());
      parentSets.get(e.address)!.add(e.parentAddress);
    }
    return new Set(
      Array.from(parentSets.entries())
        .filter(([, parents]) => parents.size > 1)
        .map(([addr]) => addr)
    );
  }, [trailEntries]);

  // ── Intersection / Commingling Analysis ──
  // Computes all 3 sections purely from data already in memory — no extra API calls.
  const intersectionData = useMemo(() => {
    if (!showTrailPanel || trailEntries.length === 0) return null;
    const rootAddr = trailEntries[0].address;

    // Build per-counterparty stats from loaded transactions
    const cpMap = new Map<string, {
      txCount: number; totalValue: number;
      firstTs: string; lastTs: string;
      sampleHash: string; sampleDate: string;
    }>();
    for (const tx of allTxs) {
      const cp = tx.direction === "in" ? tx.from : (tx.to ?? null);
      if (!cp || cp === rootAddr) continue;
      const v = parseFloat(tx.value) || 0;
      const ex = cpMap.get(cp);
      if (ex) {
        ex.txCount++;
        ex.totalValue += v;
        if (tx.timestamp && tx.timestamp < ex.firstTs) ex.firstTs = tx.timestamp;
        if (tx.timestamp && tx.timestamp > ex.lastTs) {
          ex.lastTs = tx.timestamp;
          ex.sampleHash = tx.hash || ex.sampleHash;
          ex.sampleDate = tx.timestamp;
        }
      } else {
        cpMap.set(cp, {
          txCount: 1, totalValue: v,
          firstTs: tx.timestamp || "", lastTs: tx.timestamp || "",
          sampleHash: tx.hash || "", sampleDate: tx.timestamp || "",
        });
      }
    }

    // § 1 — Direct Intersections: trail nodes whose address also appears in allTxs
    const trailNodes = trailEntries.filter((e) => e.depth > 0);
    const directIntersections = trailNodes
      .filter((e) => cpMap.has(e.address))
      .map((e) => ({ ...e, cp: cpMap.get(e.address)! }))
      .sort((a, b) => b.cp.totalValue - a.cp.totalValue);
    const intersectionAddrs = new Set(directIntersections.map((d) => d.address));

    // § 2 — Common Endpoints: nodes reached via 2+ different parents
    const parentSets = new Map<string, Set<string>>();
    for (const e of trailEntries) {
      if (!e.parentAddress) continue;
      if (!parentSets.has(e.address)) parentSets.set(e.address, new Set());
      parentSets.get(e.address)!.add(e.parentAddress);
    }
    const commonEndpoints = Array.from(parentSets.entries())
      .filter(([, parents]) => parents.size > 1)
      .map(([addr, parents]) => ({
        address: addr,
        parents: Array.from(parents),
        trailEntry: trailEntries.find((e) => e.address === addr),
        cpData: cpMap.get(addr),
      }));

    // § 3 — Numbered Trail Paths: DFS root→leaf, prefer paths with intersections
    const allPaths: string[][] = [];
    const dfs = (addr: string, path: string[]) => {
      const children = trailEntries.filter((e) => e.parentAddress === addr);
      if (children.length === 0) { allPaths.push([...path]); return; }
      for (const c of children) dfs(c.address, [...path, c.address]);
    };
    dfs(rootAddr, [rootAddr]);
    allPaths.sort((a, b) => {
      const score = (p: string[]) =>
        p.filter((addr) => intersectionAddrs.has(addr)).length * 2 +
        p.filter((addr) => commonEndpoints.some((c) => c.address === addr)).length;
      return score(b) - score(a);
    });

    return {
      directIntersections, commonEndpoints,
      paths: allPaths.slice(0, 12),
      intersectionAddrs, rootAddr,
      totalTxsLoaded: allTxs.length,
    };
  }, [showTrailPanel, trailEntries, allTxs]);

  // ── Trail trace ──
  const expandTrailNode = useCallback(async (entry: TrailEntry) => {
    if (fetchingRef.current.has(entry.address) || entry.depth >= 6) return;
    fetchingRef.current.add(entry.address);
    setTrailEntries((prev) =>
      prev.map((e) => e.address === entry.address ? { ...e, isLoading: true } : e)
    );
    try {
      const resp = await fetch(`/api/wallets/${encodeURIComponent(entry.address)}/connections?chain=${chain}`);
      if (!resp.ok) throw new Error("fetch failed");
      const data = await resp.json() as {
        nodes: Array<{ address: string; riskScore: number | null }>;
        edges: Array<{ from: string; to: string; totalValueUsd: number; transactionCount: number }>;
        centerAddress: string;
      };
      const peers = (data.nodes || []).filter((n) => n.address !== entry.address).slice(0, 12);
      const edges = data.edges || [];
      setTrailEntries((prev) => {
        const existingAddrs = new Set(prev.map((e) => e.address));
        const updated = prev.map((e) =>
          e.address === entry.address
            ? { ...e, isLoading: false, isExpanded: true, childAddresses: peers.map((p) => p.address) }
            : e
        );
        const newEntries: TrailEntry[] = [];
        for (const peer of peers) {
          if (!existingAddrs.has(peer.address)) {
            const edge = edges.find(
              (ed) =>
                (ed.from === entry.address && ed.to === peer.address) ||
                (ed.to === entry.address && ed.from === peer.address)
            );
            newEntries.push({
              address: peer.address, depth: entry.depth + 1, parentAddress: entry.address,
              knownInfo: KNOWN_LABELS[peer.address],
              isExpanded: false, isLoading: false,
              totalValueUsd: edge?.totalValueUsd ?? 0, txCount: edge?.transactionCount ?? 0,
              childAddresses: [],
            });
          }
        }
        return [...updated, ...newEntries];
      });
    } catch {
      setTrailEntries((prev) =>
        prev.map((e) => e.address === entry.address ? { ...e, isLoading: false, error: true } : e)
      );
    } finally {
      fetchingRef.current.delete(entry.address);
    }
  }, [chain]);

  const startTrailTrace = useCallback(async (targetAddr: string) => {
    setShowTrailPanel(true);
    fetchingRef.current.clear();
    const rootEntry: TrailEntry = {
      address: targetAddr, depth: 0, parentAddress: null,
      knownInfo: KNOWN_LABELS[targetAddr],
      isExpanded: false, isLoading: true,
      totalValueUsd: 0, txCount: 0, childAddresses: [],
    };
    setTrailEntries([rootEntry]);
    try {
      const resp = await fetch(`/api/wallets/${encodeURIComponent(targetAddr)}/connections?chain=${chain}`);
      if (!resp.ok) throw new Error("fetch failed");
      const data = await resp.json() as {
        nodes: Array<{ address: string; riskScore: number | null }>;
        edges: Array<{ from: string; to: string; totalValueUsd: number; transactionCount: number }>;
        centerAddress: string;
      };
      const peers = (data.nodes || []).filter((n) => n.address !== targetAddr).slice(0, 12);
      const edges = data.edges || [];
      const rootExpanded: TrailEntry = {
        ...rootEntry, isLoading: false, isExpanded: true,
        childAddresses: peers.map((p) => p.address),
      };
      const peerEntries: TrailEntry[] = peers.map((peer) => {
        const edge = edges.find(
          (ed) =>
            (ed.from === targetAddr && ed.to === peer.address) ||
            (ed.to === targetAddr && ed.from === peer.address)
        );
        return {
          address: peer.address, depth: 1, parentAddress: targetAddr,
          knownInfo: KNOWN_LABELS[peer.address],
          isExpanded: false, isLoading: false,
          totalValueUsd: edge?.totalValueUsd ?? 0, txCount: edge?.transactionCount ?? 0,
          childAddresses: [],
        };
      });
      setTrailEntries([rootExpanded, ...peerEntries]);
    } catch {
      setTrailEntries([{ ...rootEntry, isLoading: false, error: true }]);
    }
    setTimeout(() => {
      trailPanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 300);
  }, [chain]);

  const continueTrailOnWallet = useCallback((addr: string) => {
    setActiveMenu(null);
    startTrailTrace(addr);
  }, [startTrailTrace]);

  // ── TRACE TO ORIGIN — reverse source tracing ──
  async function startOriginTrace() {
    originAbortRef.current = false;
    setOriginLoading(true);
    setOriginHops([]);
    setOriginStatus("Initializing…");
    setShowOriginPanel(true);

    const maxHops = originMode === "deep" ? 75 : 30;
    const chainUp = chain.toUpperCase();
    const visited = new Set<string>();
    const hops: OriginHop[] = [];

    // Hop 0: the target wallet itself
    hops.push({
      hop: 0, address, txHash: null, txAmount: "", txAsset: chainUp,
      txTimestamp: "", knownInfo: KNOWN_LABELS[address],
      stopReason: null, isLoading: false,
    });
    setOriginHops([...hops]);
    visited.add(address);

    try {
      for (let i = 0; i < maxHops; i++) {
        if (originAbortRef.current) break;

        const current = hops[hops.length - 1].address;
        setOriginStatus(`Hop ${i + 1}/${maxHops} — scanning ${current.slice(0, 12)}…`);

        // Show loading state on last hop
        hops[hops.length - 1] = { ...hops[hops.length - 1], isLoading: true };
        setOriginHops([...hops]);

        // Fetch transactions for current wallet
        let incoming: Tx[] = [];
        try {
          const url = `/api/wallets/${encodeURIComponent(current)}/transactions?chain=${chain}&limit=50`;
          const resp = await fetch(url);
          if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
          const data = await resp.json() as { transactions: Tx[] };
          incoming = (data.transactions ?? []).filter(
            (t) => t.direction === "in" && t.from && parseFloat(t.value) > 0
          );
        } catch (err) {
          hops[hops.length - 1] = {
            ...hops[hops.length - 1],
            isLoading: false,
            error: err instanceof Error ? err.message : "Fetch failed",
          };
          setOriginHops([...hops]);
          break;
        }

        // Clear loading state on current hop
        hops[hops.length - 1] = { ...hops[hops.length - 1], isLoading: false };

        if (incoming.length === 0) {
          // Dead end — mark the current last hop
          hops[hops.length - 1] = { ...hops[hops.length - 1], stopReason: "dead-end" };
          setOriginHops([...hops]);
          break;
        }

        // Pick best sender: highest value incoming tx
        incoming.sort((a, b) => parseFloat(b.value) - parseFloat(a.value));
        const bestTx = incoming[0];
        const sender = bestTx.from;
        const knownSender = KNOWN_LABELS[sender];

        const isExchange = knownSender?.type === "exchange" || knownSender?.type === "bridge";
        const isLoop     = visited.has(sender);
        const isMaxHops  = i === maxHops - 1;

        const stopReason: OriginHop["stopReason"] =
          isExchange ? "exchange" :
          isLoop     ? "loop" :
          isMaxHops  ? "max-hops" :
          null;

        hops.push({
          hop: i + 1, address: sender,
          txHash: bestTx.hash, txAmount: bestTx.value,
          txAsset: bestTx.tokenSymbol || chainUp,
          txTimestamp: bestTx.timestamp,
          txMemo: bestTx.memo, txDestinationTag: bestTx.destinationTag,
          knownInfo: knownSender, stopReason, isLoading: false,
        });
        setOriginHops([...hops]);

        if (stopReason) break;

        visited.add(sender);
      }
    } finally {
      setOriginLoading(false);
      setOriginStatus("");
      setTimeout(() => originPanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 300);
    }
  }

  // ── Connection Finder — bidirectional BFS ─────────────────────────────────
  const runTieFinder = useCallback(async () => {
    const wA = address.trim();
    const wB = tieBWallet.trim();
    if (!wB) { setTieError("Enter Wallet B address."); return; }
    if (wA === wB) { setTieError("Wallet A and B cannot be the same address."); return; }
    setTieLoading(true);
    setTieError(null);
    setTieResult(null);

    // Hard-excluded addresses: never added to reach map or accepted as common nodes.
    // DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz — noisy reward wallet
    // DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B — Official Bridge / Base Wallet (bridge leak)
    const HARD_EXCL = new Set([
      "DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz",
      "DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B",
    ]);

    const fetchTxs = async (addr: string): Promise<Tx[]> => {
      try {
        const resp = await fetch(`/api/wallets/${encodeURIComponent(addr)}/transactions?chain=${chain}&limit=50`);
        if (!resp.ok) return [];
        const data = await resp.json() as { transactions: Tx[] };
        return (data.transactions ?? []).filter(t => passesAnalysisFilter(t, chain));
      } catch { return []; }
    };

    const isPrivateWallet = (addr: string): boolean => {
      const info = KNOWN_LABELS[addr];
      if (!info) return true; // unknown = private
      const type = (info.type || "").toLowerCase();
      return !["exchange", "bridge", "hot", "custodial"].includes(type);
    };

    type TieReachEntry = { path: string[]; tier: number };
    type TieReachMap = Map<string, TieReachEntry>;

    // Build a full 6-tier reach map from a single root wallet — identical logic
    // to Commingle Check's buildReachMap so both tools find the same nodes.
    const buildReach = async (
      wallet: string,
      label: string,
    ): Promise<{ reach: TieReachMap; segTxs: Record<string, Tx> }> => {
      const reach: TieReachMap = new Map();
      const segTxs: Record<string, Tx> = {};

      // Tier 1: direct counterparties of the root wallet
      setTieProgress(`${label}: tier 1…`);
      const rootTxs = await fetchTxs(wallet);
      for (const tx of rootTxs) {
        if (!passesAnalysisFilter(tx, chain)) continue;
        const cp = tx.direction === "in" ? tx.from : tx.to;
        if (!cp || cp === wallet || HARD_EXCL.has(cp) || reach.has(cp)) continue;
        reach.set(cp, { path: [wallet, cp], tier: 1 });
        segTxs[`${wallet}::${cp}`] = tx;
      }

      // Tiers 2–6: expand from previous tier's private nodes
      const tierLimits = [6, 4, 3, 2, 2];
      for (let tier = 2; tier <= 6; tier++) {
        setTieProgress(`${label}: tier ${tier}…`);
        const prevNodes = Array.from(reach.entries())
          .filter(([addr, v]) => v.tier === tier - 1 && isPrivateWallet(addr))
          .slice(0, tierLimits[tier - 2]);
        if (prevNodes.length === 0) break;
        const txResults = await Promise.all(prevNodes.map(([a]) => fetchTxs(a)));
        for (let i = 0; i < prevNodes.length; i++) {
          const [parentAddr, parentData] = prevNodes[i];
          for (const tx of txResults[i]) {
            if (!passesAnalysisFilter(tx, chain)) continue;
            const cp = tx.direction === "in" ? tx.from : tx.to;
            if (!cp || cp === wallet || HARD_EXCL.has(cp) || reach.has(cp)) continue;
            reach.set(cp, { path: [...parentData.path, cp], tier });
            segTxs[`${parentAddr}::${cp}`] = tx;
          }
        }
      }

      return { reach, segTxs };
    };

    try {
      const { reach: reachA, segTxs: segTxsA } = await buildReach(wA, "Wallet A");
      const { reach: reachB, segTxs: segTxsB } = await buildReach(wB, "Wallet B");

      setTieProgress("Intersecting reach maps…");

      const commonNodes: TieFinderResult["commonNodes"] = [];

      // Bridge addresses are hard-excluded from hop rendering — same as Commingle Check.
      const BRIDGE_EXCL = new Set(["DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B"]);

      const toHops = (path: string[], segTxs: Record<string, Tx>): TieFinderHop[] => {
        const hops: TieFinderHop[] = [];
        for (let i = 0; i < path.length; i++) {
          const hopAddr = path[i];
          if (BRIDGE_EXCL.has(hopAddr)) continue;
          const tx = i === 0 ? null : (segTxs[`${path[i - 1]}::${hopAddr}`] ?? segTxs[`${hopAddr}::${path[i - 1]}`] ?? null);
          hops.push({ address: hopAddr, tx });
        }
        return hops;
      };

      // Pure set intersection — same as Commingle Check: no minDepth gate.
      for (const [addr, entryA] of reachA) {
        if (!reachB.has(addr)) continue;
        if (!isPrivateWallet(addr)) continue;
        const entryB = reachB.get(addr)!;
        commonNodes.push({
          address: addr,
          pathFromA: toHops(entryA.path, segTxsA),
          pathFromB: toHops(entryB.path, segTxsB),
        });
        if (commonNodes.length >= 5) break;
      }

      setTieResult({
        walletA: wA, walletB: wB,
        chain, maxHops: tieMaxHops,
        commonNodes,
        nodesScannedA: reachA.size + 1,
        nodesScannedB: reachB.size + 1,
      });
    } catch (err) {
      setTieError(err instanceof Error ? err.message : "Search failed");
    } finally {
      setTieLoading(false);
      setTieProgress("");
      setTimeout(() => tiePanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 300);
    }
  }, [address, tieBWallet, tieMaxHops, chain]);

  // ── Multi-wallet commingling analysis ──
  const runMultiAnalysis = useCallback(async (walletOverride?: string[]) => {
    const allWallets = (walletOverride ?? [address, ...multiWallets]).filter(Boolean);
    if (allWallets.length < 2) {
      setMultiError("Add at least one additional wallet address to compare.");
      return null;
    }
    setMultiLoading(true);
    setMultiError(null);
    setMultiResult(null);

    // Hard-excluded — identical to Connection Finder and Commingle Check.
    const HARD_EXCL = new Set([
      "DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz",
      "DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B",
    ]);

    const fetchTxs = async (addr: string): Promise<Tx[]> => {
      try {
        const resp = await fetch(`/api/wallets/${encodeURIComponent(addr)}/transactions?chain=${chain}&limit=50`);
        if (!resp.ok) return [];
        const data = await resp.json() as { transactions: Tx[] };
        return (data.transactions ?? []).filter(t => passesAnalysisFilter(t, chain));
      } catch { return []; }
    };

    const isPrivateWallet = (addr: string): boolean => {
      const info = KNOWN_LABELS[addr];
      if (!info) return true;
      const type = (info.type || "").toLowerCase();
      return !["exchange", "bridge", "hot", "custodial"].includes(type);
    };

    // Full 6-tier reach map — identical logic to Connection Finder and Commingle Check.
    const buildReach = async (
      wallet: string,
      label: string,
    ): Promise<Map<string, { path: string[]; tier: number }>> => {
      const reach = new Map<string, { path: string[]; tier: number }>();

      setMultiProgress(`${label}: tier 1…`);
      const rootTxs = await fetchTxs(wallet);
      for (const tx of rootTxs) {
        if (!passesAnalysisFilter(tx, chain)) continue;
        const cp = tx.direction === "in" ? tx.from : tx.to;
        if (!cp || cp === wallet || HARD_EXCL.has(cp) || reach.has(cp)) continue;
        reach.set(cp, { path: [wallet, cp], tier: 1 });
      }

      const tierLimits = [6, 4, 3, 2, 2];
      for (let tier = 2; tier <= 6; tier++) {
        setMultiProgress(`${label}: tier ${tier}…`);
        const prevNodes = Array.from(reach.entries())
          .filter(([addr, v]) => v.tier === tier - 1 && isPrivateWallet(addr))
          .slice(0, tierLimits[tier - 2]);
        if (prevNodes.length === 0) break;
        const txResults = await Promise.all(prevNodes.map(([a]) => fetchTxs(a)));
        for (let i = 0; i < prevNodes.length; i++) {
          const [, parentData] = prevNodes[i];
          for (const tx of txResults[i]) {
            if (!passesAnalysisFilter(tx, chain)) continue;
            const cp = tx.direction === "in" ? tx.from : tx.to;
            if (!cp || cp === wallet || HARD_EXCL.has(cp) || reach.has(cp)) continue;
            reach.set(cp, { path: [...parentData.path, cp], tier });
          }
        }
      }

      return reach;
    };

    try {
      // Build reach maps for every tracked wallet sequentially.
      const reachMaps: Array<{ wallet: string; reach: Map<string, { path: string[]; tier: number }> }> = [];
      for (let i = 0; i < allWallets.length; i++) {
        const wallet = allWallets[i];
        const label  = i === 0 ? "Primary" : `Wallet ${i + 1}`;
        reachMaps.push({ wallet, reach: await buildReach(wallet, label) });
      }

      // Aggregate: address → appearances across all wallets.
      const addressMap = new Map<string, MultiSharedEntry>();
      for (const { wallet, reach } of reachMaps) {
        for (const [addr, entry] of reach) {
          if (!addressMap.has(addr)) {
            addressMap.set(addr, {
              address: addr,
              knownInfo: KNOWN_LABELS[addr] as MultiSharedEntry["knownInfo"],
              appearances: [],
            });
          }
          addressMap.get(addr)!.appearances.push({
            wallet,
            depth: entry.tier,
            txCount: 1,
            totalValueUsd: 0,
            via: entry.path.length > 1 ? entry.path[entry.path.length - 2] : wallet,
            pathChain: entry.path,
          });
        }
      }

      // Keep only addresses seen by 2+ wallets that pass the private wallet filter.
      const shared = Array.from(addressMap.values())
        .filter(e => e.appearances.length >= 2 && isPrivateWallet(e.address));

      // Stable: most appearances first; address tie-breaker for all three lists
      const sharedCounterparties = shared
        .filter(s => s.appearances.some(a => a.depth === 1))
        .sort((a, b) => b.appearances.length - a.appearances.length || a.address.localeCompare(b.address));

      const commonEndpoints = shared
        .filter(s => s.appearances.every(a => a.depth >= 2))
        .sort((a, b) => b.appearances.length - a.appearances.length || a.address.localeCompare(b.address));

      const patterns = [...shared]
        .sort((a, b) => b.appearances.length - a.appearances.length || a.address.localeCompare(b.address))
        .slice(0, 20)
        .map((s, i) => ({
          id: i + 1,
          sharedAddr: s.address,
          knownInfo: s.knownInfo,
          totalTxCount: s.appearances.length,
          totalValueUsd: 0,
          paths: s.appearances.map(a => ({ wallet: a.wallet, path: a.pathChain })),
        }));

      const _mrRes: MultiAnalysisResult = { trackedWallets: allWallets, sharedCounterparties, commonEndpoints, patterns };
      multiResultRef.current = _mrRes;
      setMultiResult(_mrRes);
      if (!walletOverride) setTimeout(() => multiPanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 200);
      return _mrRes;
    } catch (err) {
      setMultiError(err instanceof Error ? err.message : "Analysis failed");
      return null;
    } finally {
      setMultiLoading(false);
      setMultiProgress("");
    }
  }, [address, multiWallets, chain]);

  // ── COMMINGLE CHECK — depth-1 through depth-6 BFS across target + comparison wallets ──
  const runCommingleCheck = useCallback(async (comparisonOverride?: string[]) => {
    const _compWallets = comparisonOverride ?? commingleWallets;
    if (_compWallets.length === 0) {
      setCommingleError("Add at least one comparison wallet address.");
      return null;
    }
    setCommingleLoading(true);
    setCommingleError(null);
    setCommingleResult(null);
    setCommingleProgress("");

    type ReachNode = { path: string[]; tier: number; txCount: number };
    type ReachMap = Map<string, ReachNode>;

    // Fetch individual transactions for a wallet — same approach as Connection Finder.
    // Using /transactions instead of /connections finds counterparties that have only a
    // few TXs (missed by the aggregated connections endpoint) and gives us TX objects
    // directly so no separate hop-fetch step is needed.
    const fetchTxs = async (addr: string): Promise<Tx[]> => {
      try {
        const resp = await fetch(`/api/wallets/${encodeURIComponent(addr)}/transactions?chain=${chain}&limit=50`);
        if (!resp.ok) return [];
        const data = await resp.json() as { transactions: Tx[] };
        return (data.transactions ?? []).filter(t => passesAnalysisFilter(t, chain));
      } catch { return []; }
    };

    // Segment TXs accumulated during BFS — keyed "parentAddr::childAddr".
    // Populated by buildReachMap; replaces the old separate hop-fetch phase.
    // Used by the report generator for hop-by-hop TX details and exchange flow detection.
    const segmentTxs: Record<string, Tx> = {};

    const buildReachMap = async (wallet: string, label: string): Promise<ReachMap> => {
      const reach: ReachMap = new Map();

      // Hard-excluded: never add to reach map, never expand from, never shown as shared node.
      // DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz — noisy reward wallet
      // DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B — Official Bridge / Base Wallet (bridge leak)
      const HARD_EXCL = new Set([
        "DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz",
        "DAG3pBTP4AKQQa6Vpbk59Np7MVa7ogToqujCKa1B",
      ]);

      // Private wallet filter — exact same logic as Connection Finder.
      // Only exchange/bridge/hot/custodial are non-private (excluded from expansion).
      // dag-team, genesis, defi, flagged, protocol, unknown → treated as private.
      // HARD_EXCL addresses are blocked earlier in the BFS loop — no check needed here.
      const isPrivateWallet = (addr: string): boolean => {
        const info = KNOWN_LABELS[addr];
        if (!info) return true; // unknown = private
        const type = (info.type || "").toLowerCase();
        return !["exchange", "bridge", "hot", "custodial", "official", "protocol", "base"].includes(type);
      };

      // ── Tier 1: expand from root wallet ───────────────────────────────────────
      setCommingleProgress(`${label}: tier 1…`);
      const rootTxs = await fetchTxs(wallet);
      for (const tx of rootTxs) {
        if (!passesAnalysisFilter(tx, chain)) continue;
        const cp = tx.direction === "in" ? tx.from : tx.to;
        if (!cp || cp === wallet || HARD_EXCL.has(cp) || reach.has(cp)) continue;
        reach.set(cp, { path: [wallet, cp], tier: 1, txCount: 1 });
        segmentTxs[`${wallet}::${cp}`] = tx;
      }

      // ── Tiers 2–6: expand from previous tier's expandable private nodes ───────
      // Frontier limits (how many nodes to expand from) per tier: 6, 4, 3, 2, 2
      const tierLimits = [6, 4, 3, 2, 2];
      for (let tier = 2; tier <= 6; tier++) {
        setCommingleProgress(`${label}: tier ${tier}…`);
        const prevNodes = Array.from(reach.entries())
          .filter(([addr, v]) => v.tier === tier - 1 && isPrivateWallet(addr))
          .slice(0, tierLimits[tier - 2]);
        if (prevNodes.length === 0) break;
        const txResults = await Promise.all(prevNodes.map(([a]) => fetchTxs(a)));
        for (let i = 0; i < prevNodes.length; i++) {
          const [parentAddr, parentData] = prevNodes[i];
          for (const tx of txResults[i]) {
            if (!passesAnalysisFilter(tx, chain)) continue;
            const cp = tx.direction === "in" ? tx.from : tx.to;
            if (!cp || cp === wallet || HARD_EXCL.has(cp) || reach.has(cp)) continue;
            reach.set(cp, { path: [...parentData.path, cp], tier, txCount: 1 });
            segmentTxs[`${parentAddr}::${cp}`] = tx;
          }
        }
      }

      return reach;
    };

    try {
      setCommingleProgress("Scanning target wallet…");
      const targetReach = await buildReachMap(address, "TARGET");

      const compReachMaps: Array<{ wallet: string; reachMap: ReachMap }> = [];
      for (let i = 0; i < _compWallets.length; i++) {
        const cw = _compWallets[i];
        setCommingleProgress(`Scanning comparison wallet ${i + 1}/${_compWallets.length}…`);
        compReachMaps.push({ wallet: cw, reachMap: await buildReachMap(cw, `COMP ${i + 1}`) });
      }

      // All wallets treated as equal peers — no "target" vs "comparison" bias.
      // Any address that 2+ input wallets can reach (directly or through hops) is a finding.
      const allPeerMaps: Array<{ wallet: string; reachMap: ReachMap }> = [
        { wallet: address, reachMap: targetReach },
        ...compReachMaps,
      ];

      // Build a map: shared-node-address → list of {wallet, path, tier} for every peer that reaches it
      const addrToPeers = new Map<string, Array<{ wallet: string; path: string[]; tier: number }>>();
      for (const { wallet: pw, reachMap } of allPeerMaps) {
        for (const [addr, data] of reachMap) {
          if (!addrToPeers.has(addr)) addrToPeers.set(addr, []);
          addrToPeers.get(addr)!.push({ wallet: pw, path: data.path, tier: data.tier });
        }
      }

      // A finding = any shared node reached by 2+ distinct input wallets
      const allInputWalletSet = new Set(allPeerMaps.map(p => p.wallet));
      const findings: CommingleFinding[] = [];
      for (const [addr, peers] of addrToPeers) {
        // Only count distinct input wallets (exclude non-input intermediate wallets)
        const inputPeers = peers.filter(p => allInputWalletSet.has(p.wallet));
        if (inputPeers.length < 2) continue;
        const minTier = Math.min(...inputPeers.map(p => p.tier));
        findings.push({
          sharedAddress: addr,
          knownInfo: KNOWN_LABELS[addr],
          tier: minTier,
          peerPaths: inputPeers.map(p => ({ wallet: p.wallet, path: p.path })),
          txCountTarget: inputPeers[0].path.length,
        });
      }

      findings.sort((a, b) => {
        if (a.tier !== b.tier) return a.tier - b.tier;
        // Unknown private wallets first (rank 0), dag-team second (rank 1),
        // exchange/bridge/genesis last (rank 2) — they appear in a separate section anyway.
        const rank = (f: CommingleFinding) => {
          if (!f.knownInfo) return 0;
          if (f.knownInfo.type === "dag-team") return 1;
          return 2; // exchange / bridge / genesis
        };
        if (rank(a) !== rank(b)) return rank(a) - rank(b);
        // Stable: longer path first; address tie-breaker for equal path lengths
        if (b.txCountTarget !== a.txCountTarget) return b.txCountTarget - a.txCountTarget;
        return a.sharedAddress.localeCompare(b.sharedAddress);
      });

      const tieredCounts: [number, number, number, number, number, number] = [
        findings.filter((f) => f.tier === 1).length,
        findings.filter((f) => f.tier === 2).length,
        findings.filter((f) => f.tier === 3).length,
        findings.filter((f) => f.tier === 4).length,
        findings.filter((f) => f.tier === 5).length,
        findings.filter((f) => f.tier === 6).length,
      ];

      // Hop TX details are captured during BFS (segmentTxs above) — no separate fetch needed.
      // hopFetchStats kept as empty object so the result shape stays compatible.
      const hopFetchStats: Record<string, { pages: number; txs: number; rateLimitEvents?: number; failReason?: string }> = {};

      // Fetch transactions for every cluster wallet and detect exchange flows directly.
      // KEY: scan RAW (unfiltered) txs so no asset/amount filter hides exchange outflows.
      // Paginate through multiple Horizon pages — the server returns at most 200 ops per
      // call (Stellar Horizon hard limit), so a single fetch misses older exchange txs.
      setCommingleProgress("Scanning cluster wallet transactions for exchange flows…");
      const walletTxs: Record<string, Tx[]> = {};
      const EXCH_TYPES_SCAN = new Set(["exchange", "bridge", "genesis"]);
      // key = "exchAddr::sourceWallet"
      const exchFlowsMap = new Map<string, {
        exchAddr: string; exchLabel: string; exchType: string;
        sourceWallet: string; txs: Tx[];
      }>();

      // Paginating fetch — follows nextCursor for up to maxPages pages of 200 ops each.
      // All wallets run in parallel; pages within each wallet are sequential.
      const fetchPagesForExch = async (w: string, maxPages: number): Promise<Tx[]> => {
        const acc: Tx[] = [];
        let cursor: string | null = null;
        for (let p = 0; p < maxPages; p++) {
          try {
            const qs = new URLSearchParams({ chain, limit: "200" });
            if (cursor) qs.set("cursor", cursor);
            const resp = await fetch(`/api/wallets/${encodeURIComponent(w)}/transactions?${qs}`);
            if (!resp.ok) break;
            const data = await resp.json() as {
              transactions?: Tx[]; nextCursor?: string | null; hasMore?: boolean;
            };
            acc.push(...(data.transactions ?? []));
            if (!data.hasMore || !data.nextCursor) break;
            cursor = data.nextCursor;
          } catch { break; }
        }
        return acc;
      };

      // target wallet: 10 pages (up to 2 000 ops); each comparison wallet: 5 pages (1 000 ops)
      const clusterFetch = [
        { w: address, maxPages: 10 },
        ..._compWallets.map((cw) => ({ w: cw, maxPages: 5 })),
      ];
      await Promise.allSettled(
        clusterFetch.map(async ({ w, maxPages }) => {
          const rawTxs = await fetchPagesForExch(w, maxPages);
          // Filtered set for display (walletTxs) — strict analysis minimums
          const filtered = rawTxs.filter((tx) => passesAnalysisFilter(tx, chain));
          if (filtered.length > 0) walletTxs[w] = filtered;
          // Exchange detection — apply analysis filter so dust doesn't register as exchange flows
          for (const tx of rawTxs) {
            if (tx.direction === "self") continue;
            if (!passesAnalysisFilter(tx, chain)) continue;
            const candidates = [tx.from, tx.to].filter((a): a is string => !!a && a !== w);
            for (const candidate of candidates) {
              const info = KNOWN_LABELS[candidate];
              if (!info || !EXCH_TYPES_SCAN.has(info.type)) continue;
              const key = `${candidate}::${w}`;
              if (!exchFlowsMap.has(key)) {
                exchFlowsMap.set(key, {
                  exchAddr: candidate, exchLabel: info.label, exchType: info.type,
                  sourceWallet: w, txs: [],
                });
              }
              exchFlowsMap.get(key)!.txs.push(tx);
            }
          }
        })
      );
      // Supplement from reach-map tier-1 — covers exchange nodes reachable from ANY peer wallet.
      // Uses allPeerMaps so all wallets are treated equally (no target/comparison distinction).
      for (const { wallet: pw, reachMap } of allPeerMaps) {
        for (const [addr, data] of reachMap) {
          if (data.tier !== 1) continue;
          const info = KNOWN_LABELS[addr];
          if (!info || !EXCH_TYPES_SCAN.has(info.type)) continue;
          const key = `${addr}::${pw}`;
          if (!exchFlowsMap.has(key)) {
            exchFlowsMap.set(key, { exchAddr: addr, exchLabel: info.label, exchType: info.type, sourceWallet: pw, txs: [] });
          }
        }
      }

      // Supplement from segmentTxs — hop wallet transactions fetched by fetchHopPages.
      // These cover cases where an INTERMEDIATE wallet (not target/comparison) sent to or
      // received from a known exchange (e.g. GAZSPN → Kraken, GD6OZZ → Coinbase Deposits).
      // segmentTxs stores both "fa::ta" and "ta::fa" for the same TX; we deduplicate via
      // exchFlowsMap.has() before inserting.
      for (const segKey of Object.keys(segmentTxs)) {
        const sep = segKey.indexOf("::");
        if (sep < 0) continue;
        const fa = segKey.slice(0, sep);
        const ta = segKey.slice(sep + 2);
        // Check both sides — either the fa or ta could be the exchange address.
        for (const [exchAddr, srcAddr] of [[fa, ta], [ta, fa]] as [string, string][]) {
          const info = KNOWN_LABELS[exchAddr];
          if (!info || !EXCH_TYPES_SCAN.has(info.type)) continue;
          // srcAddr is the hop wallet that transacted with the exchange.
          const flowKey = `${exchAddr}::${srcAddr}`;
          if (!exchFlowsMap.has(flowKey)) {
            const tx = segmentTxs[segKey];
            exchFlowsMap.set(flowKey, {
              exchAddr,
              exchLabel: info.label,
              exchType:  info.type,
              sourceWallet: srcAddr,
              txs: tx ? [tx] : [],
            });
          }
        }
      }

      const exchFlows = [...exchFlowsMap.values()];

      const _crRes: CommingleCheckResult = {
        targetWallet: address,
        comparisonWallets: _compWallets,
        chain,
        scannedAt: new Date().toISOString(),
        findings,
        tieredCounts,
        totalScanned: allPeerMaps.reduce((sum, { reachMap }) => sum + reachMap.size, 0),
        segmentTxs,
        hopFetchStats,
        walletTxs,
        exchFlows,
      };
      commingleResultRef.current = _crRes;
      setCommingleResult(_crRes);
      if (!comparisonOverride) setTimeout(() => comminglePanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 200);
      return _crRes;
    } catch (err) {
      setCommingleError(err instanceof Error ? err.message : "Analysis failed");
      return null;
    } finally {
      setCommingleLoading(false);
      setCommingleProgress("");
    }
  }, [address, commingleWallets, chain]);

  // ── FULL PACKAGE — runs all 3 analyses + Executive Summary in one click ──────
  const runFullPackage = useCallback(async () => {
    const pkgWallets = commingleWallets.length > 0 ? commingleWallets
                     : multiWallets.length > 0 ? multiWallets : [];
    if (pkgWallets.length === 0) {
      setShowComminglePanel(true);
      setTimeout(() => comminglePanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 200);
      setCommingleError("FULL PACKAGE requires at least one comparison wallet. Add wallets in the Commingle Check panel, then click FULL PACKAGE again.");
      return;
    }

    setFullPkgLoading(true);
    setFullPkgProgress("Step 1/4: Commingle Check…");
    // Reset refs so generators use fresh data even if stale state remains from a prior run
    commingleResultRef.current = null;
    multiResultRef.current = null;

    try {
      // 1. Commingle Check
      await runCommingleCheck(pkgWallets);

      // 2. Intersection / Funnel Analysis (same wallet set)
      setFullPkgProgress("Step 2/4: Intersection / Funnel Analysis…");
      await runMultiAnalysis([address, ...pkgWallets]);

      // 3. Fetch TX maps for exchange flows
      // Union of pkgWallets + multiWallets so exchange flows always mirrors
      // the standalone Exchange Flows button (which uses multiWallets).
      setFullPkgProgress("Step 3/4: Fetching exchange flow data…");
      const allFetchWallets = [...new Set([...pkgWallets, ...multiWallets])];
      const walletTxMap = new Map<string, Tx[]>();
      walletTxMap.set(address, allTxs);
      await Promise.all(
        allFetchWallets.map(async (w) => {
          const wAddr = chain === "xdc" ? normalizeXdcAddress(w) : w;
          try {
            const resp = await fetch(`/api/wallets/${encodeURIComponent(wAddr)}/transactions?chain=${chain}&limit=200`);
            if (!resp.ok) {
              console.error(`[runFullPackage] TX fetch failed for ${wAddr} (${chain}): HTTP ${resp.status}`);
              walletTxMap.set(w, []); return;
            }
            const data = await resp.json() as { transactions: Tx[] };
            walletTxMap.set(w, data.transactions ?? []);
          } catch (err) {
            console.error(`[runFullPackage] TX fetch error for ${wAddr} (${chain}):`, err instanceof Error ? err.message : String(err));
            walletTxMap.set(w, []);
          }
        })
      );

      // Build ordered exchWalletTxMap matching standalone Exchange Flows button:
      // [address, ...multiWallets] — if multiWallets empty, fall back to allFetchWallets
      const exchOrderedWallets = multiWallets.length > 0
        ? [address, ...multiWallets]
        : [address, ...pkgWallets];
      const exchWalletTxMap = new Map<string, Tx[]>();
      for (const w of exchOrderedWallets) exchWalletTxMap.set(w, walletTxMap.get(w) ?? []);

      // 4. Generate all 3 reports + executive summary
      setFullPkgProgress("Step 4/4: Generating reports…");
      const commingleText = commingleResultRef.current
        ? generateCommingleReport()
        : "(Commingle check did not produce results — check wallet addresses and try again)";
      const funnelText = multiResultRef.current
        ? generateMultiReport(walletTxMap)
        : "(Funnel analysis did not produce results)";
      const exchText = generateMultiExchangeFlowsReport(exchWalletTxMap);
      const summaryText = generateExecutiveSummary(commingleText, funnelText, exchText, victimWallet, victimName, exchWalletTxMap);

      const secDiv = (n: number, title: string) =>
        `\n\n${"═".repeat(64)}\n  SECTION ${n} — ${title}\n${"═".repeat(64)}\n\n`;

      const howToUse = [
        `\n\n${"═".repeat(64)}`,
        `  HOW TO USE THIS REPORT`,
        `${"═".repeat(64)}`,
        ``,
        `This Full Package report is structured for law enforcement investigators,`,
        `financial intelligence analysts, and legal counsel. Use this guide to`,
        `navigate the sections efficiently and prioritize your next actions.`,
        ``,
        `${"─".repeat(64)}`,
        `  SECTION GUIDE`,
        `${"─".repeat(64)}`,
        ``,
        `  EXECUTIVE SUMMARY (§1–§7) — START HERE`,
        `    The complete intelligence briefing. All high-level findings, risk scores,`,
        `    ranked exchange targets, flow visualizations, and ready-to-file subpoena`,
        `    templates. Share directly with prosecutors, supervisors, and compliance.`,
        ``,
        `  §1  Commingling Check Summary`,
        `    Use to establish linkage between wallets / defendants. Tier 1 (direct)`,
        `    shared addresses are the strongest evidence of coordinated fund movement`,
        `    and are suitable for joint prosecution filings.`,
        ``,
        `  §5  Recommended Subpoena Targets`,
        `    Prioritized table. US-regulated (★) exchanges should be subpoenaed first`,
        `    — fastest KYC turnaround, strongest legal compellability (18 U.S.C. § 2703).`,
        `    File preservation letters to ALL exchanges simultaneously.`,
        ``,
        `  §6  Key Flow Visualization`,
        `    Three formats:`,
        `    · ASCII flows   → paste into any report, email, or court filing`,
        `    · Mermaid chart → paste into https://mermaid.live for interactive diagram`,
        `      (shareable URL, present in hearings)`,
        `    · Graph JSON    → import into Gephi, Cytoscape, or yEd for advanced`,
        `      network analysis and publication-quality charts`,
        ``,
        `  §7  Subpoena Templates + Master Data Request`,
        `    TOP 5 DYNAMIC TEMPLATES: Fill in the bracketed fields (agency, address,`,
        `    dates) and send. US-regulated (★) templates carry strongest enforceability.`,
        `    MASTER DATA REQUEST (38 items): Comprehensive reference language. Copy`,
        `    the full data categories list into any subpoena or legal hold letter.`,
        ``,
        `${"─".repeat(64)}`,
        `  DETAILED REPORTS — SECTIONS 2–4`,
        `${"─".repeat(64)}`,
        ``,
        `  Section 2 — Commingle Check Report`,
        `    Full tier-by-tier shared address breakdown with TX evidence for each`,
        `    shared node. Attach as an exhibit to court filings.`,
        ``,
        `  Section 3 — Intersection / Funnel Analysis Report`,
        `    Shows which wallets share counterparties (convergence nodes). Use to`,
        `    establish coordinated movement and common control / conspiracy.`,
        ``,
        `  Section 4 — Exchange Flows Report`,
        `    Per-exchange breakdown with individual TX details. Attach alongside`,
        `    subpoena responses to corroborate account holder identity.`,
        ``,
        `${"─".repeat(64)}`,
        `  PRIORITIZATION CHECKLIST`,
        `${"─".repeat(64)}`,
        ``,
        `  □  Review KEY FINDINGS box (top of Executive Summary) for immediate actions`,
        `  □  Subpoena US-regulated ★ exchanges first (fastest KYC turnaround)`,
        `  □  File preservation letters to ALL identified exchanges simultaneously`,
        `  □  Use peel-chain scores (§1, §5) to prioritize wallet-level investigations`,
        `  □  High tier-1 commingling = strong basis for joint prosecution`,
        `  □  Use "Load All History" on each wallet, re-run Full Package for max coverage`,
        ``,
        `  Generated by CryptoChainTrace — cryptochaintrace.com`,
        `${"═".repeat(64)}`,
      ].join("\n");

      const fullReport = [
        summaryText,
        secDiv(2, "Commingle Check Report") + commingleText,
        secDiv(3, "Intersection / Funnel Analysis Report") + funnelText,
        secDiv(4, "Exchange Flows Report") + exchText,
        howToUse,
      ].join("");

      const title = `Full Package — ${chain.toUpperCase()} — ${pkgWallets.length + 1} wallets`;
      setReportContent(fullReport);
      setReportTitle(title);
      setReportJsonData({
        reportType: "full-package",
        generatedAt: new Date().toISOString(),
        chain,
        subjectAddress: address,
        victimWallet,
        victimName,
        walletInfo: wallet,
        trackedWallets: [address, ...pkgWallets],
        reportText: fullReport,
      });
      setShowReportModal(true);
    } catch (err) {
      setCommingleError(`Full Package failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setFullPkgLoading(false);
      setFullPkgProgress("");
    }
  }, [address, commingleWallets, multiWallets, chain, victimWallet, victimName, allTxs,
      runCommingleCheck, runMultiAnalysis]);

  // ── Helpers ──
  const getRiskBadge = (score: number | null) => {
    if (score === null)
      return <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground font-mono"><Shield className="w-3 h-3" /> UNSCORED</span>;
    if (score <= 30)
      return <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-green-950/60 text-green-400 font-mono"><ShieldCheck className="w-3 h-3" /> LOW RISK ({score})</span>;
    if (score <= 70)
      return <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-yellow-950/60 text-yellow-400 font-mono"><ShieldAlert className="w-3 h-3" /> MED RISK ({score})</span>;
    return <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-red-950/60 text-red-400 font-mono"><ShieldAlert className="w-3 h-3" /> HIGH RISK ({score})</span>;
  };

  const getKnownBadge = (info?: { label: string; type: string }, size: "sm" | "md" | "lg" = "sm") => {
    if (!info) return null;
    const lbl = info.label.toLowerCase();
    const typeDefaults: Record<string, { bg: string; border: string; glow: string; ring: string; emoji: string }> = {
      exchange: { bg: "bg-blue-600/95",    border: "border-blue-300/70",    glow: "shadow-blue-500/50",    ring: "ring-1 ring-blue-400/40",    emoji: "🏦" },
      genesis:  { bg: "bg-purple-700/95",  border: "border-purple-300/80",  glow: "shadow-purple-400/40",  ring: "ring-1 ring-purple-400/30",  emoji: "⚡" },
      defi:     { bg: "bg-teal-700/95",    border: "border-teal-300/80",    glow: "shadow-teal-400/40",    ring: "ring-1 ring-teal-400/30",    emoji: "🔄" },
      flagged:  { bg: "bg-red-600/95",     border: "border-red-300/80",     glow: "shadow-red-400/40",     ring: "ring-1 ring-red-400/30",     emoji: "🚨" },
      mixer:    { bg: "bg-rose-900/95",    border: "border-rose-300/80",    glow: "shadow-rose-400/60",    ring: "ring-2 ring-rose-400/50",    emoji: "🌀" },
      founder:  { bg: "bg-yellow-600/95", border: "border-yellow-300/80",  glow: "shadow-yellow-400/60",  ring: "ring-2 ring-yellow-400/50",  emoji: "👑" },
      bridge:   { bg: "bg-amber-600/95",   border: "border-amber-300/80",   glow: "shadow-amber-400/40",   ring: "ring-1 ring-amber-400/30",   emoji: "🌉" },
      "dag-team": { bg: "bg-orange-600/95", border: "border-orange-300/80", glow: "shadow-orange-400/40",  ring: "ring-1 ring-orange-400/30",  emoji: "🏛️" },
    };
    const exchangeThemes: Array<[RegExp, { bg: string; border: string; glow: string; ring: string; emoji: string }]> = [
      [/uphold/,     { bg: "bg-red-600/95",      border: "border-red-300/70",      glow: "shadow-red-500/60",      ring: "ring-1 ring-red-400/50",      emoji: "🔴" }],
      [/kraken/,     { bg: "bg-orange-600/95",    border: "border-orange-300/70",   glow: "shadow-orange-500/60",   ring: "ring-1 ring-orange-400/50",   emoji: "🟠" }],
      [/coinbase/,   { bg: "bg-blue-600/95",      border: "border-blue-300/70",     glow: "shadow-blue-500/60",     ring: "ring-1 ring-blue-400/50",     emoji: "🔵" }],
      [/okx/,        { bg: "bg-purple-600/95",    border: "border-purple-300/70",   glow: "shadow-purple-500/60",   ring: "ring-1 ring-purple-400/50",   emoji: "🟣" }],
      [/binance/,    { bg: "bg-yellow-500/95",    border: "border-yellow-300/70",   glow: "shadow-yellow-500/60",   ring: "ring-1 ring-yellow-400/50",   emoji: "🟡" }],
      [/gemini/,     { bg: "bg-emerald-600/95",   border: "border-emerald-300/70",  glow: "shadow-emerald-500/60",  ring: "ring-1 ring-emerald-400/50",  emoji: "💎" }],
      [/crypto\.com|crypto_com/,
                     { bg: "bg-sky-600/95",        border: "border-sky-300/70",      glow: "shadow-sky-500/60",      ring: "ring-1 ring-sky-400/50",      emoji: "🔷" }],
      [/bitstamp/,   { bg: "bg-cyan-600/95",      border: "border-cyan-300/70",     glow: "shadow-cyan-500/60",     ring: "ring-1 ring-cyan-400/50",     emoji: "🏦" }],
      [/bitfinex/,   { bg: "bg-teal-600/95",      border: "border-teal-300/70",     glow: "shadow-teal-500/60",     ring: "ring-1 ring-teal-400/50",     emoji: "🏦" }],
      [/huobi/,      { bg: "bg-amber-600/95",     border: "border-amber-300/70",    glow: "shadow-amber-500/60",    ring: "ring-1 ring-amber-400/50",    emoji: "🏦" }],
      [/bybit/,      { bg: "bg-violet-600/95",    border: "border-violet-300/70",   glow: "shadow-violet-500/60",   ring: "ring-1 ring-violet-400/50",   emoji: "🏦" }],
      [/kucoin/,     { bg: "bg-green-600/95",     border: "border-green-300/70",    glow: "shadow-green-500/60",    ring: "ring-1 ring-green-400/50",    emoji: "🟢" }],
      [/mexc/,       { bg: "bg-lime-600/95",      border: "border-lime-300/70",     glow: "shadow-lime-500/60",     ring: "ring-1 ring-lime-400/50",     emoji: "🟢" }],
      [/gate/,       { bg: "bg-rose-600/95",      border: "border-rose-300/70",     glow: "shadow-rose-500/60",     ring: "ring-1 ring-rose-400/50",     emoji: "🏛️" }],
      [/bitmex/,     { bg: "bg-red-700/95",       border: "border-red-300/70",      glow: "shadow-red-500/60",      ring: "ring-1 ring-red-400/50",      emoji: "🏦" }],
      [/robinhood/,  { bg: "bg-green-600/95",     border: "border-green-300/70",    glow: "shadow-green-500/60",    ring: "ring-1 ring-green-400/50",    emoji: "🏦" }],
    ];
    const base = typeDefaults[info.type] ?? typeDefaults.exchange;
    const exchangeOverride = info.type === "exchange"
      ? (exchangeThemes.find(([rx]) => rx.test(lbl))?.[1] ?? null)
      : null;
    const c = { text: "text-white", ...base, ...(exchangeOverride ?? {}) };
    const sz = size === "lg"
      ? "text-sm px-3.5 py-1.5 gap-2 rounded-lg font-extrabold tracking-wide shadow-lg"
      : size === "md"
      ? "text-xs px-2.5 py-1 gap-1.5 rounded-md font-bold shadow-md"
      : "text-[11px] px-2 py-0.5 gap-1 rounded font-bold shadow-sm";
    return (
      <span className={`inline-flex items-center shrink-0 font-mono border ${sz} ${c.bg} ${c.text} ${c.border} ${c.ring} shadow-sm ${c.glow}`}>
        <span>{c.emoji}</span>
        <span>{info.label}</span>
      </span>
    );
  };

  const renderCounterpartyCell = (addr: string | null, dir: string) => {
    if (!addr) {
      return dir === "out"
        ? <span className="text-muted-foreground text-xs">CONTRACT CREATION</span>
        : <span className="text-muted-foreground text-xs">—</span>;
    }
    const known = getKnownInfo(addr, chain) ?? undefined;
    const saved = savedWallets.has(addr);
    const explorerAddrUrl = WALLET_EXPLORER_MAP[chain];
    return (
      <div className="flex items-center gap-1.5 flex-wrap">
        <button
          onClick={(e) => {
            e.stopPropagation();
            const rect = e.currentTarget.getBoundingClientRect();
            setActiveMenu({ addr, x: rect.left, y: rect.bottom + 4 });
          }}
          className="text-primary/80 hover:text-primary text-xs hover:underline transition-colors font-mono"
          title={addr}
        >
          {addr.length > 14 ? `${addr.slice(0, 8)}…${addr.slice(-4)}` : addr}
        </button>
        {known && getKnownBadge(known, "md")}
        {saved && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
        {explorerAddrUrl && (
          <a
            href={explorerAddrUrl(addr)}
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-primary transition-colors"
          >
            <ExternalLink className="w-2.5 h-2.5" />
          </a>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); addToCommingle(addr); }}
          className={`transition-colors shrink-0 ${commingleWallets.includes(addr) ? "text-purple-400" : "text-muted-foreground/40 hover:text-purple-400"}`}
          title={commingleWallets.includes(addr) ? "In Commingle Check" : "Add to Commingle Check"}
        >
          <GitMerge className="w-2.5 h-2.5" />
        </button>
      </div>
    );
  };

  const explorerTxUrl = EXPLORER_MAP[chain];

  if (walletError) {
    return (
      <div className="p-8 flex flex-col items-center justify-center min-h-[60vh] text-center space-y-4">
        <ShieldAlert className="w-16 h-16 text-destructive opacity-40" />
        <h2 className="text-xl font-mono text-destructive tracking-widest">PROFILE NOT FOUND</h2>
        <p className="text-muted-foreground text-sm max-w-md font-mono">
          Target address could not be resolved on the{" "}
          <span className="text-primary uppercase">{chain}</span> network.
        </p>
        <Link href="/">
          <Button variant="outline" className="font-mono mt-4 tracking-wider">RETURN TO SEARCH</Button>
        </Link>
      </div>
    );
  }

  const inCount = filteredTxs.filter((t) => t.direction === "in").length;
  const outCount = filteredTxs.filter((t) => t.direction === "out").length;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6" onClick={() => setActiveMenu(null)}>

      {/* ── Commingle toast ── */}
      {commingleToast && (
        <div className="fixed bottom-6 right-6 z-[100] flex items-center gap-2.5 px-4 py-3 bg-purple-900/95 border border-purple-500/50 rounded-lg shadow-xl shadow-black/40 text-purple-200 text-xs font-mono pointer-events-none">
          <GitMerge className="w-3.5 h-3.5 text-purple-400 shrink-0" />
          {commingleToast}
        </div>
      )}

      {/* ── Counterparty context menu ── */}
      {activeMenu && (
        <div
          className="fixed z-50 bg-card border border-border/60 rounded-lg shadow-xl shadow-black/40 overflow-hidden min-w-[220px]"
          style={{ top: Math.min(activeMenu.y, window.innerHeight - 160), left: Math.min(activeMenu.x, window.innerWidth - 240) }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-3 py-2 border-b border-border/40 bg-muted/20">
            <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Counterparty</p>
            <p className="text-xs font-mono text-primary truncate max-w-[200px]">{activeMenu.addr}</p>
          </div>
          <div className="p-1">
            <button
              onClick={() => { setActiveMenu(null); setLocation(`/wallet/${activeMenu.addr}?chain=${chain}`); }}
              className="w-full text-left px-3 py-2 text-xs font-mono text-foreground hover:bg-muted/40 rounded-md transition-colors flex items-center gap-2"
            >
              <Network className="w-3 h-3 text-muted-foreground" /> View Profile
            </button>
            <button
              onClick={() => continueTrailOnWallet(activeMenu.addr)}
              className="w-full text-left px-3 py-2 text-xs font-mono text-primary hover:bg-primary/10 rounded-md transition-colors flex items-center gap-2"
            >
              <GitFork className="w-3 h-3" /> Continue Trail on this Wallet
            </button>
            <button
              onClick={() => { addToCommingle(activeMenu.addr); setActiveMenu(null); }}
              className="w-full text-left px-3 py-2 text-xs font-mono text-purple-400 hover:bg-purple-950/30 rounded-md transition-colors flex items-center gap-2"
            >
              <GitMerge className="w-3 h-3" /> Add to Commingle Check
            </button>
            <button
              onClick={() => { toggleSavedWallet(activeMenu.addr); setActiveMenu(null); }}
              className={`w-full text-left px-3 py-2 text-xs font-mono rounded-md transition-colors flex items-center gap-2 ${
                savedWallets.has(activeMenu.addr)
                  ? "text-yellow-400 hover:bg-yellow-950/30"
                  : "text-muted-foreground hover:bg-muted/40"
              }`}
            >
              {savedWallets.has(activeMenu.addr)
                ? <><BookmarkCheck className="w-3 h-3" /> Remove from Saved</>
                : <><Bookmark className="w-3 h-3" /> Save / Add to Trail Wallet</>
              }
            </button>
            <a
              href={WALLET_EXPLORER_MAP[chain]?.(activeMenu.addr) ?? "#"}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setActiveMenu(null)}
              className="w-full text-left px-3 py-2 text-xs font-mono text-muted-foreground hover:bg-muted/40 rounded-md transition-colors flex items-center gap-2 block"
            >
              <ExternalLink className="w-3 h-3" /> Open in Explorer
            </a>
          </div>
        </div>
      )}

      {/* ── Header ── */}
      <div className="flex flex-col gap-3">
        {/* ── Big wallet label at the very top ── */}
        {getKnownInfo(address, chain) ? (
          <div className="flex items-center gap-3 mb-2">
            {getKnownBadge(getKnownInfo(address, chain)!, "lg")}
          </div>
        ) : (
          <h1 className="text-3xl font-bold text-zinc-400 mb-2">Unknown Wallet</h1>
        )}
        {/* ── Badges row ── */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="px-2 py-0.5 bg-primary/10 text-primary text-xs font-mono rounded uppercase border border-primary/20">{chain}</span>
          {walletLoading ? <div className="w-28 h-5 bg-muted/50 rounded animate-pulse" /> : getRiskBadge(wallet?.riskScore ?? null)}
          {wallet?.isContract && (
            <span className="flex items-center gap-1 px-2 py-0.5 bg-blue-950/50 text-blue-400 text-xs font-mono rounded border border-blue-500/20">
              <FileCode className="w-3 h-3" /> CONTRACT
            </span>
          )}
          {wallet?.tags.map((tag) => (
            <span key={tag} className="flex items-center gap-1 px-2 py-0.5 bg-muted text-muted-foreground text-xs font-mono rounded">
              <Tag className="w-3 h-3" /> {tag.toUpperCase()}
            </span>
          ))}
          {savedWallets.has(address) && (
            <span className="flex items-center gap-1 px-2 py-0.5 bg-yellow-950/50 text-yellow-400 text-xs font-mono rounded border border-yellow-500/20">
              <Bookmark className="w-3 h-3 fill-yellow-400" /> SAVED
            </span>
          )}
        </div>
        {/* ── Full-width address box ── */}
        <div className="font-mono text-sm text-foreground bg-muted/20 px-3 py-2 rounded border border-border/40">
          <AddressDisplay address={address} truncate={false} showIcon />
        </div>
        {/* ── Action buttons row ── */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <Button
              variant="outline"
              className={`font-mono text-xs ${
                savedWallets.has(address)
                  ? "border-yellow-500/50 text-yellow-400 hover:bg-yellow-950/30 bg-yellow-950/20"
                  : "border-border/40 text-muted-foreground hover:border-yellow-500/50 hover:text-yellow-400"
              }`}
              onClick={() => toggleSavedWallet(address)}
            >
              {savedWallets.has(address)
                ? <><BookmarkCheck className="w-3.5 h-3.5 mr-1.5" /> WATCHLISTED</>
                : <><Bookmark className="w-3.5 h-3.5 mr-1.5" /> ADD TO WATCHLIST</>
              }
            </Button>
            <Link href={`/trace/${address}?chain=${chain}`}>
              <Button variant="outline" className="font-mono border-primary/30 text-primary hover:bg-primary/10 text-xs">
                <Network className="w-3.5 h-3.5 mr-1.5" /> TRACE GRAPH
              </Button>
            </Link>
            <Button
              variant="outline"
              className={`font-mono text-xs ${showMultiPanel ? "border-violet-500/60 text-violet-300 bg-violet-950/30 hover:bg-violet-950/50" : "border-violet-500/30 text-violet-400 hover:bg-violet-950/30 hover:border-violet-500/60"}`}
              onClick={() => { setShowMultiPanel((v) => !v); if (!showMultiPanel) setTimeout(() => multiPanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100); }}
            >
              <Layers className="w-3.5 h-3.5 mr-1.5" /> INTERSECTION / FUNNEL
            </Button>
            <Button
              variant="outline"
              className={`font-mono text-xs ${showComminglePanel ? "border-amber-500/60 text-amber-300 bg-amber-950/30 hover:bg-amber-950/50" : "border-amber-500/30 text-amber-400 hover:bg-amber-950/30 hover:border-amber-500/60"}`}
              onClick={() => { setShowComminglePanel((v) => !v); if (!showComminglePanel) setTimeout(() => comminglePanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100); }}
            >
              <GitMerge className="w-3.5 h-3.5 mr-1.5" /> COMMINGLE CHECK
            </Button>
            <Button
              variant="outline"
              className={`font-mono text-xs ${showPathPanel ? "border-rose-500/60 text-rose-300 bg-rose-950/30 hover:bg-rose-950/50" : "border-rose-500/30 text-rose-400 hover:bg-rose-950/30 hover:border-rose-500/60"}`}
              title="Trace funds from victim to thief hop-by-hop with taint analysis"
              onClick={() => { setShowPathPanel((v) => !v); if (!showPathPanel) setTimeout(() => pathPanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100); }}
            >
              <Route className="w-3.5 h-3.5 mr-1.5" /> VICTIM → THIEF PATH
            </Button>
            <Button
              variant="outline"
              disabled={multiExchLoading}
              className="font-mono text-xs border-emerald-500/40 text-emerald-400 hover:bg-emerald-950/30 hover:border-emerald-500/70 hover:text-emerald-300 disabled:opacity-50"
              title={multiWallets.length > 0 ? `Generate combined exchange flows for all ${multiWallets.length + 1} wallets` : "Generate a report of all exchange, bridge, and protocol transactions"}
              onClick={async () => {
                if (multiWallets.length === 0) {
                  // Single-wallet path — unchanged
                  const rpt = generateExchangeFlowsReport();
                  const title = `Exchange Flows Report — ${chain.toUpperCase()} — ${address.slice(0, 12)}`;
                  setReportContent(rpt);
                  setReportTitle(title);
                  setReportJsonData({ reportType: "exchange-flows", generatedAt: new Date().toISOString(), chain, subjectAddress: address, walletInfo: wallet, selectedAddresses: [], reportText: rpt });
                  setShowReportModal(true);
                } else {
                  // Multi-wallet path — fetch TXs for each additional wallet then generate combined report
                  setMultiExchLoading(true);
                  try {
                    const allWallets = [address, ...multiWallets];
                    const walletTxMap = new Map<string, Tx[]>();
                    walletTxMap.set(address, allTxs);
                    await Promise.all(
                      multiWallets.map(async (w) => {
                        try {
                          const resp = await fetch(`/api/wallets/${encodeURIComponent(w)}/transactions?chain=${chain}&limit=200`);
                          if (!resp.ok) { walletTxMap.set(w, []); return; }
                          const data = await resp.json() as { transactions: Tx[] };
                          walletTxMap.set(w, data.transactions ?? []);
                        } catch { walletTxMap.set(w, []); }
                      })
                    );
                    // Ensure insertion order matches allWallets order
                    const ordered = new Map<string, Tx[]>();
                    for (const w of allWallets) ordered.set(w, walletTxMap.get(w) ?? []);
                    const rpt = generateMultiExchangeFlowsReport(ordered);
                    const title = `Multi-Wallet Exchange Flows — ${chain.toUpperCase()} — ${allWallets.length} wallets`;
                    setReportContent(rpt);
                    setReportTitle(title);
                    setReportJsonData({ reportType: "exchange-flows-multi", generatedAt: new Date().toISOString(), chain, subjectAddress: address, walletInfo: wallet, selectedAddresses: multiWallets, reportText: rpt });
                    setShowReportModal(true);
                  } finally {
                    setMultiExchLoading(false);
                  }
                }
              }}
            >
              <Landmark className="w-3.5 h-3.5 mr-1.5" />
              {multiExchLoading ? "Fetching…" : multiWallets.length > 0 ? `EXCHANGE FLOWS (${multiWallets.length + 1} WALLETS)` : "EXCHANGE FLOWS"}
            </Button>
            <Button
              variant="outline"
              className="font-mono text-xs border-purple-500/30 text-purple-400 hover:bg-purple-950/30 hover:border-purple-500/60"
              onClick={() => {
                try {
                  const raw = localStorage.getItem("chaintrace-commingle-wallets");
                  const existing: string[] = raw ? JSON.parse(raw) : [];
                  if (!existing.includes(address)) {
                    localStorage.setItem("chaintrace-commingle-wallets", JSON.stringify([...existing, address]));
                  }
                } catch { /* noop */ }
                setCommingleToast("Wallet saved — open Commingle Check on any profile to compare");
                setTimeout(() => setCommingleToast(null), 3000);
              }}
              title="Save this wallet address into your Commingle Check comparison list"
            >
              <GitMerge className="w-3.5 h-3.5 mr-1.5" /> ADD TO COMMINGLE
            </Button>
            <Button
              variant="outline"
              className={`font-mono text-xs ${showTiePanel ? "border-sky-500/60 text-sky-300 bg-sky-950/30 hover:bg-sky-950/50" : "border-sky-500/30 text-sky-400 hover:bg-sky-950/30 hover:border-sky-500/60"}`}
              title="Bidirectional search — find a verifiable connection path between this wallet and any other wallet"
              onClick={() => { setShowTiePanel((v) => !v); if (!showTiePanel) setTimeout(() => tiePanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100); }}
            >
              <Network className="w-3.5 h-3.5 mr-1.5" /> CONNECTION FINDER
            </Button>
            <Button
              variant="outline"
              className={`font-mono text-xs ${showOriginPanel ? "border-cyan-500/60 text-cyan-300 bg-cyan-950/30 hover:bg-cyan-950/50" : "border-cyan-500/30 text-cyan-400 hover:bg-cyan-950/30 hover:border-cyan-500/60"}`}
              onClick={() => { setShowOriginPanel((v) => !v); if (!showOriginPanel) setTimeout(() => originPanelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100); }}
            >
              <ArrowLeft className="w-3.5 h-3.5 mr-1.5" /> TRACE TO ORIGIN
            </Button>
            <Button
              disabled={fullPkgLoading}
              className="font-mono text-xs bg-yellow-500 hover:bg-yellow-400 text-black font-bold border-yellow-400/60 shadow-[0_0_12px_rgba(234,179,8,0.35)] hover:shadow-[0_0_18px_rgba(234,179,8,0.5)] disabled:opacity-60 disabled:cursor-not-allowed transition-all"
              title="One-click: runs Commingle Check + Intersection/Funnel Analysis + Exchange Flows and generates an Executive Summary"
              onClick={runFullPackage}
            >
              {fullPkgLoading
                ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />{fullPkgProgress || "Running…"}</>
                : <><Package className="w-3.5 h-3.5 mr-1.5" />FULL PACKAGE</>
              }
            </Button>
            <Button
              className="font-mono bg-primary text-primary-foreground hover:bg-primary/90 text-xs"
              onClick={() => startTrailTrace(address)}
            >
              <GitFork className="w-3.5 h-3.5 mr-1.5" /> START TRAIL TRACE
            </Button>
          </div>
          {/* ── Full Package — victim config strip ── */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-mono text-yellow-500/70 shrink-0">FULL PKG VICTIM:</span>
            <input
              className="font-mono text-[10px] bg-yellow-950/20 border border-yellow-500/20 text-yellow-200/80 placeholder:text-muted-foreground/40 rounded px-2 py-0.5 w-56 focus:outline-none focus:border-yellow-400/50"
              placeholder="Victim wallet address…"
              value={victimWallet}
              onChange={e => setVictimWallet(e.target.value.trim())}
              spellCheck={false}
            />
            <input
              className="font-mono text-[10px] bg-yellow-950/20 border border-yellow-500/20 text-yellow-200/80 placeholder:text-muted-foreground/40 rounded px-2 py-0.5 w-40 focus:outline-none focus:border-yellow-400/50"
              placeholder="Victim name…"
              value={victimName}
              onChange={e => setVictimName(e.target.value)}
            />
            <span className="text-[9px] font-mono text-muted-foreground/40">
              (embedded in Executive Summary; uses Commingle Check wallet list)
            </span>
          </div>
          {/* ── Selection badge + Generate Report ── */}
          {selectedWallets.size > 0 && (
            <div className="flex items-center gap-2 flex-wrap justify-end">
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-orange-950/40 border border-orange-500/30 rounded text-[11px] font-mono text-orange-300">
                <Flag className="w-3 h-3 fill-orange-400 text-orange-400" />
                <span>{selectedWallets.size} wallet{selectedWallets.size !== 1 ? "s" : ""} selected</span>
                <button onClick={clearSelected} className="ml-1 text-orange-400/60 hover:text-orange-300 transition-colors">
                  <X className="w-3 h-3" />
                </button>
              </div>
              <Button
                className="font-mono text-xs bg-orange-600 hover:bg-orange-500 text-white border-0"
                onClick={() => {
                  const rpt = generateReport();
                  const title = `Investigative Report — ${chain.toUpperCase()} — ${address.slice(0, 12)}`;
                  setReportContent(rpt);
                  setReportTitle(title);
                  setReportJsonData({ reportType: "investigative", generatedAt: new Date().toISOString(), chain, subjectAddress: address, walletInfo: wallet, selectedAddresses: [...selectedWallets], reportText: rpt });
                  setShowReportModal(true);
                }}
              >
                <FileText className="w-3.5 h-3.5 mr-1.5" /> GENERATE INVESTIGATIVE REPORT
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* ── Support Banner ── */}
      <div className="rounded-lg border border-pink-500/30 bg-gradient-to-r from-pink-950/30 via-pink-950/20 to-transparent overflow-hidden">
        <div className="px-5 py-4">
          <div className="flex items-start gap-4">
            <div className="shrink-0 w-9 h-9 rounded-full bg-pink-500/15 border border-pink-500/30 flex items-center justify-center mt-0.5">
              <Heart className="w-4 h-4 text-pink-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-mono font-bold text-pink-300 tracking-wide mb-0.5">
                Support This Free Tool
              </p>
              <p className="text-xs font-mono text-muted-foreground leading-relaxed">
                <span className="text-pink-400">100% free</span> — no fees, ads, or data selling. If CryptoChainTrace helped your investigation, even a small donation keeps the servers running.
              </p>
            </div>
            <button
              onClick={() => setShowDonate((v) => !v)}
              className="shrink-0 text-[10px] font-mono text-pink-400 hover:text-pink-300 border border-pink-500/30 hover:border-pink-400/60 bg-pink-950/40 hover:bg-pink-950/60 px-3 py-1.5 rounded transition-colors font-semibold tracking-wider"
            >
              {showDonate ? "HIDE ↑" : "DONATE ↓"}
            </button>
          </div>
          {showDonate && (
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {([
                { symbol: "XLM", label: "Stellar",  address: "GCXUMH47OGMC6JKUCMNG5KSKUOZGX7H4A6P2YZTZ2FCA2ZEB2PPSB6XW", color: "text-sky-300",    bg: "bg-sky-950/30",    border: "border-sky-500/25" },
                { symbol: "XRP", label: "Ripple",   address: "rHm4Erz4urYGqvssR6Rs8DwsQkDeEQwxuV",                          color: "text-cyan-300",   bg: "bg-cyan-950/30",   border: "border-cyan-500/25" },
                { symbol: "BTC", label: "Bitcoin",  address: "bc1q3k20tfjatu8prsszr9jmtyayj665af2aavfeyt",                   color: "text-orange-300", bg: "bg-orange-950/30", border: "border-orange-500/25" },
                { symbol: "ETH", label: "Ethereum", address: "0x0b3E9efb09Ead589F9F4c957228eE5E45B286d55",                  color: "text-blue-300",   bg: "bg-blue-950/30",   border: "border-blue-500/25" },
              ] as { symbol: string; label: string; address: string; color: string; bg: string; border: string }[]).map((d) => (
                <div key={d.symbol} className={`flex items-center gap-3 ${d.bg} border ${d.border} px-3 py-2.5 rounded-lg`}>
                  <div className="shrink-0 text-center w-10">
                    <span className={`text-xs font-mono font-bold ${d.color} block leading-none`}>{d.symbol}</span>
                    <span className="text-[9px] font-mono text-muted-foreground/50 block mt-0.5">{d.label}</span>
                  </div>
                  <code className="text-[10px] font-mono text-muted-foreground/70 truncate flex-1 min-w-0">{d.address}</code>
                  <button
                    onClick={() => copyDonateAddr(d.address)}
                    className={`shrink-0 transition-all ${copiedDonate === d.address ? "text-green-400 scale-110" : `${d.color} opacity-60 hover:opacity-100`}`}
                    title={`Copy ${d.symbol} address`}
                  >
                    {copiedDonate === d.address
                      ? <Check className="w-3.5 h-3.5" />
                      : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Stats ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "BALANCE", value: wallet?.balance ?? "0", sub: `$${(wallet?.balanceUsd ?? 0).toLocaleString()}`, subClass: "text-green-400" },
          {
            label: "TRANSACTIONS",
            value: allTxs.length > 0
              ? `${allTxs.length.toLocaleString()}${page.current.hasMore ? "+" : ""}`
              : (wallet?.transactionCount ?? 0).toLocaleString(),
            sub: null,
          },
          { label: "FIRST SEEN", value: wallet?.firstSeen ? new Date(wallet.firstSeen).toLocaleDateString() : "UNKNOWN", sub: null },
          { label: "LAST ACTIVE", value: wallet?.lastSeen ? new Date(wallet.lastSeen).toLocaleDateString() : "UNKNOWN", sub: null },
        ].map((stat) => (
          <Card key={stat.label} className="bg-card/40 border-border/40">
            <CardContent className="p-4">
              <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-1.5">{stat.label}</div>
              {walletLoading ? (
                <div className="h-7 bg-muted/50 rounded animate-pulse" />
              ) : (
                <>
                  <div className="text-xl font-mono text-foreground truncate">{stat.value}</div>
                  {stat.sub && <div className={`text-xs font-mono mt-0.5 ${stat.subClass ?? "text-muted-foreground"}`}>{stat.sub}</div>}
                </>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── Transaction Ledger ── */}
      <Card className="bg-card/40 border-border/40">
        <CardHeader className="border-b border-border/40 pb-4 px-5 pt-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <CardTitle className="text-sm font-mono uppercase tracking-widest text-foreground">Transaction Ledger</CardTitle>
              <p className="text-xs text-muted-foreground font-mono mt-1">
                {allTxs.length} loaded{page.current.hasMore ? ` · more available` : " · complete"}
                <span className="ml-2 text-muted-foreground/40">· max 25,000 for performance — Load More available</span>
              </p>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              {/* ── Minimum Amount Filter ── */}
              <div className="flex items-center gap-1.5 bg-muted/20 border border-border/40 rounded px-2 py-1">
                <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider whitespace-nowrap">
                  Min Amount
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={minAmountInput}
                  onChange={(e) => {
                    const raw = e.target.value;
                    setMinAmountInput(raw);
                    const parsed = parseFloat(raw);
                    if (!isNaN(parsed) && parsed >= 0) setMinAmount(parsed);
                    else if (raw === "" || raw === "0") setMinAmount(0);
                  }}
                  className="w-16 bg-transparent text-xs font-mono text-foreground outline-none text-right [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                  placeholder="1"
                />
                <span className="text-[10px] font-mono text-muted-foreground/60 uppercase">{chain}</span>
              </div>

              {/* ── View Mode Segmented Control — always visible ── */}
              <div className="flex items-center rounded border border-border/40 overflow-hidden text-[10px] font-mono">
                {(["in-first", "out-first", "mixed"] as const).map((m) => {
                  const labels: Record<string, string> = { "in-first": "IN FIRST", "out-first": "OUT FIRST", mixed: "MIXED" };
                  const colors: Record<string, string> = {
                    "in-first": viewMode === m ? "bg-green-950/60 text-green-400" : "bg-muted/10 text-muted-foreground hover:text-green-400",
                    "out-first": viewMode === m ? "bg-red-950/60 text-red-400" : "bg-muted/10 text-muted-foreground hover:text-red-400",
                    mixed: viewMode === m ? "bg-primary/20 text-primary" : "bg-muted/10 text-muted-foreground hover:text-primary",
                  };
                  return (
                    <button
                      key={m}
                      onClick={() => setAndSaveViewMode(m)}
                      className={`px-2.5 py-1.5 transition-colors border-r last:border-r-0 border-border/40 ${colors[m]}`}
                    >
                      {labels[m]}
                    </button>
                  );
                })}
              </div>

              {/* ── Only IN / Only OUT filter — only when Group By Counterparty is ON ── */}
              {groupByCounterparty && (
                <div className="flex items-center rounded border border-border/40 overflow-hidden text-[10px] font-mono">
                  {(["all", "only-in", "only-out"] as const).map((f) => {
                    const labels: Record<string, string> = { all: "ALL", "only-in": "↓ ONLY IN", "only-out": "↑ ONLY OUT" };
                    const colors: Record<string, string> = {
                      all: dirFilter === f ? "bg-primary/20 text-primary" : "bg-muted/10 text-muted-foreground hover:text-primary",
                      "only-in": dirFilter === f ? "bg-green-950/60 text-green-400 font-semibold" : "bg-muted/10 text-muted-foreground hover:text-green-400",
                      "only-out": dirFilter === f ? "bg-red-950/60 text-red-400 font-semibold" : "bg-muted/10 text-muted-foreground hover:text-red-400",
                    };
                    return (
                      <button
                        key={f}
                        onClick={() => setDirFilter(f)}
                        className={`px-2.5 py-1.5 transition-colors border-r last:border-r-0 border-border/40 ${colors[f]}`}
                      >
                        {labels[f]}
                      </button>
                    );
                  })}
                </div>
              )}

              <button
                onClick={() => setGroupByCounterparty((v) => !v)}
                className={`flex items-center gap-1.5 text-xs font-mono px-3 py-1.5 rounded border transition-colors ${
                  groupByCounterparty
                    ? "bg-primary/20 text-primary border-primary/40"
                    : "bg-muted/20 text-muted-foreground border-border/40 hover:border-primary/30 hover:text-primary"
                }`}
              >
                <Users className="w-3 h-3" />
                GROUP BY COUNTERPARTY
              </button>
              <div className="text-right">
                <div className="text-xs font-mono text-muted-foreground">
                  {txLoading ? "LOADING..." : groupByCounterparty
                    ? `${groupedRows.length} COUNTERPARTY ROWS`
                    : `${filteredTxs.length} TXS`}
                </div>
                <div className="flex gap-3 mt-0.5 text-xs font-mono justify-end">
                  <span className="text-green-400">↓ {inCount} IN</span>
                  <span className="text-red-400">↑ {outCount} OUT</span>
                </div>
              </div>
            </div>
          </div>

          {/* ── Group sort controls — only visible when Group By Counterparty is ON ── */}
          {groupByCounterparty && (
            <div className="flex items-center gap-2.5 pt-3 mt-1 border-t border-border/30 flex-wrap">
              <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider whitespace-nowrap">Sort Counterparties:</span>
              <div className="flex items-center rounded border border-border/40 overflow-hidden text-[10px] font-mono flex-wrap">
                {(["most-txs", "highest-value", "recent", "exchange-first"] as const).map((key) => {
                  const label = {
                    "most-txs":       "⬆ MOST TXS",
                    "highest-value":  "💰 HIGHEST VALUE",
                    "recent":         "🕐 RECENT",
                    "exchange-first": "🏦 EXCHANGES FIRST",
                  }[key];
                  return (
                    <button
                      key={key}
                      onClick={() => setGroupSort(key)}
                      className={`px-3 py-1.5 border-r last:border-r-0 border-border/40 transition-colors whitespace-nowrap ${
                        groupSort === key
                          ? key === "exchange-first"
                            ? "bg-blue-900/40 text-blue-300 font-semibold"
                            : "bg-primary/20 text-primary font-semibold"
                          : "bg-muted/10 text-muted-foreground hover:text-primary hover:bg-muted/20"
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
              <span className="text-[10px] font-mono text-muted-foreground/50 hidden sm:inline">
                + {viewMode === "in-first" ? "IN first" : viewMode === "out-first" ? "OUT first" : "mixed order"}
              </span>
            </div>
          )}
        </CardHeader>

        {/* ── Archive gap warning banner (XLM only) ── */}
        {xlmArchiveWarning && !txLoading && (
          <div className="mx-4 mb-3 flex items-start gap-2.5 rounded border border-yellow-500/30 bg-yellow-950/20 px-3.5 py-2.5 text-xs font-mono">
            <AlertTriangle className="w-3.5 h-3.5 text-yellow-400/80 mt-0.5 shrink-0" />
            <span className="text-yellow-200/70 leading-relaxed">
              {xlmArchiveWarning}
              {xlmArchiveLink && (
                <>
                  {" "}
                  <a
                    href={xlmArchiveLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-yellow-400/90 hover:text-yellow-300 underline underline-offset-2 transition-colors whitespace-nowrap"
                  >
                    View full history on stellar.expert ↗
                  </a>
                </>
              )}
            </span>
          </div>
        )}

        <div className="overflow-x-auto">
          {groupByCounterparty ? (
            /* ── GROUPED BY (address + direction) VIEW ── */
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-border/40 text-xs font-mono text-muted-foreground bg-muted/10">
                  <th className="px-5 py-3 font-normal w-20">DIR</th>
                  <th className="px-5 py-3 font-normal">COUNTERPARTY</th>
                  <th className="px-5 py-3 font-normal">LABEL</th>
                  <th className="px-5 py-3 font-normal text-center">TXS</th>
                  <th className="px-5 py-3 font-normal text-right">TOTAL AMOUNT</th>
                  <th className="px-5 py-3 font-normal text-right">ASSET</th>
                  <th className="px-5 py-3 font-normal text-right">LAST SEEN</th>
                  <th className="px-5 py-3 font-normal"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/30">
                {txLoading ? (
                  chain === "xlm"
                    ? <tr><td colSpan={8} className="px-5 py-10 text-center text-muted-foreground font-mono text-sm">
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          SEARCHING PAST SPAM PAGES…
                        </div>
                      </td></tr>
                    : Array.from({ length: 5 }).map((_, i) => (
                        <tr key={i}><td colSpan={8} className="px-5 py-3"><div className="h-5 bg-muted/40 rounded animate-pulse" /></td></tr>
                      ))
                ) : groupedRows.length === 0 ? (
                  <tr><td colSpan={8} className="px-5 py-10 text-center text-muted-foreground font-mono text-sm">
                    {allTxs.length > 0
                      ? `ALL ${allTxs.length} TXS BELOW MIN AMOUNT (${minAmount} ${chain.toUpperCase()})`
                      : xlmMessage
                        ? <span className="flex flex-col items-center gap-2">
                            <span>NO TRANSACTIONS FOUND</span>
                            <span className="text-xs text-muted-foreground/70 font-mono normal-case">{xlmMessage}</span>
                            {xlmHistoryLink && <a href={xlmHistoryLink} target="_blank" rel="noopener noreferrer" className="text-xs text-primary/70 hover:text-primary underline underline-offset-2 transition-colors">View full history on stellar.expert ↗</a>}
                          </span>
                        : "NO TRANSACTIONS FOUND"
                    }
                  </td></tr>
                ) : (
                  groupedRows.map((row, idx) => {
                    const known = KNOWN_LABELS[row.address];
                    const saved = savedWallets.has(row.address);
                    const isSelected = selectedWallets.has(row.address);
                    return (
                      <tr key={`${row.address}:${row.direction}:${idx}`} className={`hover:bg-muted/10 transition-colors text-sm font-mono ${isSelected ? "bg-yellow-950/25 border-l-2 border-yellow-500/50" : known ? "bg-muted/5" : ""}`}>
                        <td className="px-5 py-3">
                          {row.direction === "in" ? (
                            <span className="inline-flex items-center gap-1 text-green-400 bg-green-950/40 border border-green-500/20 px-2 py-0.5 rounded text-xs"><ArrowDownLeft className="w-3 h-3" /> IN</span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-red-400 bg-red-950/40 border border-red-500/20 px-2 py-0.5 rounded text-xs"><ArrowUpRight className="w-3 h-3" /> OUT</span>
                          )}
                        </td>
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const rect = e.currentTarget.getBoundingClientRect();
                                setActiveMenu({ addr: row.address, x: rect.left, y: rect.bottom + 4 });
                              }}
                              className="text-primary/80 hover:text-primary text-xs hover:underline font-mono"
                            >
                              {row.address.length > 16 ? `${row.address.slice(0, 10)}…${row.address.slice(-4)}` : row.address}
                            </button>
                            {saved && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                            <a
                              href={WALLET_EXPLORER_MAP[chain]?.(row.address) ?? "#"}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="text-muted-foreground hover:text-primary transition-colors"
                            >
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </div>
                        </td>
                        <td className="px-5 py-3">
                          {known ? getKnownBadge(known, "lg") : <span className="text-muted-foreground/30 text-xs font-mono">—</span>}
                        </td>
                        <td className="px-5 py-3 text-center text-muted-foreground">{row.txCount}</td>
                        <td className={`px-5 py-3 text-right text-xs ${row.direction === "in" ? "text-green-400" : "text-red-400"}`}>
                          {row.direction === "in" ? "+" : "−"}{row.totalValue.toFixed(4)}
                        </td>
                        <td className="px-5 py-3 text-right text-muted-foreground text-xs uppercase">{row.asset}</td>
                        <td className="px-5 py-3 text-right text-muted-foreground text-xs">
                          {row.latestTs ? new Date(row.latestTs).toLocaleDateString() : "—"}
                        </td>
                        <td className="px-5 py-3 text-right">
                          <div className="flex items-center gap-1.5 justify-end">
                            <button
                              onClick={(e) => { e.stopPropagation(); toggleSavedWallet(row.address); }}
                              className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors whitespace-nowrap flex items-center gap-1 ${
                                savedWallets.has(row.address)
                                  ? "text-yellow-300 border-yellow-400/60 bg-yellow-950/30 hover:bg-yellow-950/50"
                                  : "text-yellow-600 border-yellow-600/40 bg-yellow-950/10 hover:text-yellow-300 hover:border-yellow-400/60 hover:bg-yellow-950/30"
                              }`}
                              title={savedWallets.has(row.address) ? "Remove from Watchlist" : "Save to Watchlist"}
                            >
                              <Star className={`w-3 h-3 ${savedWallets.has(row.address) ? "fill-yellow-300 text-yellow-300" : "text-yellow-600"}`} />
                              {savedWallets.has(row.address) ? "SAVED" : "WATCHLIST"}
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); toggleTracked(row.address); }}
                              className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors whitespace-nowrap flex items-center gap-1 ${
                                multiWallets.includes(row.address)
                                  ? "text-sky-400 border-sky-500/40 bg-sky-950/20 hover:bg-sky-950/40"
                                  : "text-muted-foreground border-border/30 hover:text-sky-400 hover:border-sky-500/40"
                              }`}
                              title={multiWallets.includes(row.address) ? "Remove from Multi-Wallet Analysis" : "Add to Multi-Wallet Analysis"}
                            >
                              {multiWallets.includes(row.address)
                                ? <><BookmarkCheck className="w-3 h-3" /> TRACKED</>
                                : <><Bookmark className="w-3 h-3" /> TRACK</>}
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); toggleSelected(row.address); }}
                              className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors whitespace-nowrap flex items-center gap-1 ${
                                selectedWallets.has(row.address)
                                  ? "text-orange-300 border-orange-500/50 bg-orange-950/40 hover:bg-orange-950/60"
                                  : "text-muted-foreground border-border/30 hover:text-orange-300 hover:border-orange-500/40"
                              }`}
                              title={selectedWallets.has(row.address) ? "Deselect wallet" : "Select for report"}
                            >
                              <Flag className={`w-3 h-3 ${selectedWallets.has(row.address) ? "fill-orange-400 text-orange-400" : ""}`} />
                              {selectedWallets.has(row.address) ? "SELECTED" : "SELECT"}
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); addToCommingle(row.address); }}
                              className={`text-[10px] font-mono px-2 py-0.5 rounded border transition-colors whitespace-nowrap flex items-center gap-1 ${
                                commingleWallets.includes(row.address)
                                  ? "text-purple-400 border-purple-500/40 bg-purple-950/20 hover:bg-purple-950/40"
                                  : "text-muted-foreground border-border/30 hover:text-purple-400 hover:border-purple-500/40"
                              }`}
                              title={commingleWallets.includes(row.address) ? "In Commingle Check" : "Add to Commingle Check"}
                            >
                              <GitMerge className={`w-3 h-3 ${commingleWallets.includes(row.address) ? "text-purple-400" : ""}`} />
                              {commingleWallets.includes(row.address) ? "COMMINGLED" : "+ COMMINGLE"}
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); continueTrailOnWallet(row.address); }}
                              className="text-[10px] font-mono text-primary/60 hover:text-primary border border-primary/15 hover:border-primary/40 px-1.5 py-0.5 rounded transition-colors whitespace-nowrap"
                              title="Continue trail trace on this wallet"
                            >
                              ▶
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          ) : (
            /* ── INDIVIDUAL TX VIEW ── */
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-border/40 text-xs font-mono text-muted-foreground bg-muted/10">
                  <th className="px-5 py-3 font-normal w-20">DIR</th>
                  <th className="px-5 py-3 font-normal">TX HASH</th>
                  <th className="px-5 py-3 font-normal">TIMESTAMP</th>
                  <th className="px-5 py-3 font-normal">COUNTERPARTY</th>
                  <th className="px-5 py-3 font-normal text-right">AMOUNT</th>
                  <th className="px-5 py-3 font-normal text-right">ASSET</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/30">
                {txLoading ? (
                  chain === "xlm"
                    ? <tr><td colSpan={6} className="px-5 py-10 text-center text-muted-foreground font-mono text-sm">
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          SEARCHING PAST SPAM PAGES…
                        </div>
                      </td></tr>
                    : Array.from({ length: 8 }).map((_, i) => (
                        <tr key={i}><td colSpan={6} className="px-5 py-3"><div className="h-5 bg-muted/40 rounded animate-pulse" /></td></tr>
                      ))
                ) : filteredTxs.length === 0 ? (
                  <tr><td colSpan={6} className="px-5 py-12 text-center text-muted-foreground font-mono text-sm">
                    {allTxs.length > 0
                      ? `ALL ${allTxs.length} TXS BELOW MIN AMOUNT (${minAmount} ${chain.toUpperCase()})`
                      : xlmMessage
                        ? <span className="flex flex-col items-center gap-2">
                            <span>NO TRANSACTIONS FOUND</span>
                            <span className="text-xs text-muted-foreground/70 font-mono normal-case">{xlmMessage}</span>
                            {xlmHistoryLink && <a href={xlmHistoryLink} target="_blank" rel="noopener noreferrer" className="text-xs text-primary/70 hover:text-primary underline underline-offset-2 transition-colors">View full history on stellar.expert ↗</a>}
                          </span>
                        : "NO TRANSACTIONS FOUND"
                    }
                  </td></tr>
                ) : (
                  filteredTxs.map((tx, idx) => {
                    const counterparty = tx.direction === "in" ? tx.from : tx.to;
                    const isIn = tx.direction === "in";
                    const isOut = tx.direction === "out";
                    const val = parseFloat(tx.value);
                    return (
                      <tr key={tx.hash || idx} className="hover:bg-muted/10 transition-colors text-sm font-mono">
                        <td className="px-5 py-3">
                          {isIn ? (
                            <span className="inline-flex items-center gap-1 text-green-400 bg-green-950/40 border border-green-500/20 px-2 py-0.5 rounded text-xs font-bold">
                              <ArrowDownLeft className="w-3 h-3" /> IN
                            </span>
                          ) : isOut ? (
                            <span className="inline-flex items-center gap-1 text-red-400 bg-red-950/40 border border-red-500/20 px-2 py-0.5 rounded text-xs font-bold">
                              <ArrowUpRight className="w-3 h-3" /> OUT
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-muted-foreground bg-muted/40 border border-border/40 px-2 py-0.5 rounded text-xs">
                              <ArrowLeftRight className="w-3 h-3" /> SELF
                            </span>
                          )}
                        </td>
                        <td className="px-5 py-3">
                          {tx.hash ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-primary/80 text-xs">
                                {tx.hash.length > 12 ? `${tx.hash.slice(0, 8)}…${tx.hash.slice(-4)}` : tx.hash}
                              </span>
                              {explorerTxUrl && (
                                <a href={explorerTxUrl(tx.hash)} target="_blank" rel="noopener noreferrer"
                                  onClick={(e) => e.stopPropagation()} className="text-muted-foreground hover:text-primary">
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                          ) : <span className="text-muted-foreground text-xs">—</span>}
                          {tx.destinationTag != null && (
                            <div className="flex items-center gap-1 mt-1">
                              <span className="inline-flex items-center gap-1 text-xs font-mono font-bold text-cyan-200 bg-cyan-900/70 border border-cyan-400/50 px-2 py-0.5 rounded-md shadow-sm whitespace-nowrap">
                                🏷 TAG {tx.destinationTag}
                              </span>
                            </div>
                          )}
                          {tx.memo && (
                            <div className="flex items-center gap-1 mt-1 max-w-[200px]">
                              <span className="inline-flex items-center gap-1 text-xs font-mono text-amber-200 bg-amber-900/60 border border-amber-400/40 px-2 py-0.5 rounded-md shadow-sm truncate w-full" title={tx.memo}>
                                <MessageSquare className="w-3 h-3 shrink-0 text-amber-300" />
                                {tx.memo}
                              </span>
                            </div>
                          )}
                        </td>
                        <td className="px-5 py-3 text-muted-foreground text-xs">
                          {tx.timestamp ? new Date(tx.timestamp).toLocaleString(undefined, {
                            month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit",
                          }) : "—"}
                        </td>
                        <td className="px-5 py-3">{renderCounterpartyCell(counterparty ?? null, tx.direction)}</td>
                        <td className="px-5 py-3 text-right">
                          <div className={val > 0 ? isIn ? "text-green-400" : isOut ? "text-red-400" : "text-foreground" : "text-muted-foreground"}>
                            {isIn ? "+" : isOut ? "−" : ""}{tx.value}
                          </div>
                          {tx.valueUsd > 0 && <div className="text-xs text-muted-foreground mt-0.5">${tx.valueUsd.toLocaleString()}</div>}
                        </td>
                        <td className="px-5 py-3 text-right text-muted-foreground text-xs uppercase">
                          {tx.tokenSymbol || chain.toUpperCase()}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          )}
        </div>

        {/* ── Load More / Load All ── */}
        {page.current.error && !txLoading && (
          <div className="px-5 py-3 border-t border-border/40 bg-red-950/10 flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <span className="text-xs font-mono text-red-400">{page.current.error}</span>
              <span className="text-xs font-mono text-muted-foreground ml-2">— cursor preserved, click to retry</span>
            </div>
            <button
              onClick={() => { page.current.error = null; setAllTxs([...page.current.txs]); }}
              className="text-muted-foreground/40 hover:text-muted-foreground shrink-0"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}
        {page.current.hasMore && !txLoading && (
          <div className="px-5 py-4 border-t border-border/40 bg-muted/5">
            {allTxs.length >= 20000 && (
              <div className="mb-2.5 flex items-center gap-1.5 text-xs font-mono text-yellow-400">
                <AlertTriangle className="w-3 h-3" />
                {allTxs.length.toLocaleString()} transactions loaded — loading more may slow your browser.
              </div>
            )}
            <div className="flex items-center justify-between gap-4">
              <div className="flex flex-col gap-0.5">
                <span className="text-xs font-mono text-muted-foreground">
                  {allTxs.length.toLocaleString()} loaded · more available
                </span>
                {page.current.status && (
                  <span className="text-[10px] font-mono text-primary/70">{page.current.status}</span>
                )}
                {page.current.cursor && !page.current.busy && (
                  <span className="text-[10px] font-mono text-muted-foreground/40 break-all">
                    CURSOR: {page.current.cursor.length > 20
                      ? `${page.current.cursor.slice(0, 20)}…${page.current.cursor.slice(-8)}`
                      : page.current.cursor}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="font-mono text-xs"
                  disabled={page.current.busy}
                  onClick={loadMore}
                >
                  {page.current.busy
                    ? <><Loader2 className="w-3 h-3 mr-1.5 animate-spin" /> LOADING…</>
                    : loadMoreLabel}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="font-mono text-xs border-primary/30 text-primary hover:bg-primary/10"
                  disabled={page.current.busy}
                  onClick={loadAll}
                >
                  {page.current.busy
                    ? <><Loader2 className="w-3 h-3 mr-1.5 animate-spin" /> LOADING…</>
                    : "LOAD ALL (UP TO 25K)"}
                </Button>
              </div>
            </div>
          </div>
        )}
        {!page.current.hasMore && allTxs.length > 0 && !txLoading && (
          <div className="px-5 py-3 border-t border-border/40 text-center text-xs font-mono text-muted-foreground/60">
            FULL HISTORY LOADED · {allTxs.length.toLocaleString()} TRANSACTIONS
          </div>
        )}
      </Card>

      {/* ── Trail Trace Panel ── */}
      {showTrailPanel && (
        <Card ref={trailPanelRef} className="bg-card/40 border-border/40 border-primary/20">
          <CardHeader className="border-b border-border/40 pb-4 px-5 pt-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <CardTitle className="text-sm font-mono uppercase tracking-widest text-primary">
                  Trail Trace // Active
                </CardTitle>
                <span className="text-xs font-mono text-muted-foreground">
                  MAX DEPTH 5 · {trailEntries.length} NODES
                </span>
                {comminglingAddresses.size > 0 && (
                  <span className="flex items-center gap-1 text-xs font-mono text-yellow-400 bg-yellow-950/40 border border-yellow-500/20 px-2 py-0.5 rounded">
                    <AlertTriangle className="w-3 h-3" />
                    {comminglingAddresses.size} COMMINGLING DETECTED
                  </span>
                )}
              </div>
              <button
                onClick={() => {
                  const rpt = generateTrailReport();
                  const title = `Trail Trace Report — ${chain.toUpperCase()} — ${address.slice(0, 12)}`;
                  setReportContent(rpt);
                  setReportTitle(title);
                  setReportJsonData({ reportType: "trail", generatedAt: new Date().toISOString(), chain, subjectAddress: address, trailEntries, comminglingAddresses: [...comminglingAddresses], reportText: rpt });
                  setShowReportModal(true);
                }}
                className="flex items-center gap-1 text-[11px] font-mono text-orange-400 hover:text-orange-300 bg-orange-950/30 hover:bg-orange-950/60 border border-orange-500/30 rounded px-2 py-1 transition-colors"
              >
                <FileText className="w-3 h-3" /> TRAIL REPORT
              </button>
              <button onClick={() => setShowTrailPanel(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-center gap-4 mt-3 text-[10px] font-mono text-muted-foreground">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-primary inline-block" /> Target</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500 inline-block" /> Exchange</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-500 inline-block" /> Commingling</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-muted-foreground inline-block" /> Standard Wallet</span>
            </div>
          </CardHeader>

          {/* ── Analysis Sections ─────────────────────────────────────── */}
          {intersectionData && !trailEntries[0]?.isLoading && trailEntries.length > 1 && (
            <div className="divide-y divide-border/20 border-b border-border/30">

              {/* ── § 1 Direct Intersections ──────────────────────────────── */}
              <div className="p-4">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="w-1.5 h-4 bg-green-500 rounded-sm shrink-0" />
                  <span className="text-[10px] font-mono text-green-400 font-bold tracking-widest uppercase">
                    § 1 — Direct Intersections
                  </span>
                  <span className="text-[10px] font-mono text-muted-foreground">
                    {intersectionData.directIntersections.length > 0
                      ? `${intersectionData.directIntersections.length} wallet${intersectionData.directIntersections.length > 1 ? "s" : ""} found in both trail + tx history`
                      : "none found"}
                  </span>
                  {intersectionData.totalTxsLoaded === 0 && (
                    <span className="text-[10px] font-mono text-yellow-400 bg-yellow-950/30 px-1.5 py-0.5 rounded border border-yellow-500/20">
                      load transactions first
                    </span>
                  )}
                </div>
                {intersectionData.directIntersections.length === 0 ? (
                  <p className="text-[11px] font-mono text-muted-foreground/40 pl-3 leading-relaxed">
                    A direct intersection means a wallet appears in both this address's transaction history AND the connection graph.
                    Expand more trail nodes and load more transactions to surface them.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {intersectionData.directIntersections.map((d, i) => (
                      <div key={d.address} className="bg-green-950/20 border border-green-500/20 rounded p-3">
                        <div className="flex items-center gap-2 flex-wrap mb-2">
                          <span className="text-[10px] font-mono bg-green-900/60 text-green-300 px-1.5 py-0.5 rounded font-bold shrink-0">
                            #{i + 1}
                          </span>
                          <button
                            onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: d.address, x: r.left, y: r.bottom + 4 }); }}
                            className="text-primary/80 hover:text-primary text-xs font-mono hover:underline transition-colors"
                          >
                            {d.address.length > 16 ? `${d.address.slice(0, 8)}…${d.address.slice(-6)}` : d.address}
                          </button>
                          {d.knownInfo && getKnownBadge(d.knownInfo)}
                          {savedWallets.has(d.address) && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                          <span className="ml-auto text-[10px] font-mono text-muted-foreground shrink-0">TRAIL DEPTH {d.depth}</span>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-6 gap-y-1 text-[10px] font-mono pl-1">
                          <div><span className="text-muted-foreground">TXS </span><span className="text-green-300 font-bold">{d.cp.txCount}</span></div>
                          <div><span className="text-muted-foreground">TOTAL </span><span className="text-foreground font-bold">{d.cp.totalValue.toFixed(4)} {chain.toUpperCase()}</span></div>
                          <div><span className="text-muted-foreground">FIRST </span><span className="text-foreground">{d.cp.firstTs.slice(0, 10)}</span></div>
                          <div><span className="text-muted-foreground">LAST </span><span className="text-foreground">{d.cp.lastTs.slice(0, 10)}</span></div>
                        </div>
                        {d.cp.sampleHash && (
                          <div className="text-[10px] font-mono text-muted-foreground/60 mt-1.5 flex items-center gap-1.5 flex-wrap pl-1">
                            <span>SAMPLE TX:</span>
                            <span className="text-primary/60">{d.cp.sampleHash.slice(0, 16)}…</span>
                            {explorerTxUrl && (
                              <a href={explorerTxUrl(d.cp.sampleHash)} target="_blank" rel="noopener noreferrer"
                                className="text-muted-foreground hover:text-primary transition-colors">
                                <ExternalLink className="w-2.5 h-2.5" />
                              </a>
                            )}
                            <span className="text-muted-foreground/40">{d.cp.sampleDate.slice(0, 16).replace("T", " ")} UTC</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* ── § 2 Common Endpoints ──────────────────────────────────── */}
              <div className="p-4">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="w-1.5 h-4 bg-orange-500 rounded-sm shrink-0" />
                  <span className="text-[10px] font-mono text-orange-400 font-bold tracking-widest uppercase">
                    § 2 — Common Endpoints
                  </span>
                  <span className="text-[10px] font-mono text-muted-foreground">
                    {intersectionData.commonEndpoints.length > 0
                      ? `${intersectionData.commonEndpoints.length} wallet${intersectionData.commonEndpoints.length > 1 ? "s" : ""} reachable via multiple paths — potential commingling`
                      : "none detected"}
                  </span>
                </div>
                {intersectionData.commonEndpoints.length === 0 ? (
                  <p className="text-[11px] font-mono text-muted-foreground/40 pl-3 leading-relaxed">
                    Expand more trail nodes to detect wallets reachable from multiple independent paths — a classic indicator of fund commingling or round-tripping.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {intersectionData.commonEndpoints.map((ep, i) => (
                      <div key={ep.address} className="bg-orange-950/20 border border-orange-500/30 rounded p-3">
                        <div className="flex items-center gap-2 flex-wrap mb-1.5">
                          <span className="text-[10px] font-mono bg-orange-900/60 text-orange-300 px-1.5 py-0.5 rounded font-bold shrink-0">
                            #{i + 1}
                          </span>
                          <AlertTriangle className="w-3 h-3 text-orange-400 shrink-0" />
                          <button
                            onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: ep.address, x: r.left, y: r.bottom + 4 }); }}
                            className="text-primary/80 hover:text-primary text-xs font-mono hover:underline transition-colors"
                          >
                            {ep.address.length > 16 ? `${ep.address.slice(0, 8)}…${ep.address.slice(-6)}` : ep.address}
                          </button>
                          {ep.trailEntry?.knownInfo && getKnownBadge(ep.trailEntry.knownInfo)}
                          <span className="text-[10px] font-mono text-orange-400 font-bold ml-auto shrink-0">{ep.parents.length} PATHS CONVERGE</span>
                        </div>
                        <div className="text-[10px] font-mono text-muted-foreground pl-1 flex flex-wrap gap-1 items-center">
                          <span className="text-muted-foreground/50">VIA:</span>
                          {ep.parents.map((p, pi) => (
                            <span key={p} className="flex items-center gap-1">
                              <button
                                onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: p, x: r.left, y: r.bottom + 4 }); }}
                                className="text-primary/60 hover:text-primary hover:underline font-mono transition-colors"
                              >
                                {p.length > 12 ? `${p.slice(0, 6)}…${p.slice(-4)}` : p}
                              </button>
                              {pi < ep.parents.length - 1 && <span className="text-muted-foreground/30">·</span>}
                            </span>
                          ))}
                        </div>
                        {ep.cpData && (
                          <div className="grid grid-cols-2 gap-x-6 text-[10px] font-mono mt-1.5 pl-1">
                            <div><span className="text-muted-foreground">TXS </span><span className="text-foreground">{ep.cpData.txCount}</span></div>
                            <div><span className="text-muted-foreground">TOTAL </span><span className="text-foreground">{ep.cpData.totalValue.toFixed(4)} {chain.toUpperCase()}</span></div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* ── § 3 Numbered Trail Paths ──────────────────────────────── */}
              <div className="p-4">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="w-1.5 h-4 bg-primary rounded-sm shrink-0" />
                  <span className="text-[10px] font-mono text-primary font-bold tracking-widest uppercase">
                    § 3 — Trail Paths
                  </span>
                  <span className="text-[10px] font-mono text-muted-foreground">
                    {intersectionData.paths.length} path{intersectionData.paths.length !== 1 ? "s" : ""} · ⚡ intersection · ⚠ commingling
                  </span>
                </div>
                <div className="space-y-1.5">
                  {intersectionData.paths.map((path, pi) => (
                    <div key={pi} className="flex items-start gap-2 flex-wrap text-[10px] font-mono">
                      <span className="text-muted-foreground/40 shrink-0 w-5 text-right mt-0.5">#{pi + 1}</span>
                      <div className="flex items-center gap-1 flex-wrap">
                        {path.map((addr, ai) => {
                          const isInt = intersectionData.intersectionAddrs.has(addr);
                          const isComEP = intersectionData.commonEndpoints.some((c) => c.address === addr);
                          const isRoot = ai === 0;
                          const known = KNOWN_LABELS[addr];
                          const short = addr.length > 12 ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : addr;
                          return (
                            <span key={addr + ai} className="flex items-center gap-1">
                              {ai > 0 && <span className="text-muted-foreground/25">→</span>}
                              <button
                                onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr, x: r.left, y: r.bottom + 4 }); }}
                                className={`px-1.5 py-0.5 rounded border transition-colors ${
                                  isRoot
                                    ? "bg-primary/20 text-primary border-primary/30"
                                    : isInt
                                    ? "bg-green-950/60 text-green-300 border-green-500/40 font-bold"
                                    : isComEP
                                    ? "bg-orange-950/60 text-orange-300 border-orange-500/40"
                                    : "text-muted-foreground hover:text-foreground border-transparent hover:border-border/30"
                                }`}
                              >
                                {isInt && <span className="mr-0.5">⚡</span>}
                                {isComEP && !isInt && <span className="mr-0.5">⚠</span>}
                                {known ? known.label : short}
                              </button>
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* ── § 4 Full Connection Tree (collapsible) ────────────────────── */}
          <button
            onClick={(e) => { e.stopPropagation(); setShowNodeTree((v) => !v); }}
            className="w-full flex items-center gap-2 px-4 py-2.5 text-[10px] font-mono text-muted-foreground hover:text-foreground border-b border-border/20 hover:bg-muted/10 transition-colors"
          >
            {showNodeTree ? <ChevronDown className="w-3 h-3 shrink-0" /> : <ChevronRight className="w-3 h-3 shrink-0" />}
            <span className="uppercase tracking-wider">§ 4 — Full Connection Tree</span>
            <span className="text-muted-foreground/40">{trailEntries.length} nodes · click to {showNodeTree ? "collapse" : "expand"}</span>
          </button>
          {showNodeTree && (
            <div className="p-4 space-y-1 max-h-[420px] overflow-y-auto">
              {trailEntries.map((entry) => {
                const isCommingling = comminglingAddresses.has(entry.address);
                const isExchange = entry.knownInfo?.type === "exchange" || entry.knownInfo?.type === "bridge";
                const isGenesis = entry.knownInfo?.type === "genesis";
                const isDagTeam = entry.knownInfo?.type === "dag-team";
                const isRoot = entry.depth === 0;

                let dotColor = "bg-muted-foreground";
                if (isRoot) dotColor = "bg-primary";
                else if (isExchange) dotColor = "bg-blue-500";
                else if (isDagTeam) dotColor = "bg-orange-500";
                else if (isGenesis) dotColor = "bg-purple-500";
                else if (isCommingling) dotColor = "bg-yellow-500";
                else if (intersectionData?.intersectionAddrs.has(entry.address)) dotColor = "bg-green-500";

                let rowBg = "hover:bg-muted/10";
                if (isCommingling) rowBg = "bg-yellow-950/20 hover:bg-yellow-950/30 border-l-2 border-yellow-500/40";
                else if (intersectionData?.intersectionAddrs.has(entry.address)) rowBg = "bg-green-950/20 hover:bg-green-950/30 border-l-2 border-green-500/40";
                else if (isExchange) rowBg = "bg-blue-950/10 hover:bg-blue-950/20";
                else if (isDagTeam) rowBg = "bg-orange-950/10 hover:bg-orange-950/20 border-l-2 border-orange-500/30";
                else if (isRoot) rowBg = "bg-primary/5 border-l-2 border-primary/40";

                return (
                  <div
                    key={`${entry.address}-${entry.depth}-${entry.parentAddress}`}
                    className={`flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-colors ${rowBg}`}
                    style={{ paddingLeft: `${12 + entry.depth * 20}px` }}
                  >
                    {entry.depth > 0 && (
                      <span className="text-border/60 shrink-0">{"└─"}</span>
                    )}
                    <span className={`w-2 h-2 rounded-full shrink-0 ${dotColor} ${entry.isLoading ? "animate-pulse" : ""}`} />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const rect = e.currentTarget.getBoundingClientRect();
                        setActiveMenu({ addr: entry.address, x: rect.left, y: rect.bottom + 4 });
                      }}
                      className="text-primary/80 hover:text-primary hover:underline transition-colors truncate max-w-[200px]"
                    >
                      {entry.address.length > 20 ? `${entry.address.slice(0, 10)}…${entry.address.slice(-6)}` : entry.address}
                    </button>
                    {entry.knownInfo && getKnownBadge(entry.knownInfo)}
                    {savedWallets.has(entry.address) && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                    {intersectionData?.intersectionAddrs.has(entry.address) && (
                      <span className="flex items-center gap-1 text-green-400 bg-green-950/40 px-1.5 py-0.5 rounded border border-green-500/20 text-[10px]">
                        ⚡ INTERSECTION
                      </span>
                    )}
                    {isCommingling && !intersectionData?.intersectionAddrs.has(entry.address) && (
                      <span className="flex items-center gap-1 text-yellow-400 bg-yellow-950/40 px-1.5 py-0.5 rounded border border-yellow-500/20 text-[10px]">
                        <AlertTriangle className="w-2.5 h-2.5" /> COMMINGLING
                      </span>
                    )}
                    <span className="text-muted-foreground/60 shrink-0">D{entry.depth}</span>
                    {entry.totalValueUsd > 0 && (
                      <span className="text-muted-foreground shrink-0">${entry.totalValueUsd.toFixed(0)}</span>
                    )}
                    {entry.txCount > 0 && (
                      <span className="text-muted-foreground/60 shrink-0">{entry.txCount} tx</span>
                    )}
                    {entry.error && <span className="text-red-400 text-[10px]">FETCH FAILED</span>}
                    {entry.isLoading && <Loader2 className="w-3 h-3 text-primary animate-spin shrink-0" />}
                    {!entry.isLoading && !entry.isExpanded && !entry.error && entry.depth < 5 && (
                      <button
                        onClick={(e) => { e.stopPropagation(); expandTrailNode(entry); }}
                        className="ml-auto shrink-0 flex items-center gap-1 text-[10px] text-primary/60 hover:text-primary border border-primary/20 hover:border-primary/50 px-1.5 py-0.5 rounded transition-colors"
                      >
                        <ChevronRight className="w-2.5 h-2.5" /> EXPAND
                      </button>
                    )}
                    {entry.isExpanded && entry.childAddresses.length > 0 && (
                      <span className="ml-auto shrink-0 flex items-center gap-1 text-[10px] text-muted-foreground">
                        <ChevronDown className="w-2.5 h-2.5" /> {entry.childAddresses.length} peers
                      </span>
                    )}
                    {entry.isExpanded && entry.childAddresses.length === 0 && (
                      <span className="ml-auto shrink-0 text-[10px] text-muted-foreground/40">NO CONNECTIONS</span>
                    )}
                    {entry.depth >= 5 && (
                      <span className="ml-auto shrink-0 flex items-center gap-1 text-[10px] text-muted-foreground/40">
                        <Zap className="w-2.5 h-2.5" /> MAX DEPTH
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      )}
      {/* ── Origin Trace Panel ── */}
      {showOriginPanel && (
        <Card ref={originPanelRef} className="bg-card/40 border-border/40 border-cyan-500/20 shadow-lg shadow-cyan-500/5">
          {/* Header */}
          <CardHeader className="border-b border-border/40 pb-4 px-5 pt-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full bg-cyan-400 ${originLoading ? "animate-pulse" : ""}`} />
                <CardTitle className="text-sm font-mono uppercase tracking-widest text-cyan-300">
                  Trace to Origin
                </CardTitle>
                {originHops.length > 1 && (
                  <span className="text-xs font-mono text-muted-foreground">
                    {originHops.length - 1} hop{originHops.length !== 2 ? "s" : ""}{!originLoading && " · complete"}
                  </span>
                )}
              </div>
              <button onClick={() => setShowOriginPanel(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs font-mono text-muted-foreground mt-1.5 leading-relaxed">
              Follows the highest-value incoming transaction at each hop backwards to uncover the original source of funds.
            </p>
          </CardHeader>

          {/* Mode selector — shown before trace starts */}
          {originHops.length === 0 && !originLoading && (
            <div className="p-5 space-y-4">
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Select Trace Mode</div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setOriginMode("standard")}
                  className={`p-3.5 rounded-lg border text-left transition-colors ${
                    originMode === "standard"
                      ? "border-cyan-500/50 bg-cyan-950/30 text-cyan-300"
                      : "border-border/40 bg-muted/10 text-muted-foreground hover:border-cyan-500/30 hover:text-cyan-400"
                  }`}
                >
                  <div className="text-xs font-mono font-bold mb-1">STANDARD</div>
                  <div className="text-[10px] font-mono opacity-80">Up to 30 hops · ~5–15 sec</div>
                </button>
                <button
                  onClick={() => setOriginMode("deep")}
                  className={`p-3.5 rounded-lg border text-left transition-colors ${
                    originMode === "deep"
                      ? "border-orange-500/50 bg-orange-950/30 text-orange-300"
                      : "border-border/40 bg-muted/10 text-muted-foreground hover:border-orange-500/30 hover:text-orange-400"
                  }`}
                >
                  <div className="text-xs font-mono font-bold mb-1 flex items-center gap-1.5">
                    DEEP ORIGIN TRACE
                    {originMode === "deep" && <AlertTriangle className="w-3 h-3 text-orange-400 shrink-0" />}
                  </div>
                  <div className="text-[10px] font-mono opacity-80">Up to 75 hops</div>
                  <div className="text-[10px] font-mono text-orange-400/80">⚠ May take 20–60 sec · more resources</div>
                </button>
              </div>
              <button
                onClick={() => void startOriginTrace()}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-cyan-700 hover:bg-cyan-600 active:bg-cyan-800 text-white font-mono text-xs font-bold tracking-widest transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> START ORIGIN TRACE
              </button>
            </div>
          )}

          {/* Status bar — shown while loading */}
          {originLoading && (
            <div className="px-5 py-2.5 flex items-center gap-3 border-b border-border/30 bg-cyan-950/10">
              <Loader2 className="w-3 h-3 text-cyan-400 animate-spin shrink-0" />
              <span className="text-[11px] font-mono text-cyan-300/80 flex-1 truncate">{originStatus}</span>
              <button
                onClick={() => { originAbortRef.current = true; }}
                className="text-[10px] font-mono text-muted-foreground hover:text-red-400 border border-border/30 hover:border-red-500/40 px-2 py-0.5 rounded transition-colors shrink-0"
              >
                STOP
              </button>
            </div>
          )}

          {/* Hop list */}
          {originHops.length > 0 && (
            <div className="divide-y divide-border/20">
              {originHops.map((hop) => {
                const isRoot     = hop.hop === 0;
                const isExchange = hop.stopReason === "exchange";
                const isDeadEnd  = hop.stopReason === "dead-end";
                const isLoop     = hop.stopReason === "loop";
                const isMaxHops  = hop.stopReason === "max-hops";
                const fmtTs = (ts: string) => {
                  if (!ts) return "";
                  const d = new Date(ts);
                  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
                    + " " + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
                };
                const shortA = (a: string) => a.length > 20 ? `${a.slice(0, 10)}…${a.slice(-4)}` : a;
                let rowBg = "hover:bg-muted/5";
                if (isRoot)     rowBg = "bg-cyan-950/10";
                if (isExchange) rowBg = "bg-blue-950/20 border-l-2 border-blue-400/50";
                if (isDeadEnd)  rowBg = "bg-yellow-950/10 border-l-2 border-yellow-500/20";
                if (isLoop)     rowBg = "bg-orange-950/10 border-l-2 border-orange-500/20";
                return (
                  <div key={hop.hop} className={`px-5 py-3 transition-colors ${rowBg}`}>
                    {/* Main row */}
                    <div className="flex items-start gap-2.5 flex-wrap">
                      {/* Hop number */}
                      <span className="text-[10px] font-mono text-muted-foreground/40 w-11 shrink-0 pt-0.5 tabular-nums">
                        {String(hop.hop).padStart(2, "0")}
                      </span>
                      {/* Direction badge */}
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border shrink-0 ${
                        isRoot
                          ? "bg-cyan-950/50 text-cyan-300 border-cyan-500/40"
                          : "bg-green-950/40 text-green-400 border-green-500/20"
                      }`}>
                        {isRoot ? "TARGET" : "← IN"}
                      </span>
                      {/* Address + badges + amount + date */}
                      <div className="flex items-center gap-2 flex-wrap flex-1 min-w-0">
                        {hop.isLoading ? (
                          <span className="text-[11px] font-mono text-muted-foreground animate-pulse">scanning…</span>
                        ) : (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const rect = e.currentTarget.getBoundingClientRect();
                                setActiveMenu({ addr: hop.address, x: rect.left, y: rect.bottom + 4 });
                              }}
                              className="text-xs font-mono text-primary/80 hover:text-primary hover:underline transition-colors"
                              title={hop.address}
                            >
                              {shortA(hop.address)}
                            </button>
                            {hop.knownInfo && getKnownBadge(hop.knownInfo)}
                            {savedWallets.has(hop.address) && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                            {WALLET_EXPLORER_MAP[chain] && (
                              <a
                                href={WALLET_EXPLORER_MAP[chain](hop.address)}
                                target="_blank" rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="text-muted-foreground hover:text-primary transition-colors"
                              >
                                <ExternalLink className="w-2.5 h-2.5" />
                              </a>
                            )}
                          </>
                        )}
                        {!isRoot && hop.txAmount && (
                          <span className="text-green-400 text-xs font-mono font-bold ml-1">
                            +{parseFloat(hop.txAmount).toFixed(4)} {hop.txAsset}
                          </span>
                        )}
                        {!isRoot && hop.txTimestamp && (
                          <span className="text-muted-foreground text-[10px] font-mono">{fmtTs(hop.txTimestamp)}</span>
                        )}
                      </div>
                    </div>

                    {/* TX hash + memo/tag sub-line */}
                    {!isRoot && !hop.isLoading && (hop.txHash || hop.txMemo || hop.txDestinationTag != null) && (
                      <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1 pl-[3.5rem] text-[10px] font-mono text-muted-foreground/50">
                        {hop.txHash && (
                          <span className="flex items-center gap-1">
                            TA: {hop.txHash.length > 12 ? `${hop.txHash.slice(0, 10)}…` : hop.txHash}
                            {explorerTxUrl && (
                              <a href={explorerTxUrl(hop.txHash)} target="_blank" rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="text-muted-foreground hover:text-primary transition-colors ml-0.5">
                                <ExternalLink className="w-2 h-2" />
                              </a>
                            )}
                          </span>
                        )}
                        {hop.txDestinationTag != null && (
                          <span className="text-cyan-300/60">Destination Tag: {hop.txDestinationTag}</span>
                        )}
                        {hop.txMemo && (
                          <span className="text-amber-300/60">Memo: {hop.txMemo}</span>
                        )}
                      </div>
                    )}

                    {/* Error */}
                    {hop.error && (
                      <div className="mt-1.5 pl-[3.5rem] flex items-center gap-1.5 text-[10px] font-mono text-red-400">
                        <AlertTriangle className="w-2.5 h-2.5 shrink-0" /> {hop.error}
                      </div>
                    )}

                    {/* Stop-reason banners */}
                    {isExchange && (
                      <div className="mt-2 pl-[3.5rem]">
                        <span className="inline-flex items-center gap-2 text-[11px] font-mono text-blue-100 bg-blue-900/50 border border-blue-400/40 px-3 py-1.5 rounded-lg font-bold shadow-sm">
                          🏦 EXCHANGE REACHED — Funds entered the network via a custodial exchange. Origin tracing complete.
                        </span>
                      </div>
                    )}
                    {isDeadEnd && (
                      <div className="mt-2 pl-[3.5rem]">
                        <span className="inline-flex items-center gap-2 text-[11px] font-mono text-yellow-200 bg-yellow-950/40 border border-yellow-500/30 px-3 py-1.5 rounded-lg">
                          ⚠ DEAD END — No incoming transactions found. This may be the original source wallet.
                        </span>
                      </div>
                    )}
                    {isLoop && (
                      <div className="mt-2 pl-[3.5rem]">
                        <span className="inline-flex items-center gap-2 text-[11px] font-mono text-orange-200 bg-orange-950/40 border border-orange-500/30 px-3 py-1.5 rounded-lg">
                          🔄 CIRCULAR — This address already appeared earlier in the chain. Stopping to prevent loop.
                        </span>
                      </div>
                    )}
                    {isMaxHops && (
                      <div className="mt-2 pl-[3.5rem]">
                        <span className="inline-flex items-center gap-2 text-[11px] font-mono text-muted-foreground bg-muted/20 border border-border/40 px-3 py-1.5 rounded-lg">
                          ⏹ MAX DEPTH REACHED ({originMode === "deep" ? "75" : "30"} hops){originMode === "standard" ? " — switch to Deep Origin Trace for deeper analysis" : ""}.
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Footer: reconfigure / retrace */}
              {!originLoading && originHops.length > 0 && (
                <div className="px-5 py-3 flex items-center justify-between gap-3 bg-muted/5">
                  <span className="text-[10px] font-mono text-muted-foreground/50 shrink-0">
                    {originHops.length - 1} hop{originHops.length !== 2 ? "s" : ""} · {originMode === "deep" ? "DEEP (75 max)" : "STANDARD (30 max)"}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setOriginHops([])}
                      className="text-[10px] font-mono text-muted-foreground hover:text-foreground border border-border/30 hover:border-border/60 px-2.5 py-1 rounded transition-colors whitespace-nowrap"
                    >
                      RECONFIGURE
                    </button>
                    <button
                      onClick={() => void startOriginTrace()}
                      disabled={originLoading}
                      className="text-[10px] font-mono text-cyan-400 hover:text-cyan-300 border border-cyan-500/30 hover:border-cyan-500/60 bg-cyan-950/20 hover:bg-cyan-950/40 px-2.5 py-1 rounded transition-colors whitespace-nowrap disabled:opacity-50"
                    >
                      RETRACE
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>
      )}

      {/* ── Multi-Wallet Commingling Analysis Panel ── */}
      {showMultiPanel && (
        <Card ref={multiPanelRef} className="bg-card/40 border-violet-500/30 shadow-lg shadow-violet-500/5">
          <CardHeader className="border-b border-border/40 pb-4 px-5 pt-5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
                <CardTitle className="text-sm font-mono uppercase tracking-widest text-violet-300">
                  Intersection / Funnel Analysis
                </CardTitle>
                {multiResult && (
                  <span className="text-xs font-mono text-muted-foreground">
                    {multiResult.trackedWallets.length} wallets · {multiResult.sharedCounterparties.length + multiResult.commonEndpoints.length} shared nodes
                  </span>
                )}
              </div>
              <button onClick={() => setShowMultiPanel(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs font-mono text-muted-foreground mt-1.5 leading-relaxed">
              Deep convergence detection: maps up to depth-4 connections for every tracked wallet and surfaces shared private intermediaries, common funneling hubs, and exchange outflows — private/exchange strictly separated. Click{" "}
              <span className="text-yellow-400 font-bold">TRACK</span>
              {" "}on any counterparty row to add wallets here — or paste addresses manually.
            </p>

            {/* ── Tracked Wallet List ── */}
            <div className="mt-4 space-y-2.5">
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Tracked Wallets</div>

              {/* Primary wallet (always included) */}
              {(() => { const c = WALLET_COLORS[0]; return (
                <div className={`flex items-center gap-2.5 ${c.bg} border ${c.border} rounded-lg px-3 py-2`}>
                  <div className={`w-2 h-2 rounded-full ${c.dot} shrink-0`} />
                  <span className={`text-xs font-mono ${c.text} flex-1 truncate min-w-0`}>{address}</span>
                  <span className="text-[10px] font-mono text-muted-foreground/60 shrink-0 uppercase">Primary</span>
                  {getKnownInfo(address, chain) && <span className="shrink-0">{getKnownBadge(getKnownInfo(address, chain)!)}</span>}
                </div>
              ); })()}

              {/* Additional wallets */}
              {multiWallets.map((w, i) => {
                const c = WALLET_COLORS[(i + 1) % WALLET_COLORS.length];
                return (
                  <div key={w} className={`flex items-center gap-2.5 ${c.bg} border ${c.border} rounded-lg px-3 py-2`}>
                    <div className={`w-2 h-2 rounded-full ${c.dot} shrink-0`} />
                    <span className={`text-xs font-mono ${c.text} flex-1 truncate min-w-0`}>{w}</span>
                    <span className="text-[10px] font-mono text-muted-foreground/60 shrink-0">Wallet {i + 2}</span>
                    {getKnownInfo(w, chain) && <span className="shrink-0">{getKnownBadge(getKnownInfo(w, chain)!)}</span>}
                    <button
                      onClick={() => setMultiWallets((prev) => prev.filter((_, j) => j !== i))}
                      className="text-muted-foreground/60 hover:text-red-400 transition-colors shrink-0 ml-1"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}

              {/* Add wallet input */}
              {true && (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={multiWalletInput}
                    onChange={(e) => setMultiWalletInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && multiWalletInput.trim() && !multiWallets.includes(multiWalletInput.trim())) {
                        setMultiWallets((prev) => [...prev, multiWalletInput.trim()]);
                        setMultiWalletInput("");
                      }
                    }}
                    placeholder="Paste additional wallet address…"
                    className="flex-1 bg-muted/20 border border-border/40 focus:border-violet-500/50 rounded-lg px-3 py-2 text-xs font-mono text-foreground placeholder:text-muted-foreground/40 outline-none transition-colors"
                  />
                  <button
                    onClick={() => {
                      const trimmed = multiWalletInput.trim();
                      if (trimmed && !multiWallets.includes(trimmed)) {
                        setMultiWallets((prev) => [...prev, trimmed]);
                        setMultiWalletInput("");
                      }
                    }}
                    disabled={!multiWalletInput.trim()}
                    className="px-3 py-2 rounded-lg bg-violet-900/60 border border-violet-500/40 text-violet-300 hover:bg-violet-900/80 disabled:opacity-40 transition-colors shrink-0"
                    title="Add wallet"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Load from Commingle List */}
              <button
                onClick={() => {
                  if (commingleWallets.length === 0) {
                    setMultiError("Commingle list is empty — add wallets first.");
                    return;
                  }
                  const toAdd = commingleWallets.filter(
                    (w) => w !== address && !multiWallets.includes(w)
                  );
                  if (toAdd.length === 0) {
                    setMultiError("All Commingle wallets are already in the list.");
                    return;
                  }
                  setMultiError(null);
                  setMultiWallets((prev) => Array.from(new Set([...prev, ...toAdd])));
                  setMultiNotice(`✅ Loaded ${toAdd.length} wallet${toAdd.length === 1 ? "" : "s"} from Commingle list`);
                  setTimeout(() => setMultiNotice(null), 4000);
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-mono text-xs font-bold tracking-widest transition-colors"
              >
                <GitMerge className="w-3.5 h-3.5 shrink-0" />
                LOAD FROM COMMINGLE LIST
                {commingleWallets.length > 0 && (
                  <span className="opacity-70 text-[10px] font-normal">({commingleWallets.length} wallets)</span>
                )}
              </button>

              {/* Analyze button */}
              <button
                onClick={() => runMultiAnalysis()}
                disabled={multiLoading || multiWallets.length === 0}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-violet-600 hover:bg-violet-500 active:bg-violet-700 disabled:bg-muted/30 disabled:text-muted-foreground/60 text-white font-mono text-xs font-bold tracking-widest transition-colors mt-1"
              >
                {multiLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                    <span>ANALYZING…</span>
                    {multiProgress && <span className="opacity-60 truncate max-w-[240px] font-normal">{multiProgress}</span>}
                  </>
                ) : (
                  <><GitMerge className="w-3.5 h-3.5" /> RUN INTERSECTION ANALYSIS</>
                )}
              </button>
              {multiError && (
                <p className="text-xs font-mono text-red-400 flex items-center gap-1.5 mt-0.5">
                  <AlertTriangle className="w-3 h-3 shrink-0" /> {multiError}
                </p>
              )}
              {multiNotice && (
                <p className="text-xs font-mono text-sky-400 flex items-center gap-1.5 mt-0.5">
                  {multiNotice}
                </p>
              )}
            </div>
          </CardHeader>

          {multiResult && (
            <div className="divide-y divide-border/20">

              {/* ── Generate intersection report ── */}
              <div className="px-5 py-3 bg-violet-950/30 border-b border-violet-500/20 flex items-center justify-between gap-3">
                <div className="text-xs font-mono text-violet-300/80">
                  Analysis complete · {multiResult.trackedWallets.length} wallets · {multiResult.sharedCounterparties.length + multiResult.commonEndpoints.length} shared nodes found
                </div>
                <button
                  disabled={multiIntersectLoading}
                  onClick={async () => {
                    setMultiIntersectLoading(true);
                    try {
                      const allWallets = multiResult.trackedWallets;
                      const walletTxMap = new Map<string, Tx[]>();
                      // Primary wallet uses already-loaded allTxs
                      walletTxMap.set(allWallets[0], allTxs);
                      // Fetch TXs for each additional tracked wallet in parallel
                      await Promise.all(
                        allWallets.slice(1).map(async (w) => {
                          try {
                            const resp = await fetch(`/api/wallets/${encodeURIComponent(w)}/transactions?chain=${chain}&limit=200`);
                            walletTxMap.set(w, resp.ok ? ((await resp.json() as { transactions: Tx[] }).transactions ?? []) : []);
                          } catch { walletTxMap.set(w, []); }
                        })
                      );
                      // Also fetch TXs for every intermediate address found in pathChains.
                      // The BFS scan visits these nodes but discards their TXs — without
                      // fetching them here, findHopTx can only find direct wallet↔node TXs.
                      const intermediateAddrs = new Set<string>();
                      for (const entry of [...multiResult.sharedCounterparties, ...multiResult.commonEndpoints]) {
                        for (const app of entry.appearances) {
                          // pathChain = [trackedWallet, ...intermediates, convergenceNode]
                          // skip index 0 (tracked wallet — already in map)
                          for (let pi = 1; pi < app.pathChain.length; pi++) {
                            const a = app.pathChain[pi];
                            if (!walletTxMap.has(a)) intermediateAddrs.add(a);
                          }
                        }
                      }
                      // Cap at 80 intermediate addresses, 100 TXs each — covers deep Hop 2/Hop 3 paths
                      const intermediateList = Array.from(intermediateAddrs).slice(0, 80);
                      if (intermediateList.length > 0) {
                        await Promise.all(
                          intermediateList.map(async (addr) => {
                            try {
                              const resp = await fetch(`/api/wallets/${encodeURIComponent(addr)}/transactions?chain=${chain}&limit=100`);
                              walletTxMap.set(addr, resp.ok ? ((await resp.json() as { transactions: Tx[] }).transactions ?? []) : []);
                            } catch { walletTxMap.set(addr, []); }
                          })
                        );
                      }
                      const rpt = generateMultiReport(walletTxMap);
                      const title = `Intersection / Funnel Analysis — ${chain.toUpperCase()} — ${address.slice(0, 12)}`;
                      setReportContent(rpt);
                      setReportTitle(title);
                      setReportJsonData({ reportType: "multi-intersection", generatedAt: new Date().toISOString(), chain, trackedWallets: multiResult.trackedWallets, reportText: rpt });
                      setShowReportModal(true);
                    } finally {
                      setMultiIntersectLoading(false);
                    }
                  }}
                  className="flex items-center gap-1.5 text-[11px] font-mono font-bold text-white bg-violet-600 hover:bg-violet-500 border border-violet-500/50 rounded px-3 py-1.5 transition-colors shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <FileText className="w-3.5 h-3.5" /> {multiIntersectLoading ? "Fetching…" : "GENERATE INTERSECTION REPORT"}
                </button>
              </div>

              {/* ── Wallet legend ── */}
              <div className="px-5 py-3 flex items-center gap-4 flex-wrap bg-muted/5">
                <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Legend:</span>
                {multiResult.trackedWallets.map((w, i) => {
                  const c = WALLET_COLORS[i % WALLET_COLORS.length];
                  return (
                    <div key={w} className="flex items-center gap-1.5">
                      <div className={`w-2 h-2 rounded-full ${c.dot} shrink-0`} />
                      <span className={`text-[10px] font-mono ${c.text}`}>
                        {i === 0 ? "PRIMARY" : `W${i + 1}`}: {w.length > 18 ? `${w.slice(0, 10)}…${w.slice(-4)}` : w}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* ── § 1 Private Convergence Points  /  § 2 Exchange Flows ── */}
              {(() => {
                const EXCL2   = new Set(["DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz"]);
                const isExch2 = (a: string) => ["exchange","bridge","genesis"].includes(KNOWN_LABELS[a]?.type ?? "");
                const seen2   = new Set<string>();
                const allUniq2 = [...multiResult.sharedCounterparties, ...multiResult.commonEndpoints]
                  .filter(s => { if (seen2.has(s.address)) return false; seen2.add(s.address); return !EXCL2.has(s.address); });
                const privNodes = allUniq2.filter(s => !isExch2(s.address));
                return (
                  <>
                    {/* ── § 1 Private Convergence Points ── */}
                    <div className="p-5">
                      <div className="flex items-center gap-2 mb-3 flex-wrap">
                        <span className="w-1.5 h-4 bg-red-500 rounded-sm shrink-0" />
                        <span className="text-[10px] font-mono text-red-300 font-bold tracking-widest uppercase">§ 1 — Private Convergence Points</span>
                        <span className="text-[10px] font-mono text-muted-foreground">private wallets shared by 2+ tracked wallets</span>
                        <span className={`ml-auto text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${privNodes.length > 0 ? "bg-red-950/60 text-red-200 border-red-400/40" : "text-muted-foreground border-border/30"}`}>
                          {privNodes.length} found
                        </span>
                      </div>
                      {privNodes.length === 0 ? (
                        <p className="text-[11px] font-mono text-muted-foreground/40 pl-3 leading-relaxed">
                          No private convergence points found within depth-4. Try adding more wallets or loading additional TX history.
                        </p>
                      ) : (
                        <div className="space-y-2">
                          {privNodes.map((entry, i) => {
                            const kn     = entry.knownInfo ?? KNOWN_LABELS[entry.address];
                            const isTeam = kn?.type === "dag-team";
                            return (
                              <div key={entry.address} className={`border rounded-lg p-3 ${isTeam ? "bg-blue-950/15 border-blue-500/20" : "bg-red-950/10 border-red-500/20"}`}>
                                <div className="flex items-center gap-2 flex-wrap mb-2">
                                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border font-bold shrink-0 ${isTeam ? "bg-blue-900/70 text-blue-200 border-blue-400/40" : "bg-red-900/70 text-red-200 border-red-400/40"}`}>
                                    #{i + 1}
                                  </span>
                                  <button
                                    onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: entry.address, x: r.left, y: r.bottom + 4 }); }}
                                    className="text-primary/80 hover:text-primary text-xs font-mono hover:underline transition-colors"
                                  >
                                    {entry.address.length > 24 ? `${entry.address.slice(0, 12)}…${entry.address.slice(-6)}` : entry.address}
                                  </button>
                                  {kn && getKnownBadge(kn, "md")}
                                  {isTeam && <span className="text-[10px] font-mono text-blue-400/80 shrink-0">◄ OFFICIAL ENTITY</span>}
                                  {savedWallets.has(entry.address) && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                                  <span className={`ml-auto text-[10px] font-mono font-bold shrink-0 ${entry.appearances.length >= multiResult.trackedWallets.length ? "text-red-300" : "text-orange-300"}`}>
                                    {entry.appearances.length}/{multiResult.trackedWallets.length} wallets
                                  </span>
                                </div>
                                <div className="space-y-1.5 mt-1">
                                  {entry.appearances.map((app) => {
                                    const idx      = multiResult.trackedWallets.indexOf(app.wallet);
                                    const c        = WALLET_COLORS[idx % WALLET_COLORS.length];
                                    const wLabel   = idx === 0 ? "PRIMARY" : `W${idx + 1}`;
                                    const trailStr = app.pathChain.length > 1
                                      ? app.pathChain.map(a => a.length > 14 ? `${a.slice(0, 6)}…${a.slice(-4)}` : a).join(" → ")
                                      : `${app.wallet.length > 14 ? `${app.wallet.slice(0, 6)}…${app.wallet.slice(-4)}` : app.wallet} → ${entry.address.length > 14 ? `${entry.address.slice(0, 6)}…${entry.address.slice(-4)}` : entry.address}`;
                                    return (
                                      <div key={app.wallet} className={`rounded px-2 py-1.5 border ${c.border} ${c.bg} text-[10px] font-mono`}>
                                        <div className="flex items-center gap-1.5 flex-wrap">
                                          <div className={`w-1.5 h-1.5 rounded-full ${c.dot} shrink-0`} />
                                          <span className={`${c.text} font-bold shrink-0`}>{wLabel}</span>
                                          <span className="text-muted-foreground/60">·</span>
                                          <span className="text-foreground font-bold">{app.txCount} tx</span>
                                          <span className={`${app.depth === 1 ? "text-yellow-400/80" : "text-muted-foreground/60"}`}>d{app.depth}</span>
                                          {app.totalValueUsd > 0 && <span className="text-muted-foreground/70">${app.totalValueUsd.toFixed(0)}</span>}
                                        </div>
                                        {app.pathChain.length > 1 && (
                                          <div className="mt-0.5 text-muted-foreground/50 text-[9px] truncate" title={trailStr}>
                                            {trailStr}
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                  </>
                );
              })()}

              {/* ── § 3 Commingling Patterns (private only) ── */}
              {(() => {
                const privPats = multiResult.patterns.filter(p =>
                  !["exchange","bridge","genesis"].includes(KNOWN_LABELS[p.sharedAddr]?.type ?? "") &&
                  p.sharedAddr !== "DAG5KmHp9gFS723uN6uukwRqCTwvrddaW5QuKKKz"
                );
                return (
                <div className="p-5">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="w-1.5 h-4 bg-red-500 rounded-sm shrink-0" />
                  <span className="text-[10px] font-mono text-red-300 font-bold tracking-widest uppercase">§ 3 — Commingling Patterns</span>
                  <span className="text-[10px] font-mono text-muted-foreground">private funneling paths to shared nodes</span>
                  <span className={`ml-auto text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${privPats.length > 0 ? "bg-red-950/60 text-red-200 border-red-400/40" : "text-muted-foreground border-border/30"}`}>
                    {privPats.length} patterns
                  </span>
                </div>
                {privPats.length === 0 ? (
                  <p className="text-[11px] font-mono text-muted-foreground/40 pl-3">No private commingling patterns detected.</p>
                ) : (
                  <div className="space-y-3">
                    {privPats.map((pat) => (
                      <div key={pat.sharedAddr} className="bg-red-950/10 border border-red-500/15 rounded-lg p-3">
                        <div className="flex items-center gap-2 flex-wrap mb-2.5">
                          <span className="text-[10px] font-mono bg-red-900/70 text-red-200 px-1.5 py-0.5 rounded border border-red-400/40 font-bold shrink-0">
                            PATTERN #{pat.id}
                          </span>
                          <button
                            onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: pat.sharedAddr, x: r.left, y: r.bottom + 4 }); }}
                            className="text-primary/80 hover:text-primary text-xs font-mono hover:underline transition-colors"
                          >
                            {pat.sharedAddr.length > 20 ? `${pat.sharedAddr.slice(0, 10)}…${pat.sharedAddr.slice(-6)}` : pat.sharedAddr}
                          </button>
                          {pat.knownInfo && getKnownBadge(pat.knownInfo, "md")}
                          <div className="ml-auto flex items-center gap-3 text-[10px] font-mono shrink-0">
                            {pat.totalTxCount > 0 && <span className="text-foreground font-bold">{pat.totalTxCount} tx</span>}
                            {pat.totalValueUsd > 0 && <span className="text-muted-foreground">${pat.totalValueUsd.toFixed(0)}</span>}
                            <span className="text-red-400 font-bold">{pat.paths.length} paths converge</span>
                          </div>
                        </div>
                        <div className="space-y-1.5 pl-2 border-l-2 border-red-500/20">
                          {pat.paths.map((p) => {
                            const idx = multiResult.trackedWallets.indexOf(p.wallet);
                            const c = WALLET_COLORS[idx % WALLET_COLORS.length];
                            return (
                              <div key={p.wallet} className="flex items-center gap-1 flex-wrap text-[10px] font-mono">
                                <span className={`${c.text} font-bold shrink-0`}>{idx === 0 ? "PRIMARY" : `WALLET ${idx + 1}`}</span>
                                {p.path.map((step, si) => (
                                  <span key={si} className="flex items-center gap-1">
                                    {si > 0 && <ChevronRight className="w-2.5 h-2.5 text-muted-foreground/50 shrink-0" />}
                                    <span className={
                                      si === 0 ? `${c.text}/70` :
                                      si === p.path.length - 1 ? "text-red-300 font-bold" :
                                      "text-muted-foreground"
                                    }>
                                      {step.length > 14 ? `${step.slice(0, 8)}…${step.slice(-4)}` : step}
                                    </span>
                                  </span>
                                ))}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
                );
              })()}

            </div>
          )}
        </Card>
      )}

      {/* ── Commingle Check Panel ── */}
      {showComminglePanel && (
        <Card ref={comminglePanelRef} className="bg-card/40 border-amber-500/30 shadow-lg shadow-amber-500/5">
          <CardHeader className="border-b border-border/40 pb-4 px-5 pt-5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full bg-amber-400 ${commingleLoading ? "animate-pulse" : ""}`} />
                <CardTitle className="text-sm font-mono uppercase tracking-widest text-amber-300">
                  Commingle Check
                </CardTitle>
                {commingleResult && (
                  <span className="text-xs font-mono text-muted-foreground">
                    <span className="text-green-400/80">{commingleResult.findings.filter((f) => f.knownInfo?.type !== "exchange").length} private</span>
                    {" · "}{commingleResult.totalScanned} scanned
                  </span>
                )}
              </div>
              <button onClick={() => setShowComminglePanel(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs font-mono text-muted-foreground mt-1.5 leading-relaxed">
              Scans up to 6 tiers deep from the target and each comparison wallet, then surfaces all shared addresses — direct counterparties, intermediaries, and common endpoints. Generates a police-ready report.
            </p>

            {/* ── Comparison wallet list ── */}
            <div className="mt-4 space-y-2.5">
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Target Wallet (fixed)</div>
              <div className="flex items-center gap-2.5 bg-amber-950/30 border border-amber-500/30 rounded-lg px-3 py-2">
                <div className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                <span className="text-xs font-mono text-amber-300 flex-1 truncate min-w-0">{address}</span>
                <span className="text-[10px] font-mono text-muted-foreground/60 shrink-0 uppercase">Target</span>
                {getKnownInfo(address, chain) && <span className="shrink-0">{getKnownBadge(getKnownInfo(address, chain)!)}</span>}
              </div>

              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider pt-1">Comparison Wallets</div>
              {commingleWallets.map((w, i) => (
                <div key={w} className="flex items-center gap-2.5 bg-muted/20 border border-border/40 rounded-lg px-3 py-2">
                  <div className="w-2 h-2 rounded-full bg-muted-foreground/60 shrink-0" />
                  <span className="text-xs font-mono text-foreground flex-1 truncate min-w-0">{w}</span>
                  <span className="text-[10px] font-mono text-muted-foreground/60 shrink-0">Wallet {i + 1}</span>
                  {getKnownInfo(w, chain) && <span className="shrink-0">{getKnownBadge(getKnownInfo(w, chain)!)}</span>}
                  <button
                    onClick={() => setCommingleWallets((prev) => { const next = prev.filter((_, j) => j !== i); try { localStorage.setItem("chaintrace-commingle-wallets", JSON.stringify(next)); } catch { /* noop */ } return next; })}
                    className="text-muted-foreground/60 hover:text-red-400 transition-colors shrink-0 ml-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}

              <div className="flex gap-2">
                <input
                  type="text"
                  value={commingleWalletInput}
                  onChange={(e) => setCommingleWalletInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      const trimmed = commingleWalletInput.trim();
                      if (trimmed && !commingleWallets.includes(trimmed) && trimmed !== address) {
                        setCommingleWallets((prev) => { const next = [...prev, trimmed]; try { localStorage.setItem("chaintrace-commingle-wallets", JSON.stringify(next)); } catch { /* noop */ } return next; });
                        setCommingleWalletInput("");
                      }
                    }
                  }}
                  placeholder="Paste comparison wallet address…"
                  className="flex-1 bg-muted/20 border border-border/40 focus:border-amber-500/50 rounded-lg px-3 py-2 text-xs font-mono text-foreground placeholder:text-muted-foreground/40 outline-none transition-colors"
                />
                <button
                  onClick={() => {
                    const trimmed = commingleWalletInput.trim();
                    if (trimmed && !commingleWallets.includes(trimmed) && trimmed !== address) {
                      setCommingleWallets((prev) => { const next = [...prev, trimmed]; try { localStorage.setItem("chaintrace-commingle-wallets", JSON.stringify(next)); } catch { /* noop */ } return next; });
                      setCommingleWalletInput("");
                    }
                  }}
                  disabled={!commingleWalletInput.trim()}
                  className="px-3 py-2 rounded-lg bg-amber-900/60 border border-amber-500/40 text-amber-300 hover:bg-amber-900/80 disabled:opacity-40 transition-colors shrink-0"
                  title="Add wallet"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={() => runCommingleCheck()}
                disabled={commingleLoading || commingleWallets.length === 0}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-amber-600 hover:bg-amber-500 active:bg-amber-700 disabled:bg-muted/30 disabled:text-muted-foreground/60 text-white font-mono text-xs font-bold tracking-widest transition-colors mt-1"
              >
                {commingleLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                    <span>SCANNING…</span>
                    {commingleProgress && <span className="opacity-60 truncate max-w-[240px] font-normal">{commingleProgress}</span>}
                  </>
                ) : (
                  <><GitMerge className="w-3.5 h-3.5" /> RUN COMMINGLE CHECK (6 TIERS)</>
                )}
              </button>
              {commingleError && (
                <p className="text-xs font-mono text-red-400 flex items-center gap-1.5 mt-0.5">
                  <AlertTriangle className="w-3 h-3 shrink-0" /> {commingleError}
                </p>
              )}
            </div>
          </CardHeader>

          {commingleResult && (
            <div className="divide-y divide-border/20">

              {/* ── Generate report bar ── */}
              <div className="px-5 py-3 bg-amber-950/20 border-b border-amber-500/20 flex flex-col gap-2.5">
                {/* Row 1: scan summary + MIN AMOUNT + GENERATE */}
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="text-xs font-mono text-amber-300/80">
                      Scan complete · <span className="text-green-400/80">{commingleResult.findings.filter((f) => f.knownInfo?.type !== "exchange").length} private</span> · {commingleResult.totalScanned} addresses mapped
                    </div>
                    {commingleResult.tieredCounts[0] > 0 && (
                      <span className="flex items-center gap-1 text-[10px] font-mono text-red-300 bg-red-950/50 border border-red-500/30 px-2 py-0.5 rounded font-bold">
                        <AlertTriangle className="w-2.5 h-2.5" /> {commingleResult.tieredCounts[0]} DIRECT MATCH{commingleResult.tieredCounts[0] !== 1 ? "ES" : ""}
                      </span>
                    )}
                  </div>
                </div>
                {/* Row 2: MIN AMOUNT filter + GENERATE button */}
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider shrink-0">Min Amount:</span>
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={commingleMinAmountInput}
                    onChange={(e) => {
                      setCommingleMinAmountInput(e.target.value);
                      const v = parseFloat(e.target.value);
                      if (!isNaN(v) && v >= 0) setCommingleMinAmount(v);
                    }}
                    onBlur={() => {
                      const v = parseFloat(commingleMinAmountInput);
                      if (isNaN(v) || v < 0) { setCommingleMinAmountInput("1"); setCommingleMinAmount(1); }
                    }}
                    className="w-20 bg-muted/20 border border-amber-500/30 focus:border-amber-400/60 rounded px-2 py-1 text-xs font-mono text-amber-200 outline-none transition-colors"
                  />
                  <span className="text-[10px] font-mono text-amber-300/60 shrink-0">{(commingleResult?.chain ?? chain).toUpperCase()}</span>
                  <span className="text-[10px] font-mono text-muted-foreground/60">
                    {commingleMinAmount <= 0 ? "showing all transactions" : "dust & fees excluded"}
                  </span>
                  <button
                    className="ml-auto flex items-center gap-1.5 text-[11px] font-mono font-bold text-white bg-amber-600 hover:bg-amber-500 border border-amber-500/50 rounded px-3 py-1.5 transition-colors shrink-0"
                    onClick={() => {
                    const rpt = generateCommingleReport();
                    const title = `Commingle Check Report — ${(commingleResult?.chain ?? chain).toUpperCase()} — ${(commingleResult?.targetWallet ?? address).slice(0, 12)}`;
                    setReportContent(rpt);
                    setReportTitle(title);
                    const enrichedFindings = (commingleResult?.findings ?? []).map((f) => ({
                      ...f,
                      sampleTransactions: allTxs
                        .filter((t) =>
                          (t.direction === "in" ? t.from : t.to) === f.sharedAddress &&
                          (commingleMinAmount <= 0 || parseFloat(t.value) >= commingleMinAmount)
                        )
                        .slice(0, 5)
                        .map((t) => ({
                          hash: t.hash,
                          direction: t.direction,
                          value: t.value,
                          timestamp: t.timestamp,
                          memo: t.memo ?? null,
                          destinationTag: t.destinationTag ?? null,
                        })),
                    }));
                    setReportJsonData({ reportType: "commingle", generatedAt: new Date().toISOString(), ...commingleResult, findings: enrichedFindings, reportText: rpt });
                    setShowReportModal(true);
                  }}
                >
                  <FileText className="w-3.5 h-3.5" /> GENERATE REPORT
                </button>
              </div>
            </div>

              {/* ── Tier badges summary ── */}
              <div className="px-5 py-3 flex items-center gap-4 flex-wrap bg-muted/5">
                <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Shared nodes by tier:</span>
                {([
                  { label: "Tier 1 · Direct", count: commingleResult.tieredCounts[0], color: "text-red-300 border-red-500/30 bg-red-950/30" },
                  { label: "Tier 2", count: commingleResult.tieredCounts[1], color: "text-orange-300 border-orange-500/30 bg-orange-950/30" },
                  { label: "Tier 3", count: commingleResult.tieredCounts[2], color: "text-yellow-300 border-yellow-500/30 bg-yellow-950/30" },
                  { label: "Tier 4", count: commingleResult.tieredCounts[3], color: "text-muted-foreground border-border/30 bg-muted/10" },
                ] as const).map((t) => (
                  <div key={t.label} className={`flex items-center gap-1.5 border rounded px-2 py-0.5 text-[10px] font-mono font-bold ${t.color}`}>
                    {t.label}: {t.count}
                  </div>
                ))}
              </div>

              {/* ── § 1 Tier 1 — Direct Shared Counterparties ── */}
              <div className="p-5">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="w-1.5 h-4 bg-red-500 rounded-sm shrink-0" />
                  <span className="text-[10px] font-mono text-red-300 font-bold tracking-widest uppercase">§ 1 — Tier 1: Direct Shared Counterparties</span>
                  <span className="text-[10px] font-mono text-muted-foreground">wallets both sides transact with directly</span>
                  <span className={`ml-auto text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${commingleResult.tieredCounts[0] > 0 ? "bg-red-950/60 text-red-200 border-red-400/40" : "text-muted-foreground border-border/30"}`}>
                    {commingleResult.tieredCounts[0]} found
                  </span>
                </div>
                {commingleResult.tieredCounts[0] === 0 ? (
                  <p className="text-[11px] font-mono text-muted-foreground/40 pl-3 leading-relaxed">
                    No direct shared counterparties. Check Tier 2+ below for deeper connections.
                  </p>
                ) : (() => {
                  const t1priv = commingleResult.findings.filter((f) => f.tier === 1 && f.knownInfo?.type !== "exchange");
                  return (
                    <div className="space-y-3">
                      {t1priv.length > 0 && (
                        <div>
                          <div className="text-[10px] font-mono text-green-400/80 font-bold tracking-wider mb-2 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-green-400/80 shrink-0" />
                            Private Wallet Connections ({t1priv.length}) — Investigate First
                          </div>
                          <div className="space-y-2">
                            {t1priv.map((f, i) => (
                              <div key={f.sharedAddress} className="bg-red-950/15 border border-red-500/25 rounded-lg p-3">
                                <div className="flex items-center gap-2 flex-wrap mb-2">
                                  <span className="text-[10px] font-mono bg-red-900/70 text-red-200 px-1.5 py-0.5 rounded border border-red-400/40 font-bold shrink-0">#{i + 1}</span>
                                  <AlertTriangle className="w-3 h-3 text-red-400 shrink-0" />
                                  <button
                                    onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: f.sharedAddress, x: r.left, y: r.bottom + 4 }); }}
                                    className="text-primary/80 hover:text-primary text-xs font-mono hover:underline transition-colors"
                                  >
                                    {f.sharedAddress.length > 20 ? `${f.sharedAddress.slice(0, 10)}…${f.sharedAddress.slice(-6)}` : f.sharedAddress}
                                  </button>
                                  {f.knownInfo && getKnownBadge(f.knownInfo, "md")}
                                  {savedWallets.has(f.sharedAddress) && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                                  <span className="ml-auto text-[10px] font-mono text-red-400 font-bold shrink-0">
                                    {f.peerPaths.length} wallet{f.peerPaths.length !== 1 ? "s" : ""} share this
                                  </span>
                                </div>
                                <div className="text-[10px] font-mono text-muted-foreground/70 pl-1 space-y-0.5">
                                  {f.peerPaths.map((p, pi) => (
                                    <div key={p.wallet}><span className="text-muted-foreground/50">Wallet {pi + 1}: </span>{p.wallet.length > 14 ? `${p.wallet.slice(0, 8)}…${p.wallet.slice(-4)}` : p.wallet} → {f.sharedAddress.length > 12 ? `${f.sharedAddress.slice(0, 6)}…${f.sharedAddress.slice(-4)}` : f.sharedAddress}</div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* ── § 2 Tier 2 ── */}
              <div className="p-5">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="w-1.5 h-4 bg-orange-500 rounded-sm shrink-0" />
                  <span className="text-[10px] font-mono text-orange-300 font-bold tracking-widest uppercase">§ 2 — Tier 2: Second-Degree Shared Nodes</span>
                  <span className="text-[10px] font-mono text-muted-foreground">shared 2nd-degree connections</span>
                  <span className={`ml-auto text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${commingleResult.tieredCounts[1] > 0 ? "bg-orange-950/60 text-orange-200 border-orange-400/40" : "text-muted-foreground border-border/30"}`}>
                    {commingleResult.tieredCounts[1]} found
                  </span>
                </div>
                {commingleResult.tieredCounts[1] === 0 ? (
                  <p className="text-[11px] font-mono text-muted-foreground/40 pl-3 leading-relaxed">No tier-2 shared nodes.</p>
                ) : (() => {
                  const t2priv = commingleResult.findings.filter((f) => f.tier === 2 && f.knownInfo?.type !== "exchange");
                  return (
                    <div className="space-y-3">
                      {t2priv.length > 0 && (
                        <div>
                          <div className="text-[10px] font-mono text-green-400/70 font-bold tracking-wider mb-1.5 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-green-400/70 shrink-0" />
                            Private ({t2priv.length})
                          </div>
                          <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                            {t2priv.slice(0, 30).map((f, i) => (
                              <div key={f.sharedAddress} className="bg-orange-950/10 border border-orange-500/20 rounded-lg p-3">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[10px] font-mono bg-orange-900/60 text-orange-200 px-1.5 py-0.5 rounded border border-orange-400/40 font-bold shrink-0">#{i + 1}</span>
                                  <button
                                    onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: f.sharedAddress, x: r.left, y: r.bottom + 4 }); }}
                                    className="text-primary/80 hover:text-primary text-xs font-mono hover:underline transition-colors"
                                  >
                                    {f.sharedAddress.length > 20 ? `${f.sharedAddress.slice(0, 10)}…${f.sharedAddress.slice(-6)}` : f.sharedAddress}
                                  </button>
                                  {f.knownInfo && getKnownBadge(f.knownInfo)}
                                  {savedWallets.has(f.sharedAddress) && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                                  <span className="ml-auto text-[10px] font-mono text-muted-foreground shrink-0">
                                    {f.peerPaths.length} wallet{f.peerPaths.length !== 1 ? "s" : ""} · via {f.peerPaths[0]?.path.length > 2 ? (f.peerPaths[0].path[1].length > 10 ? `${f.peerPaths[0].path[1].slice(0, 6)}…` : f.peerPaths[0].path[1]) : "—"}
                                  </span>
                                </div>
                              </div>
                            ))}
                            {t2priv.length > 30 && (
                              <p className="text-[10px] font-mono text-muted-foreground/50 pl-3">… and {t2priv.length - 30} more — see full report</p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* ── § 3 Tier 3–4 ── */}
              <div className="p-5">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="w-1.5 h-4 bg-yellow-500 rounded-sm shrink-0" />
                  <span className="text-[10px] font-mono text-yellow-300 font-bold tracking-widest uppercase">§ 3 — Tier 3–4: Deep Shared Nodes</span>
                  <span className="text-[10px] font-mono text-muted-foreground">3rd and 4th degree connections</span>
                  <span className={`ml-auto text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${(commingleResult.tieredCounts[2] + commingleResult.tieredCounts[3] + commingleResult.tieredCounts[4] + commingleResult.tieredCounts[5]) > 0 ? "bg-yellow-950/60 text-yellow-200 border-yellow-400/40" : "text-muted-foreground border-border/30"}`}>
                    {commingleResult.tieredCounts[2] + commingleResult.tieredCounts[3] + commingleResult.tieredCounts[4] + commingleResult.tieredCounts[5]} found
                  </span>
                </div>
                {commingleResult.tieredCounts[2] + commingleResult.tieredCounts[3] + commingleResult.tieredCounts[4] + commingleResult.tieredCounts[5] === 0 ? (
                  <p className="text-[11px] font-mono text-muted-foreground/40 pl-3 leading-relaxed">No tier 3–6 shared nodes detected.</p>
                ) : (() => {
                  const t34priv = commingleResult.findings.filter((f) => f.tier >= 3 && f.knownInfo?.type !== "exchange");
                  return (
                    <div className="space-y-3">
                      {t34priv.length > 0 && (
                        <div>
                          <div className="text-[10px] font-mono text-green-400/60 font-bold tracking-wider mb-1.5 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-green-400/60 shrink-0" />
                            Private ({t34priv.length})
                          </div>
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {t34priv.slice(0, 20).map((f, i) => (
                              <div key={f.sharedAddress} className="bg-yellow-950/10 border border-yellow-500/15 rounded-lg p-3">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[10px] font-mono bg-yellow-900/50 text-yellow-200 px-1.5 py-0.5 rounded border border-yellow-400/30 font-bold shrink-0">#{i + 1}</span>
                                  <span className="text-[10px] font-mono text-yellow-400/70 border border-yellow-500/20 px-1 py-0.5 rounded shrink-0">T{f.tier}</span>
                                  <button
                                    onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setActiveMenu({ addr: f.sharedAddress, x: r.left, y: r.bottom + 4 }); }}
                                    className="text-primary/80 hover:text-primary text-xs font-mono hover:underline transition-colors"
                                  >
                                    {f.sharedAddress.length > 20 ? `${f.sharedAddress.slice(0, 10)}…${f.sharedAddress.slice(-6)}` : f.sharedAddress}
                                  </button>
                                  {f.knownInfo && getKnownBadge(f.knownInfo)}
                                  {savedWallets.has(f.sharedAddress) && <Bookmark className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />}
                                </div>
                              </div>
                            ))}
                            {t34priv.length > 20 && (
                              <p className="text-[10px] font-mono text-muted-foreground/50 pl-3">… and {t34priv.length - 20} more — see full report</p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* ── Copy report inline ── */}
              <div className="px-5 py-4 bg-muted/5 flex items-center justify-between gap-3 flex-wrap">
                <div className="space-y-0.5">
                  <p className="text-[10px] font-mono text-muted-foreground/70">
                    Scanned at {new Date(commingleResult.scannedAt).toLocaleString()} · {commingleResult.chain.toUpperCase()} · 6 tiers
                  </p>
                  <p className="text-[10px] font-mono text-muted-foreground/50">
                    Comparison wallets: {commingleResult.comparisonWallets.length}
                  </p>
                </div>
                <button
                  onClick={() => {
                    const rpt = generateCommingleReport();
                    navigator.clipboard.writeText(rpt).catch(() => {});
                    setCommingleReportCopied(true);
                    setTimeout(() => setCommingleReportCopied(false), 2500);
                  }}
                  className={`flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border transition-colors ${
                    commingleReportCopied
                      ? "border-green-500/50 text-green-400 bg-green-950/30"
                      : "border-amber-500/30 text-amber-300 hover:bg-amber-950/30 hover:border-amber-500/60"
                  }`}
                >
                  {commingleReportCopied ? <><Check className="w-3.5 h-3.5" /> COPIED!</> : <><Copy className="w-3.5 h-3.5" /> COPY REPORT</>}
                </button>
              </div>

            </div>
          )}
        </Card>
      )}

      {/* ── Victim → Thief Path Trace Panel ──────────────────────────────── */}
      {showPathPanel && (
        <Card ref={pathPanelRef} className="bg-card/40 border-rose-500/30 shadow-lg shadow-rose-500/5">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Route className="w-4 h-4 text-rose-400" />
                <CardTitle className="text-sm font-mono text-rose-300 tracking-widest uppercase">
                  Victim → Thief Path Trace
                </CardTitle>
              </div>
              <button onClick={() => setShowPathPanel(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs font-mono text-muted-foreground mt-1">
              Enter wallets in exact order — victim first, then thief, then any additional known hops.
              Paste the specific transaction hash (TA) for each step for the most precise evidence trail.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Column headers */}
            <div className="grid grid-cols-[7rem_1fr_1fr_1.5rem] gap-2 items-center px-0.5">
              <div />
              <span className="text-[10px] font-mono text-muted-foreground/60 uppercase tracking-wider">Wallet Address</span>
              <span className="text-[10px] font-mono text-muted-foreground/60 uppercase tracking-wider">Transaction Hash (TA)</span>
              <div />
            </div>

            {/* Hop rows */}
            <div className="space-y-2">
              {pathSteps.map((step, idx) => (
                <div key={idx} className="grid grid-cols-[7rem_1fr_1fr_1.5rem] gap-2 items-center">
                  {/* Role badge */}
                  <div className="flex items-center">
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border whitespace-nowrap ${
                      idx === 0
                        ? "text-blue-300 bg-blue-950/40 border-blue-500/30"
                        : idx === 1
                        ? "text-rose-300 bg-rose-950/40 border-rose-500/30"
                        : "text-orange-300 bg-orange-950/40 border-orange-500/30"
                    }`}>
                      {idx === 0 ? "VICTIM" : idx === 1 ? "THIEF" : `HOP ${idx + 1}`}
                    </span>
                  </div>
                  {/* Wallet input */}
                  <input
                    type="text"
                    value={step.wallet}
                    onChange={(e) => {
                      const next = pathSteps.map((s, i) => i === idx ? { ...s, wallet: e.target.value } : s);
                      setPathSteps(next);
                    }}
                    placeholder={idx === 0 ? "Victim wallet address" : idx === 1 ? "Thief wallet address" : "Next hop wallet address"}
                    className="bg-background/50 border border-border/50 text-xs font-mono text-foreground px-3 py-2 rounded focus:outline-none focus:border-rose-500/50 focus:ring-1 focus:ring-rose-500/20 placeholder:text-muted-foreground/40 min-w-0"
                  />
                  {/* TX hash input */}
                  <input
                    type="text"
                    value={step.txHash}
                    onChange={(e) => {
                      const next = pathSteps.map((s, i) => i === idx ? { ...s, txHash: e.target.value } : s);
                      setPathSteps(next);
                    }}
                    placeholder="TX hash (optional but recommended)"
                    className="bg-background/50 border border-border/50 text-xs font-mono text-foreground px-3 py-2 rounded focus:outline-none focus:border-rose-500/50 focus:ring-1 focus:ring-rose-500/20 placeholder:text-muted-foreground/40 min-w-0"
                  />
                  {/* Remove button — only for hop 3+ */}
                  {idx >= 2 ? (
                    <button
                      onClick={() => setPathSteps(pathSteps.filter((_, i) => i !== idx))}
                      className="text-muted-foreground hover:text-rose-400 transition-colors flex items-center justify-center"
                      title="Remove this hop"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  ) : <div />}
                </div>
              ))}

              {/* Add hop */}
              <button
                onClick={() => setPathSteps([...pathSteps, { wallet: "", txHash: "" }])}
                className="flex items-center gap-1.5 text-[11px] font-mono text-rose-400/70 hover:text-rose-300 border border-dashed border-rose-500/20 hover:border-rose-500/40 px-3 py-1.5 rounded w-full justify-center transition-colors mt-1"
              >
                <Plus className="w-3 h-3" /> ADD NEXT HOP
              </button>
            </div>

            {/* Error */}
            {pathError && (
              <div className="text-xs font-mono text-red-400 bg-red-950/20 border border-red-500/20 rounded px-3 py-2">
                {pathError}
              </div>
            )}

            {/* Progress */}
            {pathLoading && pathProgress && (
              <div className="flex items-center gap-2 text-xs font-mono text-rose-300/80">
                <Loader2 className="w-3 h-3 animate-spin" />
                {pathProgress}
              </div>
            )}

            {/* Generate / Clear */}
            <div className="flex items-center gap-3">
              <Button
                className="font-mono text-xs bg-rose-700 hover:bg-rose-600 text-white border-0"
                onClick={runPathTrace}
                disabled={pathLoading || pathSteps.filter(s => s.wallet.trim()).length < 2}
              >
                {pathLoading
                  ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> TRACING…</>
                  : <><Route className="w-3.5 h-3.5 mr-1.5" /> GENERATE PATH TRACE</>}
              </Button>
              <button
                onClick={() => setPathSteps([{ wallet: "", txHash: "" }, { wallet: "", txHash: "" }])}
                className="text-[11px] font-mono text-muted-foreground hover:text-foreground transition-colors"
              >
                CLEAR
              </button>
            </div>

            <p className="text-[10px] font-mono text-muted-foreground/50 leading-relaxed">
              TX hashes are used to look up the exact transaction for each hop.
              Transactions are searched in your loaded history first, then fetched directly from the chain.
              The report also shows all further connections from the final wallet (Expand section).
            </p>
          </CardContent>
        </Card>
      )}

      {/* ── Connection Finder Panel ─────────────────────────────────────────── */}
      {showTiePanel && (
        <Card ref={tiePanelRef} className="bg-card/40 border-sky-500/20">
          <CardHeader className="border-b border-border/40 pb-4 px-5 pt-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                <CardTitle className="text-sm font-mono uppercase tracking-widest text-sky-300">
                  Connection Finder
                </CardTitle>
              </div>
              <div className="flex items-center gap-2">
                {tieResult && (
                  <button
                    onClick={() => {
                      const rpt = generateTieFinderReport();
                      const title = `Connection Finder Report — ${chain.toUpperCase()} — ${address.slice(0, 12)}`;
                      setReportContent(rpt);
                      setReportTitle(title);
                      setReportJsonData({ reportType: "connection-finder", generatedAt: new Date().toISOString(), chain, subjectAddress: address, walletInfo: wallet, selectedAddresses: [tieBWallet], reportText: rpt });
                      setShowReportModal(true);
                    }}
                    className="flex items-center gap-1 text-[11px] font-mono text-orange-400 hover:text-orange-300 bg-orange-950/30 hover:bg-orange-950/60 border border-orange-500/30 rounded px-2 py-1 transition-colors"
                  >
                    <FileText className="w-3 h-3" /> EXPORT REPORT
                  </button>
                )}
                <button onClick={() => setShowTiePanel(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <p className="text-xs font-mono text-muted-foreground mt-1.5 leading-relaxed">
              Bidirectional BFS — expands outward from both wallets simultaneously and detects any common node they share. Every hop shows full TX details.
            </p>
          </CardHeader>

          {/* ── Input form ── */}
          <div className="p-5 space-y-4 border-b border-border/30">
            <div className="grid grid-cols-1 gap-3">
              {/* Wallet A — pre-filled */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">
                  Wallet A — Victim / Theft Wallet (current)
                </label>
                <div className="w-full px-3 py-2 rounded border border-border/40 bg-muted/10 text-[11px] font-mono text-sky-200/70 truncate select-all">
                  {address}
                </div>
              </div>

              {/* Wallet B — free input */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">
                  Wallet B — Suspected Connected Wallet
                </label>
                <input
                  type="text"
                  value={tieBWallet}
                  onChange={e => { setTieBWallet(e.target.value); setTieError(null); setTieResult(null); }}
                  placeholder="Enter wallet address…"
                  className="w-full px-3 py-2 rounded border border-border/40 bg-muted/10 hover:border-sky-500/40 focus:border-sky-500/60 focus:outline-none text-[11px] font-mono text-foreground placeholder:text-muted-foreground/40 transition-colors"
                  disabled={tieLoading}
                />
              </div>

              {/* Max Hops + Run button row */}
              <div className="flex items-end gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">
                    Max Hops
                  </label>
                  <select
                    value={tieMaxHops}
                    onChange={e => setTieMaxHops(Number(e.target.value))}
                    disabled={tieLoading}
                    className="px-3 py-2 rounded border border-border/40 bg-muted/10 hover:border-sky-500/40 focus:border-sky-500/60 focus:outline-none text-[11px] font-mono text-foreground transition-colors cursor-pointer"
                  >
                    {[4, 5, 6, 7, 8].map(n => (
                      <option key={n} value={n}>{n} hops</option>
                    ))}
                  </select>
                </div>
                <button
                  onClick={() => void runTieFinder()}
                  disabled={tieLoading || !tieBWallet.trim()}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-sky-700 hover:bg-sky-600 active:bg-sky-800 disabled:opacity-40 disabled:cursor-not-allowed text-white font-mono text-xs font-bold tracking-widest transition-colors"
                >
                  {tieLoading
                    ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> SEARCHING…</>
                    : <><Network className="w-3.5 h-3.5" /> FIND CONNECTION</>
                  }
                </button>
                {(tieResult || tieError) && !tieLoading && (
                  <button
                    onClick={() => { setTieResult(null); setTieError(null); }}
                    className="px-3 py-2 text-[10px] font-mono text-muted-foreground hover:text-foreground border border-border/30 hover:border-border/60 rounded transition-colors"
                  >
                    CLEAR
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* ── Progress bar ── */}
          {tieLoading && (
            <div className="px-5 py-2.5 flex items-center gap-3 border-b border-border/30 bg-sky-950/10">
              <Loader2 className="w-3 h-3 text-sky-400 animate-spin shrink-0" />
              <span className="text-[11px] font-mono text-sky-300/80 flex-1 truncate">{tieProgress}</span>
            </div>
          )}

          {/* ── Error ── */}
          {tieError && (
            <div className="mx-5 mt-4 flex items-center gap-2 px-3 py-2 rounded border border-red-500/30 bg-red-950/20 text-[11px] font-mono text-red-300">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" /> {tieError}
            </div>
          )}

          {/* ── Results ── */}
          {tieResult && (
            <div className="p-5 space-y-5">

              {/* Summary bar */}
              <div className={`flex items-start gap-3 px-4 py-3 rounded-lg border ${
                tieResult.commonNodes.length > 0
                  ? "border-sky-500/30 bg-sky-950/20"
                  : "border-yellow-500/20 bg-yellow-950/10"
              }`}>
                <div className={`mt-0.5 shrink-0 ${tieResult.commonNodes.length > 0 ? "text-sky-400" : "text-yellow-400"}`}>
                  {tieResult.commonNodes.length > 0
                    ? <Network className="w-4 h-4" />
                    : <AlertTriangle className="w-4 h-4" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  {tieResult.commonNodes.length > 0 ? (
                    <>
                      <p className="text-xs font-mono font-bold text-sky-300 mb-0.5">
                        CONNECTION CONFIRMED — {tieResult.commonNodes.length} common node{tieResult.commonNodes.length !== 1 ? "s" : ""} found
                      </p>
                      <p className="text-[10px] font-mono text-muted-foreground">
                        Both wallets transact through the same intermediate address{tieResult.commonNodes.length !== 1 ? "es" : ""}
                        &nbsp;·&nbsp; {tieResult.nodesScannedA} nodes scanned from A · {tieResult.nodesScannedB} from B · max {tieResult.maxHops} hops
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-xs font-mono font-bold text-yellow-300 mb-0.5">
                        NO VERIFIABLE PRIVATE-WALLET CONNECTION found within {tieResult.maxHops} hops
                      </p>
                      <p className="text-[10px] font-mono text-muted-foreground">
                        {tieResult.nodesScannedA} nodes scanned from A · {tieResult.nodesScannedB} from B.
                        Try increasing Max Hops or loading more TX history first.
                      </p>
                    </>
                  )}
                </div>
              </div>

              {/* Common node details */}
              {tieResult.commonNodes.map((node, ni) => {
                const kn = KNOWN_LABELS[node.address];
                const chainUp = tieResult!.chain.toUpperCase();
                const fmtDate = (ts: string) => {
                  if (!ts) return "—";
                  const d = new Date(ts);
                  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
                    + " " + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) + " UTC";
                };
                const fmtAmt = (v: string, dir: string) => {
                  const n = parseFloat(v);
                  const sign = dir === "in" ? "+" : "−";
                  if (!n || isNaN(n)) return `${sign}0.00`;
                  const abs = Math.abs(n);
                  const dec = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
                  return `${sign}${n.toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec })}`;
                };

                const renderTrail = (path: TieFinderHop[], label: string, color: string) => (
                  <div className="space-y-0">
                    <div className={`text-[10px] font-mono font-bold ${color} uppercase tracking-wider mb-2`}>
                      {label} — {path.length - 1} hop{path.length - 1 !== 1 ? "s" : ""}
                    </div>
                    <div className="space-y-0">
                      {path.map((hop, idx) => {
                        const hopKn  = KNOWN_LABELS[hop.address];
                        const isRoot = idx === 0;
                        const isLast = idx === path.length - 1;
                        return (
                          <div key={hop.address + idx} className="relative">
                            {/* Connector line */}
                            {idx > 0 && (
                              <div className="flex items-center gap-2 py-0.5 pl-3">
                                <div className="w-px h-4 bg-border/40 ml-1.5" />
                                <span className="text-[9px] font-mono text-muted-foreground/50">HOP {idx}</span>
                              </div>
                            )}
                            {/* Address row */}
                            <div className={`flex items-start gap-2 px-3 py-2 rounded ${
                              isRoot ? "bg-muted/10 border border-border/20" :
                              isLast ? "bg-sky-950/20 border border-sky-500/20" :
                              "bg-muted/5 border border-border/10"
                            }`}>
                              <div className={`mt-0.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                                isRoot ? "bg-green-400" : isLast ? "bg-sky-400" : "bg-muted-foreground/40"
                              }`} />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[11px] font-mono text-foreground break-all">{hop.address}</span>
                                  {isRoot && <span className="text-[9px] font-mono text-green-400/80 bg-green-950/30 border border-green-500/20 px-1.5 py-0.5 rounded">{label}</span>}
                                  {isLast && !isRoot && <span className="text-[9px] font-mono text-sky-400/80 bg-sky-950/30 border border-sky-500/20 px-1.5 py-0.5 rounded">COMMON NODE</span>}
                                  {hopKn && <span className="text-[9px] font-mono text-blue-300/80 bg-blue-950/30 border border-blue-500/20 px-1.5 py-0.5 rounded">{hopKn.label}</span>}
                                </div>
                                {/* TX details for this hop */}
                                {hop.tx && !isRoot && (
                                  <div className="mt-1.5 pl-2 border-l border-border/30 space-y-0.5">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span className={`text-[9px] font-mono px-1 py-0.5 rounded ${
                                        hop.tx.direction === "in"
                                          ? "text-green-300 bg-green-950/30 border border-green-500/20"
                                          : "text-red-300 bg-red-950/30 border border-red-500/20"
                                      }`}>
                                        {hop.tx.direction === "in" ? "IN" : "OUT"}
                                      </span>
                                      <span className="text-[10px] font-mono text-foreground/90 font-medium">
                                        {fmtAmt(hop.tx.value, hop.tx.direction)}&nbsp;
                                        {(hop.tx as Tx & { tokenSymbol?: string }).tokenSymbol || chainUp}
                                      </span>
                                      {hop.tx.valueUsd > 0 && (
                                        <span className="text-[9px] font-mono text-muted-foreground">
                                          ${hop.tx.valueUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                        </span>
                                      )}
                                    </div>
                                    <div className="text-[10px] font-mono text-muted-foreground space-y-0.5">
                                      <div><span className="text-muted-foreground/50">From </span>{hop.tx.from || "—"}</div>
                                      <div><span className="text-muted-foreground/50">To   </span>{hop.tx.to || "—"}</div>
                                      <div><span className="text-muted-foreground/50">TX   </span>{hop.tx.hash || "(none)"}</div>
                                      <div><span className="text-muted-foreground/50">Date </span>{fmtDate(hop.tx.timestamp || "")}</div>
                                      {(hop.tx as Tx & { destinationTag?: number | null }).destinationTag != null && (
                                        <div><span className="text-muted-foreground/50">Tag  </span>{(hop.tx as Tx & { destinationTag?: number | null }).destinationTag}</div>
                                      )}
                                      {hop.tx.memo && (
                                        <div><span className="text-muted-foreground/50">Memo </span>{hop.tx.memo}</div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );

                return (
                  <div key={node.address + ni} className="rounded-lg border border-sky-500/20 bg-sky-950/5 overflow-hidden">
                    {/* Common node header */}
                    <div className="px-4 py-3 border-b border-sky-500/15 bg-sky-950/15 flex items-start gap-3">
                      <div className="shrink-0 w-5 h-5 rounded-full bg-sky-500/20 border border-sky-500/40 flex items-center justify-center mt-0.5">
                        <span className="text-[9px] font-mono font-bold text-sky-300">{ni + 1}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-[10px] font-mono text-sky-400/70 uppercase tracking-wider mb-0.5">
                          Common Node {ni + 1} of {tieResult!.commonNodes.length}
                          {kn ? ` — ${kn.label.toUpperCase()}` : ""}
                        </div>
                        <div className="text-[11px] font-mono text-sky-200 break-all">{node.address}</div>
                        <div className="text-[9px] font-mono text-muted-foreground mt-1">
                          Wallet A reaches here in {node.pathFromA.length - 1} hop{node.pathFromA.length - 1 !== 1 ? "s" : ""}
                          &nbsp;·&nbsp;
                          Wallet B reaches here in {node.pathFromB.length - 1} hop{node.pathFromB.length - 1 !== 1 ? "s" : ""}
                        </div>
                      </div>
                    </div>

                    {/* Two trail columns */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-border/20">
                      <div className="p-4">
                        {renderTrail(node.pathFromA, "WALLET A", "text-green-400")}
                      </div>
                      <div className="p-4">
                        {renderTrail(node.pathFromB, "WALLET B", "text-amber-400")}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      )}

      {/* ── Investigative Report Modal ─────────────────────────────────────── */}
      {showReportModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={() => setShowReportModal(false)}
        >
          <div
            className="relative w-full max-w-4xl bg-[#0a0c10] border border-orange-500/30 rounded-lg shadow-2xl flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border/40 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                <span className="font-mono text-sm text-orange-300 font-bold uppercase tracking-widest">
                  Investigative Report
                </span>
                <span className="text-[11px] font-mono text-muted-foreground">
                  {selectedWallets.size} selected wallet{selectedWallets.size !== 1 ? "s" : ""} · {chain.toUpperCase()}
                </span>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => exportAsPdf(reportTitle, reportContent)}
                  className="flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border border-blue-500/30 text-blue-300 hover:bg-blue-950/30 hover:border-blue-500/60 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" /> EXPORT PDF
                </button>
                <button
                  onClick={() => exportAsJson(reportFilename(reportTitle, "json"), reportJsonData)}
                  className="flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border border-cyan-500/30 text-cyan-300 hover:bg-cyan-950/30 hover:border-cyan-500/60 transition-colors"
                >
                  <FileJson className="w-3.5 h-3.5" /> EXPORT JSON
                </button>
                <button
                  onClick={async () => {
                    try {
                      const encoded = await encodeReportForUrl(reportTitle, reportContent);
                      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
                      const url = `${window.location.origin}${base}/report-view?d=${encoded}`;
                      await navigator.clipboard.writeText(url);
                      setReportLinkCopied(true);
                      setTimeout(() => setReportLinkCopied(false), 2500);
                    } catch { /* noop */ }
                  }}
                  className={`flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border transition-colors ${
                    reportLinkCopied
                      ? "border-green-500/50 text-green-400 bg-green-950/30"
                      : "border-purple-500/30 text-purple-300 hover:bg-purple-950/30 hover:border-purple-500/60"
                  }`}
                >
                  {reportLinkCopied ? <><Check className="w-3.5 h-3.5" /> LINK COPIED!</> : <><ExternalLink className="w-3.5 h-3.5" /> COPY LINK</>}
                </button>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(reportContent).catch(() => {});
                    setReportCopied(true);
                    setTimeout(() => setReportCopied(false), 2500);
                  }}
                  className={`flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border transition-colors ${
                    reportCopied
                      ? "border-green-500/50 text-green-400 bg-green-950/30"
                      : "border-orange-500/30 text-orange-300 hover:bg-orange-950/30 hover:border-orange-500/60"
                  }`}
                >
                  {reportCopied ? <><Check className="w-3.5 h-3.5" /> COPIED!</> : <><Copy className="w-3.5 h-3.5" /> COPY TEXT</>}
                </button>
                <button
                  onClick={() => setShowReportModal(false)}
                  className="text-muted-foreground hover:text-foreground transition-colors p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Report body */}
            <div className="overflow-y-auto flex-1 p-5">
              <pre className="font-mono text-[11px] leading-relaxed text-green-300/90 whitespace-pre-wrap break-all bg-transparent select-all">
                {reportContent}
              </pre>
            </div>

            {/* Footer */}
            <div className="px-5 py-3 border-t border-border/30 shrink-0 flex items-center justify-between gap-3 flex-wrap bg-muted/5">
              <span className="text-[10px] font-mono text-muted-foreground/50">
                Click outside to close · ✅ Use the blue "Save as PDF" button in the print dialog — full report exports completely
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => exportAsPdf(reportTitle, reportContent)}
                  className="flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border border-blue-500/30 text-blue-300 hover:bg-blue-950/30 transition-colors"
                >
                  <Download className="w-3 h-3" /> EXPORT PDF
                </button>
                <button
                  onClick={() => exportAsJson(reportFilename(reportTitle, "json"), reportJsonData)}
                  className="flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border border-cyan-500/30 text-cyan-300 hover:bg-cyan-950/30 transition-colors"
                >
                  <FileJson className="w-3 h-3" /> EXPORT JSON
                </button>
                <button
                  onClick={async () => {
                    try {
                      const encoded = await encodeReportForUrl(reportTitle, reportContent);
                      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
                      const url = `${window.location.origin}${base}/report-view?d=${encoded}`;
                      await navigator.clipboard.writeText(url);
                      setReportLinkCopied(true);
                      setTimeout(() => setReportLinkCopied(false), 2500);
                    } catch { /* noop */ }
                  }}
                  className={`flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border transition-colors ${
                    reportLinkCopied
                      ? "border-green-500/50 text-green-400 bg-green-950/30"
                      : "border-purple-500/30 text-purple-300 hover:bg-purple-950/30"
                  }`}
                >
                  {reportLinkCopied ? <><Check className="w-3 h-3" /> LINK COPIED!</> : <><ExternalLink className="w-3 h-3" /> COPY LINK</>}
                </button>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(reportContent).catch(() => {});
                    setReportCopied(true);
                    setTimeout(() => setReportCopied(false), 2500);
                  }}
                  className={`flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded border transition-colors ${
                    reportCopied
                      ? "border-green-500/50 text-green-400 bg-green-950/30"
                      : "border-orange-500/30 text-orange-300 hover:bg-orange-950/30"
                  }`}
                >
                  {reportCopied ? <><Check className="w-3 h-3" /> COPIED!</> : <><Copy className="w-3 h-3" /> COPY TEXT</>}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
